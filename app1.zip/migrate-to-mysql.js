import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import mysql from 'mysql2/promise';

// Configuração do Firebase atual
const firebaseConfig = {
  projectId: "festive-analog-ssjh2",
  appId: "1:1039449988090:web:9dce1d5b074c35b1026243",
  apiKey: "AIzaSyBBIg29iSouwSV5hIPIegOL2jtTTNwXVp4",
  authDomain: "festive-analog-ssjh2.firebaseapp.com",
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Configuração do MySQL nativo
const pool = mysql.createPool({
  host: 'localhost',
  user: 'upx_user',
  password: 'banco123$!',
  database: 'gerenciamento_upx',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

async function migrateData() {
  console.log('Iniciando migração do Firebase para MySQL...');

  try {
    // 1. Criar tabelas no MySQL
    console.log('Criando tabelas no MySQL...');
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255),
        email VARCHAR(255),
        role VARCHAR(50),
        status VARCHAR(50),
        password VARCHAR(255)
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS tickets (
        id VARCHAR(255) PRIMARY KEY,
        clientName VARCHAR(255),
        clientPhone VARCHAR(50),
        companyName VARCHAR(255),
        deviceModel VARCHAR(255),
        dateTime DATETIME,
        finishedAt DATETIME,
        problemCategory VARCHAR(255),
        status VARCHAR(50),
        solutionCategory VARCHAR(255),
        observations TEXT,
        technicianId VARCHAR(255),
        technicianName VARCHAR(255),
        transfer JSON
      );
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS counters (
        id VARCHAR(255) PRIMARY KEY,
        value INT
      );
    `);

    // 2. Extrair dados do Firebase e inserir no MySQL
    console.log('Migrando Usuários...');
    const usersSnap = await getDocs(collection(db, 'users'));
    for (const doc of usersSnap.docs) {
      const data = doc.data();
      await pool.query(
        'INSERT IGNORE INTO users (id, name, email, role, status, password) VALUES (?, ?, ?, ?, ?, ?)',
        [doc.id, data.name, data.email, data.role, data.status, data.password || '']
      );
    }

    console.log('Migrando Tickets...');
    const ticketsSnap = await getDocs(collection(db, 'tickets'));
    for (const doc of ticketsSnap.docs) {
      const data = doc.data();
      const transferJson = data.transfer ? JSON.stringify(data.transfer) : null;
      
      await pool.query(
        'INSERT IGNORE INTO tickets (id, clientName, clientPhone, companyName, deviceModel, dateTime, finishedAt, problemCategory, status, solutionCategory, observations, technicianId, technicianName, transfer) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          doc.id, data.clientName, data.clientPhone || null, data.companyName, data.deviceModel, 
          data.dateTime ? new Date(data.dateTime) : null, 
          data.finishedAt ? new Date(data.finishedAt) : null, 
          data.problemCategory, data.status, data.solutionCategory || null, data.observations || null, 
          data.technicianId, data.technicianName, transferJson
        ]
      );
    }

    console.log('Migrando Contadores...');
    const countersSnap = await getDocs(collection(db, 'counters'));
    for (const doc of countersSnap.docs) {
      const data = doc.data();
      await pool.query(
        'INSERT IGNORE INTO counters (id, value) VALUES (?, ?)',
        [doc.id, data.value || 0]
      );
    }

    console.log('Migração concluída com sucesso!');
  } catch (error) {
    console.error('Erro na migração:', error);
  } finally {
    process.exit(0);
  }
}

migrateData();
