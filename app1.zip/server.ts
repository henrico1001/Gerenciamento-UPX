import express from "express";
import cors from "cors";
import path from "path";
import mysql from "mysql2/promise";
import { createServer as createViteServer } from "vite";
import fs from "fs";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(cors());
  app.use(express.json());

  // Connection Pool for MySQL using the user's VM credentials
  const pool = mysql.createPool({
    host: 'localhost',
    user: 'upx_user',
    password: 'banco123$!',
    database: 'gerenciamento_upx',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
  });

  // Verify / Ensure that phone_calls table exists
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS phone_calls (
         id VARCHAR(50) PRIMARY KEY,
         clientName VARCHAR(255) NOT NULL,
         clientPhone VARCHAR(100),
         companyName VARCHAR(255),
         dateTime DATETIME NOT NULL,
         direction VARCHAR(50) NOT NULL,
         recipientName VARCHAR(255),
         subject VARCHAR(255) NOT NULL,
         status VARCHAR(50) NOT NULL,
         notes TEXT,
         loggedById VARCHAR(50) NOT NULL,
         loggedByName VARCHAR(255) NOT NULL
      )
    `);
    console.log("MySQL: Table 'phone_calls' is ready.");
  } catch (err) {
    console.error("MySQL: Error verifying or creating 'phone_calls' table:", err);
  }

  // --- API Routes for Users ---
  
  app.get('/api/backup-download', (req, res) => {
    const secret = req.query.secret;
    if (secret !== 'banco123') {
      return res.status(403).send('Acesso nao autorizado. Use ?secret=seu_segredo');
    }
    const pathsToTry = [
      '/root/backup_gerenciamento_upx.sql',
      path.join(process.cwd(), 'backup_gerenciamento_upx.sql'),
      '/root/Gerenciamento-UPX/backup_gerenciamento_upx.sql'
    ];
    
    let foundPath = '';
    for (const p of pathsToTry) {
      if (fs.existsSync(p)) {
        foundPath = p;
        break;
      }
    }
    
    if (foundPath) {
      res.download(foundPath, 'backup_gerenciamento_upx.sql');
    } else {
      res.status(404).send('Arquivo de backup nao encontrado no servidor. Por favor, gere o backup primeiro no terminal.');
    }
  });
  
  app.get('/api/users', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM users');
      res.json(rows);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/users/:id', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM users WHERE id = ?', [req.params.id]);
      const users = rows as any[];
      if (users.length > 0) res.json(users[0]);
      else res.status(404).json({ error: 'User not found' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/users/:id', async (req, res) => {
    const { name, email, role, status, password } = req.body;
    try {
      await pool.query(
        'INSERT INTO users (id, name, email, role, status, password) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name=VALUES(name), email=VALUES(email), role=VALUES(role), status=VALUES(status), password=VALUES(password)',
        [req.params.id, name, email, role, status, password || '']
      );
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.patch('/api/users/:id', async (req, res) => {
    const data = req.body;
    const entries = Object.entries(data);
    if (entries.length === 0) return res.json({ success: true });
    
    const setClause = entries.map(([k]) => `${k} = ?`).join(', ');
    const values = entries.map(([_, v]) => v);
    values.push(req.params.id);

    try {
      await pool.query(`UPDATE users SET ${setClause} WHERE id = ?`, values);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/users/:id', async (req, res) => {
    try {
      await pool.query('DELETE FROM users WHERE id = ?', [req.params.id]);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // --- API Routes for Tickets ---

  app.get('/api/tickets', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM tickets');
      // Convert database rows to object expected by frontend
      const formatRows = (rows as any[]).map(row => ({
        ...row,
        dateTime: row.dateTime ? new Date(row.dateTime).toISOString() : null,
        finishedAt: row.finishedAt ? new Date(row.finishedAt).toISOString() : null,
        transfer: row.transfer ? (typeof row.transfer === 'string' ? JSON.parse(row.transfer) : row.transfer) : null,
      }));
      res.json(formatRows);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/tickets/:id', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM tickets WHERE id = ?', [req.params.id]);
      const tickets = rows as any[];
      if (tickets.length > 0) {
        const row = tickets[0];
        res.json({
            ...row,
            dateTime: row.dateTime ? new Date(row.dateTime).toISOString() : null,
            finishedAt: row.finishedAt ? new Date(row.finishedAt).toISOString() : null,
            transfer: row.transfer ? (typeof row.transfer === 'string' ? JSON.parse(row.transfer) : row.transfer) : null,
        });
      } else res.status(404).json({ error: 'Ticket not found' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/tickets/:id', async (req, res) => {
    const data = req.body;
    let transferJson = data.transfer ? JSON.stringify(data.transfer) : null;
    let dateTime = data.dateTime ? new Date(data.dateTime) : null;
    let finishedAt = data.finishedAt ? new Date(data.finishedAt) : null;

    try {
        await pool.query(
          `INSERT INTO tickets (id, clientName, clientPhone, companyName, deviceModel, dateTime, finishedAt, problemCategory, status, solutionCategory, observations, technicianId, technicianName, transfer)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE clientName=VALUES(clientName), clientPhone=VALUES(clientPhone), companyName=VALUES(companyName), deviceModel=VALUES(deviceModel), dateTime=VALUES(dateTime), finishedAt=VALUES(finishedAt), problemCategory=VALUES(problemCategory), status=VALUES(status), solutionCategory=VALUES(solutionCategory), observations=VALUES(observations), technicianId=VALUES(technicianId), technicianName=VALUES(technicianName), transfer=VALUES(transfer)`,
          [
            req.params.id, data.clientName, data.clientPhone || null, data.companyName, data.deviceModel, 
            dateTime, finishedAt, data.problemCategory, data.status, 
            data.solutionCategory || null, data.observations || null, data.technicianId, data.technicianName, transferJson
          ]
        );
        res.json({ success: true });
    } catch(err: any) {
        res.status(500).json({ error: err.message });
    }
  });

  app.patch('/api/tickets/:id', async (req, res) => {
    const data = req.body;
    if (data.dateTime) data.dateTime = new Date(data.dateTime);
    if (data.finishedAt) data.finishedAt = new Date(data.finishedAt);
    if (data.transfer !== undefined) data.transfer = data.transfer ? JSON.stringify(data.transfer) : null;

    const entries = Object.entries(data);
    if (entries.length === 0) return res.json({ success: true });
    
    const setClause = entries.map(([k]) => `${k} = ?`).join(', ');
    const values = entries.map(([_, v]) => v ?? null);
    values.push(req.params.id);

    try {
      await pool.query(`UPDATE tickets SET ${setClause} WHERE id = ?`, values);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/tickets/:id', async (req, res) => {
    try {
      await pool.query('DELETE FROM tickets WHERE id = ?', [req.params.id]);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // --- API Routes for Counters ---

  app.get('/api/counters', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM counters');
      res.json(rows);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/counters/:id', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM counters WHERE id = ?', [req.params.id]);
      const counters = rows as any[];
      if (counters.length > 0) res.json(counters[0]);
      else res.status(404).json({ error: 'Counter not found' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/counters/:id', async (req, res) => {
    const { value } = req.body;
    try {
      await pool.query(
        'INSERT INTO counters (id, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value=VALUES(value)',
        [req.params.id, value || 0]
      );
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });


  // --- API Routes for Phone Calls ---

  app.get('/api/phone_calls', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM phone_calls ORDER BY dateTime DESC');
      const formatRows = (rows as any[]).map(row => ({
        ...row,
        dateTime: row.dateTime ? new Date(row.dateTime).toISOString() : null,
      }));
      res.json(formatRows);
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/phone_calls/:id', async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM phone_calls WHERE id = ?', [req.params.id]);
      const calls = rows as any[];
      if (calls.length > 0) {
        const row = calls[0];
        res.json({
          ...row,
          dateTime: row.dateTime ? new Date(row.dateTime).toISOString() : null,
        });
      } else res.status(404).json({ error: 'Phone call not found' });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.put('/api/phone_calls/:id', async (req, res) => {
    const data = req.body;
    let dateTime = data.dateTime ? new Date(data.dateTime) : new Date();

    try {
      await pool.query(
        `INSERT INTO phone_calls (id, clientName, clientPhone, companyName, dateTime, direction, recipientName, subject, status, notes, loggedById, loggedByName)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE clientName=VALUES(clientName), clientPhone=VALUES(clientPhone), companyName=VALUES(companyName), dateTime=VALUES(dateTime), direction=VALUES(direction), recipientName=VALUES(recipientName), subject=VALUES(subject), status=VALUES(status), notes=VALUES(notes), loggedById=VALUES(loggedById), loggedByName=VALUES(loggedByName)`,
        [
          req.params.id, data.clientName, data.clientPhone || null, data.companyName || null,
          dateTime, data.direction, data.recipientName || null, data.subject, data.status,
          data.notes || null, data.loggedById, data.loggedByName
        ]
      );
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.patch('/api/phone_calls/:id', async (req, res) => {
    const data = req.body;
    if (data.dateTime) data.dateTime = new Date(data.dateTime);

    const entries = Object.entries(data);
    if (entries.length === 0) return res.json({ success: true });

    const setClause = entries.map(([k]) => `${k} = ?`).join(', ');
    const values = entries.map(([_, v]) => v ?? null);
    values.push(req.params.id);

    try {
      await pool.query(`UPDATE phone_calls SET ${setClause} WHERE id = ?`, values);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/phone_calls/:id', async (req, res) => {
    try {
      await pool.query('DELETE FROM phone_calls WHERE id = ?', [req.params.id]);
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // --- API Webhook for Automatic Phone Calls (Twilio / Asterisk / API integration) ---
  app.post('/api/webhooks/voice', async (req, res) => {
    // Standard webhook keys supporting both JSON, URL-Encoded formats (from Twilio 'From', 'To', 'CallSid')
    const phone = req.body.From || req.body.clientPhone || req.body.phone || '(31) 98765-4321';
    let clientName = req.body.clientName || 'Novo Cliente (Identificado por Telefone)';
    let companyName = req.body.companyName || 'Empresa Desconhecida';
    const direction = req.body.direction || 'RECEBIDA';
    const callId = req.body.CallSid || req.body.id || `call_auto_${Date.now()}`;
    const subject = req.body.subject || 'Ligação Automática - Entrada de Linha';
    const notes = req.body.notes || 'Ligação detectada e registrada automaticamente no sistema via Webhook.';

    try {
      // SMART LOOKUP: Check if this phone number already exists in some of our tickets to pull actual client details
      const cleanPhone = phone.replace(/\D/g, '');
      if (cleanPhone.length >= 8) {
        // Find tickets that might have similar phone numbers
        const [matchingTickets] = await pool.query(
          `SELECT clientName, companyName FROM tickets 
           WHERE REPLACE(REPLACE(REPLACE(REPLACE(clientPhone, ' ', ''), '-', ''), '(', ''), ')', '') LIKE ? 
           LIMIT 1`, 
          [`%${cleanPhone}%`]
        );
        const resolvedTickets = matchingTickets as any[];
        if (resolvedTickets.length > 0) {
          clientName = resolvedTickets[0].clientName;
          companyName = resolvedTickets[0].companyName || 'Empresa Identificada';
          console.log(`Webhook: Found matching client "${clientName}" for phone number: ${phone}`);
        }
      }

      await pool.query(
        `INSERT INTO phone_calls (id, clientName, clientPhone, companyName, dateTime, direction, recipientName, subject, status, notes, loggedById, loggedByName)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          callId, clientName, phone, companyName, new Date(), direction, 
          'Gestor / Suporte Central', subject, 'PENDENTE_RETORNO', notes, 
          'system', 'Sistema de Telefonia Automático'
        ]
      );

      res.status(200).json({ 
        success: true, 
        message: 'Chamada registrada com sucesso.', 
        data: { id: callId, clientName, clientPhone: phone, companyName, direction }
      });
    } catch (err: any) {
      console.error('Webhook error:', err);
      res.status(500).json({ error: err.message });
    }
  });


  // --- Vite Middleware for Development ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(process.cwd(), 'dist')));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(process.cwd(), 'dist', 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
