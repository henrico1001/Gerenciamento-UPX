/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Ticket, 
  TicketStatus, 
  STATUS_LABELS,
  SOLUTION_CATEGORIES
} from './types';
import { 
  INITIAL_USERS,
  INITIAL_TICKETS,
  loadData,
  getStoredUsers,
  getStoredTickets
} from './utils/mockData';
import { 
  collection, 
  doc, 
  onSnapshot, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  writeBatch,
  getDoc,
  db,
  handleFirestoreError,
  OperationType
} from './lib/api';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import TicketForm from './components/TicketForm';
import SearchAndFilters, { FilterState } from './components/SearchAndFilters';
import ProductivityReports from './components/ProductivityReports';
import AdminSettings from './components/AdminSettings';
import SupportTechnicians from './components/SupportTechnicians';
import TambasaTickets from './components/TambasaTickets';
import PhoneCalls from './components/PhoneCalls';
import { 
  ArrowLeft,
  LayoutDashboard, 
  Layers, 
  Briefcase, 
  PlusCircle, 
  LogOut, 
  Edit3, 
  Trash2, 
  ShieldCheck, 
  Wrench,
  Search,
  CheckCircle2,
  AlertTriangle,
  MessageSquareCode,
  Calendar,
  Building,
  UserCheck,
  ChevronDown,
  Info,
  UserPlus,
  ArrowRightLeft,
  LayoutGrid,
  Clock,
  List,
  Wallet,
  Factory,
  Package,
  Target,
  Settings,
  Phone
} from 'lucide-react';

const formatDuration = (startIso: string, endIso: string) => {
  const diff = new Date(endIso).getTime() - new Date(startIso).getTime();
  if (diff < 0) return 'Duração inválida';
  const m = Math.floor(diff / 60000);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}h ${m % 60}min`;
  return `${m} min`;
};

export default function App() {
  // Import hooks
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [tab, setTab] = useState<'dashboard' | 'chamados' | 'relatorios' | 'tecnicos' | 'suporte-tecnicos' | 'assistencia' | 'assistencia-suporte' | 'assistencia-treinamento' | 'assistencia-credenciamento' | 'assistencia-pecas' | 'assistencia-equipamentos' | 'assistencia-reparos' | 'comercial' | 'financeiro' | 'fabrica' | 'estoque' | 'estrategico' | 'configuracoes-admin' | 'tambasa' | 'ligacoes'>('dashboard');
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [technicians, setTechnicians] = useState<User[]>([]);

  // Ticket Form States
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTicket, setEditingTicket] = useState<Ticket | null>(null);

  // Search and Advanced Filters State
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    technicianId: '',
    status: '',
    date: '',
    minDuration: '',
  });

  // Ticket Detail View Overlay State
  const [activeDetailTicket, setActiveDetailTicket] = useState<Ticket | null>(null);

  // Transfer States
  const [transferringTicket, setTransferringTicket] = useState<Ticket | null>(null);
  const [selectedTransferTechId, setSelectedTransferTechId] = useState('');
  const [transferReason, setTransferReason] = useState('');
  const [transferError, setTransferError] = useState('');

  // Dynamic Ticket Counter linked to Firestore
  const [ticketCounter, setTicketCounter] = useState<number>(113);

  // View mode state for ticket listing (grid or list)
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const [dbError, setDbError] = useState<string | null>(null);

  // Initialize and load saved state on component mount
  useEffect(() => {
    document.documentElement.classList.add('dark');

    // Run safe one-time database seeding check
    const checkAndSeed = async () => {
      try {
        const seedRef = doc(db, 'counters', 'seed_status');
        const seedSnap = await getDoc(seedRef);
        if (!seedSnap.exists() || !seedSnap.data()?.seeded) {
          console.log("Database not seeded. Performing one-time initial seed of users, tickets and counters...");
          const batch = writeBatch(db);
          
          INITIAL_USERS.forEach((usr) => {
            const userRef = doc(db, 'users', usr.id);
            batch.set(userRef, usr);
          });
          
          INITIAL_TICKETS.forEach((t) => {
            const ticketRef = doc(db, 'tickets', t.id);
            batch.set(ticketRef, t);
          });
          
          batch.set(doc(db, 'counters', 'ticket_counter'), { value: 113 });
          batch.set(seedRef, { seeded: true });
          
          await batch.commit();
          console.log("One-time initial database seeding completed successfully.");
        } else {
          // Check and update existing admin to Aurelino and DONO position
          const adminRef = doc(db, 'users', 'admin_ricardo');
          const adminSnap = await getDoc(adminRef);
          if (adminSnap.exists()) {
             const data = adminSnap.data();
             if (data?.name !== 'Aurelino' || data?.email !== 'eng1@upxsolution.com.br') {
               console.log("Updating admin details to Aurelino in Firestore...");
               await updateDoc(adminRef, { name: 'Aurelino', email: 'eng1@upxsolution.com.br', position: 'DONO' });
             }
          }
        }
      } catch (err: any) {
        console.error("Error during initial seeding check: ", err);
        if (err.message && err.message.includes('ECONNREFUSED')) {
            setDbError('O preview do AI Studio não consegue se conectar ao MySQL local da sua máquina. Para testar a aplicação com o MySQL, por favor exporte o código (File > Export as Zip ou Share) e rode `npm start` no seu servidor/máquina virtual onde o banco de dados MySQL está rodando.');
        } else {
            setDbError(err.message || String(err));
        }
      }
    };
    checkAndSeed();

    // Live sync Users (without automatic auto-seeding upon emptiness)
    const unsubscribeUsers = onSnapshot(collection(db, 'users'), (snapshot) => {
      try {
        if (!snapshot.empty) {
          const loadedUsers: User[] = [];
          snapshot.forEach((d) => {
            loadedUsers.push(d.data() as User);
          });
          setTechnicians(loadedUsers);
          localStorage.setItem('upx_users', JSON.stringify(loadedUsers));

          // Real-time synchronization of the currently logged-in user context
          const cachedUser = localStorage.getItem('upx_session');
          if (cachedUser) {
            try {
              const currentCached = JSON.parse(cachedUser) as User;
              const matches = loadedUsers.find(u => u.id === currentCached.id);
              if (matches && (matches.name !== currentCached.name || matches.email !== currentCached.email)) {
                setCurrentUser(matches);
                localStorage.setItem('upx_session', JSON.stringify(matches));
              }
            } catch (e) {
              // Safe bypass
            }
          }
        } else {
          // Seed Firebase with initial users if it's empty
          const initialUsers = getStoredUsers();
          const loadedUsers: User[] = [];
          for (const u of initialUsers) {
             setDoc(doc(db, 'users', u.id), u).catch(err => console.error(err));
             loadedUsers.push(u);
          }
          setTechnicians(loadedUsers);
          localStorage.setItem('upx_users', JSON.stringify(loadedUsers));
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, 'users');
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'users');
    });

    // Live sync Tickets (without automatic auto-seeding upon emptiness)
    const unsubscribeTickets = onSnapshot(collection(db, 'tickets'), (snapshot) => {
      try {
        if (!snapshot.empty) {
          const loadedTickets: Ticket[] = [];
          snapshot.forEach((d) => {
            loadedTickets.push(d.data() as Ticket);
          });
          // Order descending by ISO date
          loadedTickets.sort((a, b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime());
          setTickets(loadedTickets);
          localStorage.setItem('upx_tickets', JSON.stringify(loadedTickets));
        } else {
          // If empty, just set tickets to empty list instead of recreating them!
          setTickets([]);
          localStorage.removeItem('upx_tickets');
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, 'tickets');
      }
    }, (err) => {
      handleFirestoreError(err, OperationType.LIST, 'tickets');
    });

    // Live sync Ticket Counter
    const unsubscribeCounter = onSnapshot(doc(db, 'counters', 'ticket_counter'), (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data();
        setTicketCounter(data.value || 0);
      } else {
        setDoc(doc(db, 'counters', 'ticket_counter'), { value: 113 }).catch((err) => {
          console.error("Error initializing ticket counter in Firestore:", err);
        });
        setTicketCounter(113);
      }
    });

    // Check if user was already logged in (optional persistence)
    const cachedUser = localStorage.getItem('upx_session');
    if (cachedUser) {
      try {
        setCurrentUser(JSON.parse(cachedUser));
      } catch (e) {
        // Safe bypass
      }
    }

    return () => {
      unsubscribeUsers();
      unsubscribeTickets();
      unsubscribeCounter();
    };
  }, []);

  const handleLoginSuccess = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('upx_session', JSON.stringify(user));
    // Reset view
    setTab('dashboard');
    setIsFormOpen(false);
    setEditingTicket(null);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('upx_session');
  };

  // Admin technicians callbacks
  const handleAddTechnician = (newTechData: Omit<User, 'id' | 'role'> & { password?: string }) => {
    const lowerEmail = newTechData.email.toLowerCase();
    const existing = technicians.find(u => u.email.toLowerCase() === lowerEmail);
    if (existing) {
      return { success: false, message: 'Este e-mail já está cadastrado no sistema.' };
    }

    const newId = 'tech_' + Math.random().toString(36).substring(2, 9);
    const newTech: User = {
      id: newId,
      name: newTechData.name,
      email: newTechData.email,
      role: 'TECNICO',
      status: newTechData.status,
      password: '' // Starts empty so they must define the password from the invitation email
    };

    setDoc(doc(db, 'users', newId), newTech)
      .catch(err => handleFirestoreError(err, OperationType.WRITE, `users/${newId}`));

    return { 
      success: true, 
      message: 'Técnico cadastrado com sucesso! Um e-mail de convite de ativação foi enviado.',
      techId: newId 
    };
  };

  const handleSetTechnicianPassword = async (techId: string, passwordString: string) => {
    try {
      await updateDoc(doc(db, 'users', techId), { password: passwordString });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${techId}`);
    }
  };

  const handleDeleteTechnician = async (techId: string) => {
    try {
      await deleteDoc(doc(db, 'users', techId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${techId}`);
    }
  };

  const handleToggleTechnicianStatus = async (techId: string) => {
    const tech = technicians.find(u => u.id === techId);
    if (!tech) return;
    const newStatus = tech.status === 'ATIVO' ? 'INATIVO' : 'ATIVO';
    try {
      await updateDoc(doc(db, 'users', techId), { status: newStatus });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${techId}`);
    }
  };

  const handleResetTicketCounter = async () => {
    if (!isAdmin) return;
    try {
      await setDoc(doc(db, 'counters', 'ticket_counter'), { value: 1 });
      alert("Número dos pedidos reiniciado com sucesso.");
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, 'counters/ticket_counter');
    }
  };

  const handleUpdateUser = async (updatedUser: User) => {
    try {
      await updateDoc(doc(db, 'users', updatedUser.id), updatedUser as any);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${updatedUser.id}`);
    }
  };

  // Add / Edit Ticket callback
  const handleTicketSubmit = async (ticketData: Omit<Ticket, 'id' | 'dateTime' | 'technicianId' | 'technicianName' | 'transfer'> & { id?: string; transfer?: Ticket['transfer'] }) => {
    if (!currentUser) return;

    try {
      if (ticketData.id) {
        // Editing Mode - build the updated fields directly
        const updatedFields: Partial<Ticket> = {
          clientName: ticketData.clientName,
          clientPhone: ticketData.clientPhone || null as any,
          companyName: ticketData.companyName,
          deviceModel: ticketData.deviceModel,
          problemCategory: ticketData.problemCategory,
          status: ticketData.status,
          solutionCategory: ticketData.solutionCategory || null as any,
          observations: ticketData.observations || null as any,
          transfer: ticketData.transfer || null as any,
          finishedAt: ticketData.finishedAt || null as any,
        };
        // Remove undefined fields
        Object.keys(updatedFields).forEach(key => {
          if ((updatedFields as any)[key] === undefined) {
            delete (updatedFields as any)[key];
          }
        });

        await updateDoc(doc(db, 'tickets', ticketData.id), updatedFields);
      } else {
        // Creation Mode using global Firestore synchronized ticketCounter
        const newId = ticketCounter.toString();
        await setDoc(doc(db, 'counters', 'ticket_counter'), { value: ticketCounter + 1 });
        
        const newTicket: Ticket = {
          id: newId,
          clientName: ticketData.clientName,
          clientPhone: ticketData.clientPhone || undefined,
          companyName: ticketData.companyName,
          deviceModel: ticketData.deviceModel,
          dateTime: new Date().toISOString(),
          finishedAt: ticketData.finishedAt,
          problemCategory: ticketData.problemCategory,
          status: ticketData.status,
          solutionCategory: ticketData.solutionCategory,
          observations: ticketData.observations,
          technicianId: currentUser.id,
          technicianName: currentUser.name,
          transfer: ticketData.transfer,
        };
        // Remove undefined fields
        Object.keys(newTicket).forEach(key => {
          if ((newTicket as any)[key] === undefined) {
            delete (newTicket as any)[key];
          }
        });

        await setDoc(doc(db, 'tickets', newId), newTicket);
      }
      setIsFormOpen(false);
      setEditingTicket(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `tickets/${ticketData.id || 'new'}`);
    }
  };

  const [ticketToDelete, setTicketToDelete] = useState<Ticket | null>(null);

  // Finalize Ticket State
  const [ticketToFinalize, setTicketToFinalize] = useState<Ticket | null>(null);
  const [finalizeSolutionCategory, setFinalizeSolutionCategory] = useState(SOLUTION_CATEGORIES[0]);
  const [finalizeTime, setFinalizeTime] = useState('');

  const initiateTicketFinalize = (ticket: Ticket) => {
    // Current time
    const now = new Date();
    const hh = now.getHours().toString().padStart(2, '0');
    const mm = now.getMinutes().toString().padStart(2, '0');
    setFinalizeTime(`${hh}:${mm}`);
    setFinalizeSolutionCategory(ticket.solutionCategory || SOLUTION_CATEGORIES[0]);
    setTicketToFinalize(ticket);
  };

  const confirmTicketFinalize = async () => {
    if (!ticketToFinalize) return;
    try {
      const baseDate = new Date(ticketToFinalize.dateTime);
      if (finalizeTime) {
        const [hh, mm] = finalizeTime.split(':').map(Number);
        if (!isNaN(hh) && !isNaN(mm)) {
          baseDate.setHours(hh, mm, 0, 0);
        }
      }
      const updatedFields = {
        status: 'RESOLVIDO' as const,
        solutionCategory: finalizeSolutionCategory,
        finishedAt: baseDate.toISOString()
      };
      await updateDoc(doc(db, 'tickets', ticketToFinalize.id), updatedFields);
      
      if (activeDetailTicket?.id === ticketToFinalize.id) {
         setActiveDetailTicket({ ...activeDetailTicket, ...updatedFields });
      }
      setTicketToFinalize(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `tickets/${ticketToFinalize.id}`);
    }
  };

  // Delete Ticket Callback
  const confirmTicketDelete = async () => {
    if (!ticketToDelete) return;
    try {
      await deleteDoc(doc(db, 'tickets', ticketToDelete.id));
      if (activeDetailTicket?.id === ticketToDelete.id) {
        setActiveDetailTicket(null);
      }
      setTicketToDelete(null);
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `tickets/${ticketToDelete.id}`);
    }
  };

  // Transfer Handlers
  const handleInitiateTransfer = async (ticketId: string, toTechId: string, reason: string) => {
    if (!reason.trim()) {
      return { success: false, message: 'Por favor, insira o motivo da transferência.' };
    }
    if (!toTechId) {
      return { success: false, message: 'Por favor, selecione um técnico de destino.' };
    }
    const targetTech = technicians.find(u => u.id === toTechId);
    if (!targetTech) {
      return { success: false, message: 'Técnico de destino não encontrado.' };
    }

    const t = tickets.find(tk => tk.id === ticketId);
    if (!t) {
      return { success: false, message: 'Chamado não encontrado.' };
    }

    const transferData = {
      fromId: t.technicianId,
      fromName: t.technicianName,
      toId: targetTech.id,
      toName: targetTech.name,
      reason: reason.trim(),
      status: 'PENDENTE' as const,
      timestamp: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'tickets', ticketId), { transfer: transferData });
      return { success: true, message: 'Transferência enviada com sucesso!' };
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `tickets/${ticketId}`);
      return { success: false, message: 'Erro ao solicitar a transferência no servidor.' };
    }
  };

  const handleAcceptTransfer = async (ticketId: string) => {
    if (!currentUser) return;
    const t = tickets.find(tk => tk.id === ticketId);
    if (!t || !t.transfer) return;

    const updatedTransfer = {
      ...t.transfer,
      status: 'ACEITO' as const,
      timestamp: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'tickets', ticketId), {
        technicianId: currentUser.id,
        technicianName: currentUser.name,
        transfer: updatedTransfer
      });
      
      // Also update current active detail modal object if it is open
      if (activeDetailTicket?.id === ticketId) {
        setActiveDetailTicket({
          ...t,
          technicianId: currentUser.id,
          technicianName: currentUser.name,
          transfer: updatedTransfer
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `tickets/${ticketId}`);
    }
  };

  const handleDeclineTransfer = async (ticketId: string) => {
    const t = tickets.find(tk => tk.id === ticketId);
    if (!t || !t.transfer) return;

    const updatedTransfer = {
      ...t.transfer,
      status: 'RECUSADO' as const,
      timestamp: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'tickets', ticketId), { transfer: updatedTransfer });

      // Also update current active detail modal object if it is open
      if (activeDetailTicket?.id === ticketId) {
        setActiveDetailTicket({
          ...t,
          transfer: updatedTransfer
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `tickets/${ticketId}`);
    }
  };

  const handleClearTransferRefusedMessage = async (ticketId: string) => {
    try {
      // In JS Firestore SDK, we can pass null to successfully overwrite and wipe the key in the document payload
      await updateDoc(doc(db, 'tickets', ticketId), { transfer: null as any });

      // Also update current active detail modal object if it is open
      if (activeDetailTicket?.id === ticketId) {
        setActiveDetailTicket(prev => prev ? { ...prev, transfer: undefined } : null);
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `tickets/${ticketId}`);
    }
  };

  // Memos for transfer items
  const pendingTransfersForMe = useMemo(() => {
    if (!currentUser) return [];
    return tickets.filter(t => t.transfer?.toId === currentUser.id && t.transfer?.status === 'PENDENTE');
  }, [tickets, currentUser]);

  const myOutboxTransfers = useMemo(() => {
    if (!currentUser) return [];
    return tickets.filter(t => t.transfer?.fromId === currentUser.id && t.transfer?.status === 'PENDENTE');
  }, [tickets, currentUser]);

  // Restrict access on standard technician role
  const viewableTickets = useMemo(() => {
    if (!currentUser) return [];
    // Technicians can now view and edit other technician's tickets as requested
    return tickets;
  }, [tickets, currentUser]);

  // Compute final filtered results based on search models
  const filteredTickets = useMemo(() => {
    return viewableTickets.filter(ticket => {
      // Client description/company search
      if (filters.searchQuery) {
        const q = filters.searchQuery.toLowerCase();
        const clientMatch = ticket.clientName.toLowerCase().includes(q);
        const companyMatch = ticket.companyName.toLowerCase().includes(q);
        if (!clientMatch && !companyMatch) return false;
      }
      
      // Technician select
      if (filters.technicianId && ticket.technicianId !== filters.technicianId) {
        return false;
      }

      // Status match
      if (filters.status && ticket.status !== filters.status) {
        return false;
      }

      // Date select check
      if (filters.date) {
        const tDateObj = new Date(ticket.dateTime);
        const matchYear = tDateObj.getFullYear();
        const matchMonth = String(tDateObj.getMonth() + 1).padStart(2, '0');
        const matchDay = String(tDateObj.getDate()).padStart(2, '0');
        const formattedTicketDate = `${matchYear}-${matchMonth}-${matchDay}`;
        if (formattedTicketDate !== filters.date) return false;
      }

      // Min duration check
      if (filters.minDuration) {
        const minMins = parseInt(filters.minDuration, 10);
        if (!isNaN(minMins)) {
           const endIso = ticket.finishedAt || new Date().toISOString();
           const diffMins = (new Date(endIso).getTime() - new Date(ticket.dateTime).getTime()) / 60000;
           if (diffMins < minMins) return false;
        }
      }

      return true;
    });
  }, [viewableTickets, filters]);

  // Handle switching edit mode
  const triggerEdit = (ticket: Ticket) => {
    setEditingTicket(ticket);
    setIsFormOpen(true);
    setActiveDetailTicket(null);
  };

  if (!currentUser) {
    return (
      <>
        {dbError && (
          <div className="bg-red-500/90 text-white p-4 text-center text-sm font-medium sticky top-0 z-50">
            ⚠ {dbError}
          </div>
        )}
        <Login onLoginSuccess={handleLoginSuccess} technicians={technicians} />
      </>
    );
  }

  const isAdmin = currentUser.role === 'ADMIN';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0F172A] flex flex-col font-sans text-slate-850 dark:text-slate-100 antialiased transition-colors duration-300 selection:bg-cyan-500 selection:text-white" id="main-container">
      {dbError && (
          <div className="bg-red-500/90 text-white p-4 text-center text-sm font-medium sticky top-0 z-50 shadow-md backdrop-blur-md">
            ⚠ {dbError}
          </div>
      )}
      
      {/* Top Professional Navbar */}
      <header className="bg-slate-900/90 backdrop-blur-md text-white sticky top-0 z-30 shadow-md px-6 py-4 flex flex-wrap justify-between items-center border-b border-slate-800/60" id="navbar">
        <div className="flex items-center gap-3">
            <img 
              src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNihFkMakDJ_PHpwVWeSTaeSkMGfg-xeTWvg&s" 
              alt="UPX Logo" 
              className="w-10 h-10 object-contain rounded-xl" 
            />
          <div>
            <h1 className="text-base font-black tracking-tight flex items-center gap-1.5 text-[#ffffff]">
              UPX <span className="text-[10px] bg-cyan-950/80 border border-cyan-800/50 px-1.5 py-0.5 rounded-md text-cyan-400 uppercase font-bold tracking-wider">PRO</span>
            </h1>
            <span className="text-[10px] text-cyan-400 font-mono tracking-wider block uppercase">Gestão de Atendimento</span>
          </div>
        </div>

        {/* User context information and Quick LogOut */}
        <div className="flex items-center gap-3 mt-2 sm:mt-0">
          <div className="flex items-center gap-2.5 bg-slate-800/70 backdrop-blur-sm px-3.5 py-1.5 rounded-xl border border-slate-700/50 hover:border-slate-600 transition-colors">
            {isAdmin ? (
              <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
            ) : (
              <Wrench className="w-4 h-4 text-slate-400 shrink-0" />
            )}
            <div className="text-left text-xs">
              <p className="font-extrabold text-[#FFFFFF] leading-none">{currentUser.name}</p>
              <span className="text-[9px] text-[#A5F3FC] capitalize block mt-0.5 font-semibold">{isAdmin ? 'Administrador' : 'Técnico de Suporte'}</span>
            </div>
          </div>

          <button
            id="btn-logout"
            onClick={handleLogout}
            className="p-2.5 bg-rose-500/20 hover:bg-rose-600 text-rose-300 hover:text-white rounded-xl transition-all cursor-pointer border border-rose-500/50 hover:border-rose-500 shadow-md hover:shadow-rose-600/20 active:scale-95 flex items-center justify-center gap-1.5 font-bold"
            title="Desconectar do sistema"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline text-[10px] font-black uppercase tracking-wider">Desconectar</span>
          </button>
        </div>
      </header>

      {/* Main Body Grid */}
      <main className="flex-1 w-full max-w-[98%] mx-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column Navigation (Menu Panel) */}
        {!isFormOpen && (
          <div className="lg:col-span-3 space-y-4">
            
            <div className="bg-white dark:bg-[#1E293B] p-4 rounded-2xl border border-slate-200 dark:border-slate-800/60 shadow- premium-hover shadow-saas space-y-2 relative" id="sidebar-navigation">
              <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-3 px-1">Menu Principal</span>
              
              {/* Dashboard View toggle */}
              <button
                id="tab-dashboard-act"
                onClick={() => setTab('dashboard')}
                className={`w-full text-left p-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-colors cursor-pointer relative overflow-hidden group ${
                  tab === 'dashboard' 
                    ? 'bg-cyan-50/80 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 border border-cyan-200/50 dark:border-cyan-550/20 font-extrabold shadow-sm' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/40 border border-transparent'
                }`}
              >
                {tab === 'dashboard' && (
                  <span className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-cyan-500 rounded-r-md"></span>
                )}
                <LayoutDashboard className={`w-4 h-4 ${tab === 'dashboard' ? 'text-cyan-550 dark:text-cyan-400' : 'text-slate-400 group-hover:text-cyan-500'}`} />
                Painel Geral (Dashboard)
              </button>

              {/* Assistência View toggle */}
              <button
                id="tab-assistencia-act"
                onClick={() => setTab('assistencia')}
                className={`w-full text-left p-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-colors cursor-pointer relative overflow-hidden group ${
                  ['assistencia', 'assistencia-treinamento', 'assistencia-credenciamento', 'assistencia-pecas', 'assistencia-equipamentos', 'assistencia-reparos', 'chamados', 'relatorios', 'suporte-tecnicos'].includes(tab)
                    ? 'bg-cyan-50/80 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 border border-cyan-200/50 dark:border-cyan-550/20 font-extrabold shadow-sm' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/40 border border-transparent'
                }`}
              >
                {['assistencia', 'assistencia-treinamento', 'assistencia-credenciamento', 'assistencia-pecas', 'assistencia-equipamentos', 'assistencia-reparos', 'chamados', 'relatorios', 'suporte-tecnicos'].includes(tab) && (
                  <span className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-cyan-500 rounded-r-md"></span>
                )}
                <Wrench className={`w-4 h-4 ${['assistencia', 'assistencia-treinamento', 'assistencia-credenciamento', 'assistencia-pecas', 'assistencia-equipamentos', 'assistencia-reparos', 'chamados', 'relatorios', 'suporte-tecnicos'].includes(tab) ? 'text-cyan-550 dark:text-cyan-400' : 'text-slate-400 group-hover:text-cyan-500'}`} />
                Assistência
              </button>

              {/* Comercial View toggle */}
              <button
                id="tab-comercial-act"
                onClick={() => setTab('comercial')}
                className={`w-full text-left p-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-colors cursor-pointer relative overflow-hidden group ${
                  tab === 'comercial' 
                    ? 'bg-cyan-50/80 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 border border-cyan-200/50 dark:border-cyan-550/20 font-extrabold shadow-sm' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/40 border border-transparent'
                }`}
              >
                {tab === 'comercial' && (
                  <span className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-cyan-500 rounded-r-md"></span>
                )}
                <Briefcase className={`w-4 h-4 ${tab === 'comercial' ? 'text-cyan-550 dark:text-cyan-400' : 'text-slate-400 group-hover:text-cyan-500'}`} />
                Comercial
              </button>

              {/* Financeiro View toggle */}
              <button
                id="tab-financeiro-act"
                onClick={() => setTab('financeiro')}
                className={`w-full text-left p-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-colors cursor-pointer relative overflow-hidden group ${
                  tab === 'financeiro' 
                    ? 'bg-cyan-50/80 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 border border-cyan-200/50 dark:border-cyan-550/20 font-extrabold shadow-sm' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/40 border border-transparent'
                }`}
              >
                {tab === 'financeiro' && (
                  <span className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-cyan-500 rounded-r-md"></span>
                )}
                <Wallet className={`w-4 h-4 ${tab === 'financeiro' ? 'text-cyan-550 dark:text-cyan-400' : 'text-slate-400 group-hover:text-cyan-500'}`} />
                Financeiro
              </button>

              {/* Fábrica View toggle */}
              <button
                id="tab-fabrica-act"
                onClick={() => setTab('fabrica')}
                className={`w-full text-left p-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-colors cursor-pointer relative overflow-hidden group ${
                  tab === 'fabrica' 
                    ? 'bg-cyan-50/80 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 border border-cyan-200/50 dark:border-cyan-550/20 font-extrabold shadow-sm' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/40 border border-transparent'
                }`}
              >
                {tab === 'fabrica' && (
                  <span className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-cyan-500 rounded-r-md"></span>
                )}
                <Factory className={`w-4 h-4 ${tab === 'fabrica' ? 'text-cyan-550 dark:text-cyan-400' : 'text-slate-400 group-hover:text-cyan-500'}`} />
                Fábrica
              </button>

              {/* Estoque View toggle */}
              <button
                id="tab-estoque-act"
                onClick={() => setTab('estoque')}
                className={`w-full text-left p-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-colors cursor-pointer relative overflow-hidden group ${
                  tab === 'estoque' 
                    ? 'bg-cyan-50/80 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 border border-cyan-200/50 dark:border-cyan-550/20 font-extrabold shadow-sm' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/40 border border-transparent'
                }`}
              >
                {tab === 'estoque' && (
                  <span className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-cyan-500 rounded-r-md"></span>
                )}
                <Package className={`w-4 h-4 ${tab === 'estoque' ? 'text-cyan-550 dark:text-cyan-400' : 'text-slate-400 group-hover:text-cyan-500'}`} />
                Estoque
              </button>

              {/* Estratégico View toggle */}
              <button
                id="tab-estrategico-act"
                onClick={() => setTab('estrategico')}
                className={`w-full text-left p-3 rounded-xl text-xs font-semibold flex items-center gap-3 transition-colors cursor-pointer relative overflow-hidden group ${
                  tab === 'estrategico' 
                    ? 'bg-cyan-50/80 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 border border-cyan-200/50 dark:border-cyan-550/20 font-extrabold shadow-sm' 
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800/40 border border-transparent'
                }`}
              >
                {tab === 'estrategico' && (
                  <span className="absolute left-0 top-1/4 bottom-1/4 w-1 bg-cyan-500 rounded-r-md"></span>
                )}
                <Target className={`w-4 h-4 ${tab === 'estrategico' ? 'text-cyan-550 dark:text-cyan-400' : 'text-slate-400 group-hover:text-cyan-500'}`} />
                Estratégico
              </button>

            </div>

            {/* Quick Action Button: Create Service Check-In (SaaS Highlighted CTA with business brand color #06B6D4) */}
            <button
              id="btn-quick-new-ticket"
              onClick={() => { setEditingTicket(null); setIsFormOpen(true); }}
              className="w-full bg-gradient-to-r from-cyan-500 via-cyan-600 to-cyan-500 hover:opacity-95 active:scale-[0.98] text-white font-black py-4 px-4 rounded-xl shadow-lg shadow-cyan-500/15 flex items-center justify-center gap-2 text-xs cursor-pointer transition-all hover:scale-[1.015] hover:shadow-cyan-500/25 select-none animate-pulse hover:animate-none"
            >
              <PlusCircle className="w-5 h-5 text-white" />
              Novo Atendimento
            </button>

            {/* Short helpful hint box */}
            <div className="bg-slate-50/60 dark:bg-slate-900/60 p-4 rounded-2xl border border-slate-200 dark:border-slate-800/60 text-[11px] text-slate-500 dark:text-slate-400 space-y-1.5 shadow-saas">
              <span className="font-extrabold flex items-center gap-1.5 text-slate-700 dark:text-slate-300">
                <Info className="w-3.5 h-3.5 text-cyan-500" />
                Espaço UPX Suporte
              </span>
              <p className="leading-relaxed font-light">
                {isAdmin
                  ? "Como supervisor, você tem visão consolidada do faturamento, SLA e fechamento de atendimentos de todos os colaboradores do time de campo."
                  : "Organize seus chamados do dia. Lembre-se de preencher a Solução Aplicada para cada chamado resolvido!"}
              </p>
            </div>

          </div>
        )}

        {/* Right Content Column (Dynamic Content Panel) */}
        <div className={isFormOpen ? "col-span-12" : "col-span-12 lg:col-span-9"}>
          
          {isFormOpen ? (
            /* Open Ticket Creator / Editor Form */
            <TicketForm 
              currentUser={currentUser} 
              allTechnicians={technicians}
              editingTicket={editingTicket} 
              onSubmit={handleTicketSubmit} 
              onCancel={() => { setIsFormOpen(false); setEditingTicket(null); }} 
            />
          ) : (
            /* Tab layouts rendering */
            <div className="space-y-6">
              
              {tab !== 'dashboard' && (
                <div className="animate-fadeIn">
                  <button
                    onClick={() => setTab('dashboard')}
                    className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-cyan-600 transition-colors duration-200 cursor-pointer font-semibold select-none group"
                  >
                    <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-0.5" />
                    Voltar ao Painel Geral
                  </button>
                </div>
              )}

              {/* Assistência Sub-navigation Header */}
              {['assistencia', 'assistencia-treinamento', 'assistencia-credenciamento', 'assistencia-pecas', 'assistencia-equipamentos', 'assistencia-reparos', 'chamados', 'relatorios', 'suporte-tecnicos', 'tambasa', 'ligacoes'].includes(tab) && (
                <div className="space-y-4 animate-fadeIn" id="assistencia-sub-nav">
                  <div className="bg-white dark:bg-[#1E293B] p-2 rounded-2xl border border-slate-200 dark:border-slate-800/60 shadow-[0_2px_8px_-3px_rgba(6,182,212,0.1)] flex flex-wrap gap-1.5 items-center">
                    <button onClick={() => setTab('chamados')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${['chamados', 'relatorios', 'suporte-tecnicos', 'assistencia', 'tambasa', 'ligacoes'].includes(tab) ? 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-750 dark:text-cyan-400 border border-cyan-100 dark:border-cyan-800/50 shadow-sm' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 border border-transparent'}`}>Suporte</button>
                    <button onClick={() => setTab('assistencia-treinamento')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${tab === 'assistencia-treinamento' ? 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-750 dark:text-cyan-400 border border-cyan-100 dark:border-cyan-800/50 shadow-sm' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 border border-transparent'}`}>Treinamento</button>
                    <button onClick={() => setTab('assistencia-credenciamento')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${tab === 'assistencia-credenciamento' ? 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-750 dark:text-cyan-400 border border-cyan-100 dark:border-cyan-800/50 shadow-sm' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 border border-transparent'}`}>Credenciamento</button>
                    <button onClick={() => setTab('assistencia-pecas')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${tab === 'assistencia-pecas' ? 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-750 dark:text-cyan-400 border border-cyan-100 dark:border-cyan-800/50 shadow-sm' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 border border-transparent'}`}>Gerenciar Peças</button>
                    <button onClick={() => setTab('assistencia-equipamentos')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${tab === 'assistencia-equipamentos' ? 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-750 dark:text-cyan-400 border border-cyan-100 dark:border-cyan-800/50 shadow-sm' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 border border-transparent'}`}>Gerenciar Equipamentos</button>
                    <button onClick={() => setTab('assistencia-reparos')} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${tab === 'assistencia-reparos' ? 'bg-cyan-50 dark:bg-cyan-900/20 text-cyan-750 dark:text-cyan-400 border border-cyan-100 dark:border-cyan-800/50 shadow-sm' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800/50 border border-transparent'}`}>Reparos F. Garantia</button>
                  </div>

                  {/* Secondary Level for Suporte */}
                  {['assistencia', 'chamados', 'relatorios', 'suporte-tecnicos', 'tambasa', 'ligacoes'].includes(tab) && (
                    <div className="flex flex-wrap gap-2 items-center px-1">
                      <button onClick={() => setTab('chamados')} className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border ${['chamados', 'assistencia'].includes(tab) ? 'bg-white dark:bg-[#1E293B] border-slate-300 dark:border-slate-600 text-slate-800 dark:text-slate-100 shadow-sm' : 'border-transparent text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-800'}`}>Histórico de Chamados</button>
                      {isAdmin && <button onClick={() => setTab('relatorios')} className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border ${tab === 'relatorios' ? 'bg-white dark:bg-[#1E293B] border-slate-300 dark:border-slate-600 text-slate-800 dark:text-slate-100 shadow-sm' : 'border-transparent text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-800'}`}>Relatórios SLA</button>}
                      {isAdmin && <button onClick={() => setTab('suporte-tecnicos')} className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border ${tab === 'suporte-tecnicos' ? 'bg-white dark:bg-[#1E293B] border-slate-300 dark:border-slate-600 text-slate-800 dark:text-slate-100 shadow-sm' : 'border-transparent text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-800'}`}>Gerenciar Técnicos</button>}
                      <button onClick={() => setTab('tambasa')} className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border ${tab === 'tambasa' ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700/50 text-blue-700 dark:text-blue-400 shadow-sm' : 'border-transparent text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-800'}`}>
                        Tambasa
                      </button>
                      <button onClick={() => setTab('ligacoes')} className={`px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all cursor-pointer border ${tab === 'ligacoes' ? 'bg-cyan-50 dark:bg-cyan-900/20 border-cyan-300 dark:border-cyan-700/50 text-cyan-700 dark:text-cyan-400 shadow-sm' : 'border-transparent text-slate-500 hover:bg-slate-200/50 dark:hover:bg-slate-800'}`}>
                        Controle de Ligações
                      </button>
                    </div>
                  )}
                </div>
              )}

              {tab === 'dashboard' && (
                <Dashboard 
                  tickets={tickets} 
                  currentUser={currentUser} 
                  allTechnicians={technicians} 
                  onTicketClick={(ticket) => setActiveDetailTicket(ticket)}
                  onMetricClick={(statusFilter) => {
                    setFilters(prev => ({
                      ...prev,
                      status: statusFilter
                    }));
                    setTab('chamados');
                  }}
                />
              )}

              {tab === 'relatorios' && isAdmin && (
                <ProductivityReports 
                  tickets={tickets} 
                  technicians={technicians} 
                  onBackToDashboard={() => setTab('dashboard')} 
                />
              )}

              {tab === 'suporte-tecnicos' && isAdmin && (
                <SupportTechnicians 
                  technicians={technicians} 
                  onAddTechnician={handleAddTechnician} 
                  onDeleteTechnician={handleDeleteTechnician}
                  onToggleStatus={handleToggleTechnicianStatus}
                  onSetTechnicianPassword={handleSetTechnicianPassword}
                  onResetTicketCounter={handleResetTicketCounter}
                />
              )}

              {tab === 'tambasa' && (
                <TambasaTickets 
                  currentUser={currentUser}
                  isAdmin={isAdmin}
                />
              )}

              {tab === 'ligacoes' && (
                <PhoneCalls 
                  currentUser={currentUser}
                  tickets={tickets}
                />
              )}



              {['assistencia-treinamento', 'assistencia-credenciamento', 'assistencia-pecas', 'assistencia-equipamentos', 'assistencia-reparos', 'comercial', 'financeiro', 'fabrica', 'estoque', 'estrategico'].includes(tab) && (
                <div className="bg-white dark:bg-[#1E293B] p-8 rounded-2xl border border-slate-200 dark:border-slate-800/60 shadow-sm flex flex-col items-center justify-center text-center space-y-4 animate-fadeIn min-h-[400px]">
                  <div className="bg-slate-50 dark:bg-slate-800/50 p-6 rounded-full">
                    <Wrench className="w-10 h-10 text-cyan-500/50" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2 capitalize">
                      {{
                        'assistencia-treinamento': 'Treinamento',
                        'assistencia-credenciamento': 'Credenciamento',
                        'assistencia-pecas': 'Gerenciar Peças',
                        'assistencia-equipamentos': 'Gerenciar Equipamentos',
                        'assistencia-reparos': 'Reparos Fora de Garantia',
                        'comercial': 'Comercial',
                        'financeiro': 'Financeiro',
                        'fabrica': 'Fábrica',
                        'estoque': 'Estoque',
                        'estrategico': 'Estratégico'
                      }[tab] || tab}
                    </h2>
                    <p className="text-sm text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
                      Esta área está atualmente em desenvolvimento e estará disponível nas próximas atualizações.
                    </p>
                  </div>
                </div>
              )}

              {['chamados', 'assistencia'].includes(tab) && (
                <div className="space-y-5" id="ticket-listing-panel">
                  
                  {/* Transfer requests alert box */}
                  {pendingTransfersForMe.length > 0 && (
                    <div className="bg-slate-100 p-5 rounded-2xl border border-slate-300 shadow-sm space-y-3.5" id="pending-transfers-alert-box">
                      <div className="flex items-center gap-2 text-sky-700">
                        <div className="w-2 h-2 rounded-full bg-sky-500 animate-ping shrink-0" />
                        <ArrowRightLeft className="w-4.5 h-4.5 text-sky-600 shrink-0" />
                        <h3 className="text-xs font-black uppercase tracking-wider text-sky-800">
                          Novas solicitações de transferência recebidas ({pendingTransfersForMe.length})
                        </h3>
                      </div>
                      <p className="text-xs text-slate-700 leading-relaxed">
                        Outros técnicos solicitaram a transferência dos seguintes chamados para você.
                        <span className="font-semibold text-slate-900"> Você precisa aceitar o chamado para que ele seja transferido para si.</span>
                      </p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {pendingTransfersForMe.map((ticket) => (
                          <div 
                            key={ticket.id} 
                            className="bg-white p-4 rounded-xl border border-amber-200 shadow-xs flex flex-col justify-between space-y-3"
                            id={`pending-transfer-card-${ticket.id}`}
                          >
                            <div className="space-y-1.5">
                              <div className="flex justify-between items-center text-[10px]">
                                <span className="font-mono bg-amber-100 text-amber-800 px-2.5 py-0.5 rounded font-bold notranslate" translate="no">
                                  ID: {ticket.id}
                                </span>
                                <span className="text-slate-400 font-medium">
                                  Enviado em: {new Date(ticket.transfer!.timestamp).toLocaleDateString('pt-BR')}
                                </span>
                              </div>
                              
                              <h4 className="text-xs font-bold text-slate-800 leading-snug">
                                {ticket.companyName}
                              </h4>
                              <p className="text-[11px] text-slate-650">
                                <span className="font-medium text-slate-400">Cliente:</span> {ticket.clientName}
                              </p>
                              <p className="text-[11px] text-slate-650">
                                <span className="font-medium text-slate-400">Problema:</span> {ticket.problemCategory}
                              </p>
                              
                              <div className="p-2 bg-amber-50/50 rounded-lg border border-amber-100 text-[11px] text-slate-700">
                                <span className="text-[9px] font-bold text-amber-700 block uppercase tracking-wider mb-0.5">
                                  Motivo da Transferência
                                </span>
                                <p className="italic font-medium leading-relaxed">
                                  "{ticket.transfer!.reason}"
                                </p>
                              </div>
                              
                              <p className="text-[10px] text-slate-400 font-medium">
                                Enviado por: <span className="font-bold text-cyan-600">{ticket.transfer!.fromName}</span>
                              </p>
                            </div>
                            
                            <div className="flex gap-2 pt-2.5 border-t border-slate-100">
                              <button
                                onClick={() => handleAcceptTransfer(ticket.id)}
                                className="flex-1 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold text-xs py-2 rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-sm shadow-emerald-950/5"
                                id={`btn-accept-transfer-${ticket.id}`}
                              >
                                ✓ Aceitar
                              </button>
                              <button
                                onClick={() => handleDeclineTransfer(ticket.id)}
                                className="px-3 bg-slate-100 hover:bg-rose-50 hover:text-rose-600 active:bg-rose-100 text-slate-650 font-bold text-xs py-2 rounded-lg transition-colors cursor-pointer"
                                id={`btn-decline-transfer-${ticket.id}`}
                              >
                                Recusar
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* List Header */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div>
                      <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 tracking-tight flex items-center gap-2">
                        <Layers className="w-5.5 h-5.5 text-cyan-600" />
                        Repositório de Atendimentos
                      </h2>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {isAdmin 
                          ? "Pesquise e gerencie o histórico completo de chamados corporativos da empresa." 
                          : "Consulte ou modifique o seu histórico pessoal de atendimentos finalizados."}
                      </p>
                    </div>

                    <div className="flex items-center gap-3 w-full sm:w-auto self-stretch sm:self-auto justify-between sm:justify-end">
                      {/* View Mode Switcher */}
                      <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
                        <button
                          type="button"
                          id="btn-view-grid"
                          onClick={() => setViewMode('grid')}
                          className={`p-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold ${
                            viewMode === 'grid'
                              ? 'bg-white dark:bg-slate-750 text-cyan-600 dark:text-cyan-400 shadow-xs'
                              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-250'
                          }`}
                          title="Visualização em Grade/Cards"
                        >
                          <LayoutGrid className="w-4 h-4" />
                          <span className="sr-only sm:not-sr-only">Grade</span>
                        </button>
                        <button
                          type="button"
                          id="btn-view-list"
                          onClick={() => setViewMode('list')}
                          className={`p-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 text-xs font-bold ${
                            viewMode === 'list'
                              ? 'bg-white dark:bg-slate-755 text-cyan-600 dark:text-cyan-400 shadow-xs'
                              : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-250'
                          }`}
                          title="Visualização em Lista Compacta"
                        >
                          <List className="w-4 h-4" />
                          <span className="sr-only sm:not-sr-only">Lista</span>
                        </button>
                      </div>

                      <button
                        id="btn-add-ticket-chamados"
                        onClick={() => { setEditingTicket(null); setIsFormOpen(true); }}
                        className="bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-sm whitespace-nowrap"
                      >
                        <PlusCircle className="w-4 h-4" />
                        Registrar Atendimento
                      </button>
                    </div>
                  </div>

                  {/* Filter Toolbar Component */}
                  <SearchAndFilters 
                    technicians={technicians} 
                    isAdmin={isAdmin} 
                    onFilterChange={(newFilters) => setFilters(newFilters)} 
                    currentFilters={filters}
                    currentUser={currentUser}
                  />

                  {/* Active count and list */}
                  <div className="flex justify-between items-center text-xs text-slate-500">
                    <span>Apresentando <span className="font-bold text-slate-700">{filteredTickets.length}</span> chamados filtrados</span>
                    <span className="italic">Total na base: {viewableTickets.length}</span>
                  </div>

                  {filteredTickets.length === 0 ? (
                    /* Blank Slate Panel */
                    <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 shadow-sm space-y-4 text-slate-500" id="blank-slate">
                      <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-400 border border-slate-200">
                        <Search className="w-5 h-5" />
                      </div>
                      <div className="max-w-md mx-auto space-y-1">
                        <h3 className="font-bold text-slate-700 text-sm">Nenhum atendimento correspondente</h3>
                        <p className="text-xs text-slate-400">Verifique os filtros de pesquisa ativa, o status selecionado ou selecione outro período da consulta.</p>
                      </div>
                      <button
                        onClick={() => setFilters({ searchQuery: '', technicianId: '', status: '', date: '', minDuration: '' })}
                        className="text-xs text-cyan-600 hover:text-cyan-700 font-bold underline cursor-pointer"
                      >
                        Limpar Todos os Filtros
                      </button>
                    </div>
                  ) : viewMode === 'grid' ? (
                    /* Interactive Cards List */
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4" id="tickets-cards-grid">
                      {filteredTickets.map((ticket) => {
                        const statusObj = STATUS_LABELS[ticket.status] || { label: ticket.status, theme: 'bg-slate-100 text-slate-755' };
                        const ticketDateObj = new Date(ticket.dateTime);
                        const displayDate = ticketDateObj.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
                        const displayTime = ticketDateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

                        const isOwner = ticket.technicianId === currentUser.id;
                        const canModify = true; // Permite que técnicos alterem chamados de outros, como se fossem deles

                        let durationText = "";
                        let durationColor = "";
                        const diffMins = (new Date(ticket.finishedAt || new Date().toISOString()).getTime() - new Date(ticket.dateTime).getTime()) / 60000;
                        if (ticket.status === 'EM_ANDAMENTO') {
                          durationText = `Aberto: ${formatDuration(ticket.dateTime, new Date().toISOString())}`;
                          if (diffMins > 120) durationColor = 'text-rose-600 dark:text-rose-500 font-black text-[12px]';
                          else if (diffMins > 60) durationColor = 'text-amber-500 dark:text-amber-400 font-bold text-[11px]';
                          else durationColor = 'text-blue-500 dark:text-blue-400 font-medium text-[11px]';
                        } else {
                          durationText = `Duração: ${formatDuration(ticket.dateTime, ticket.finishedAt || new Date().toISOString())}`;
                          durationColor = 'text-emerald-600 dark:text-emerald-500 font-bold text-[11px]';
                        }

                        // Left border accent color depending on ticket status (SLA)
                        const borderLeftClass = ticket.status === 'RESOLVIDO'
                          ? 'border-l-4 border-l-emerald-500 shadow-emerald-500/5'
                          : 'border-l-4 border-l-amber-500 shadow-amber-500/5';

                        return (
                          <div 
                            key={ticket.id}
                            id={`ticket-card-${ticket.id}`}
                            className={`bg-white dark:bg-[#1E293B] rounded-xl border border-slate-200/90 dark:border-slate-800/80 ${borderLeftClass} hover:border-cyan-400/40 dark:hover:border-cyan-500/30 hover:shadow-premium-hover hover:-translate-y-0.5 shadow-premium transition-all duration-300 p-6 flex flex-col justify-between space-y-4 relative overflow-hidden group`}
                          >
                            <div className="space-y-4">
                              {/* Header tags */}
                              <div className="flex justify-between items-center gap-2.5">
                                <div className="flex items-center gap-1.5">
                                  <span className="font-mono text-[13.5px] bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-black px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-1.5 notranslate" translate="no">
                                    CHAMADO: <span className="text-cyan-600 dark:text-cyan-450 dark:text-cyan-400 font-black text-[16px]">{ticket.id}</span>
                                  </span>
                                </div>
                                
                                <span className={`px-3 py-1 rounded-full text-[11px] font-black uppercase border tracking-wider ${statusObj.theme}`}>
                                  {statusObj.label}
                                </span>
                              </div>

                              {/* Client and Company info */}
                              <div className="space-y-1.5">
                                <h3 className="text-[18px] font-black text-slate-850 dark:text-slate-100 leading-tight uppercase tracking-tight group-hover:text-cyan-600 dark:group-hover:text-cyan-400 transition-colors">{ticket.companyName}</h3>
                                <div className="text-[13.5px] text-slate-550 dark:text-slate-400 flex items-center gap-1.5">
                                  <span className="font-semibold text-slate-400 dark:text-slate-500">Cliente:</span>
                                  <span className="font-black text-slate-700 dark:text-slate-300">{ticket.clientName}</span>
                                </div>
                              </div>

                              {/* Problem label */}
                              <div className="p-3.5 bg-slate-50/80 dark:bg-slate-800 rounded-xl border border-slate-150/70 dark:border-slate-700">
                                <div className="text-[11px] font-bold text-slate-500 dark:text-slate-300 uppercase tracking-widest block mb-1">Problema Relatado</div>
                                <p className="text-[14px] text-slate-900 dark:text-sky-355 dark:text-sky-300 font-bold leading-snug">{ticket.problemCategory}</p>
                              </div>

                              {/* Conditional Solution Details */}
                              {ticket.status === 'RESOLVIDO' && ticket.solutionCategory && (
                                <div className="p-3.5 bg-emerald-50/30 dark:bg-emerald-950/10 rounded-xl border border-emerald-100/50 dark:border-emerald-900/20">
                                  <div className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest block mb-1">Solução Aplicada</div>
                                  <p className="text-[14px] text-slate-800 dark:text-slate-100 font-bold leading-snug">{ticket.solutionCategory}</p>
                                </div>
                              )}

                              {/* Observations Snip if available */}
                              {ticket.observations && (
                                <div className="whitespace-pre-line text-[14px] text-slate-500 dark:text-slate-400 bg-slate-50/45 dark:bg-slate-900/30 p-3.5 rounded-xl border border-slate-100 dark:border-slate-800/40 italic leading-relaxed">
                                  "{ticket.observations}"
                                </div>
                              )}

                              {/* Transfer State Badge on card */}
                              {ticket.transfer && (
                                <div className="space-y-1 pt-1.5">
                                  {ticket.transfer.status === 'PENDENTE' && (
                                    <div className="text-[11.5px] font-semibold text-sky-900 bg-sky-100 border border-sky-300 rounded-xl p-3 flex items-center gap-2.5" id={`card-transfer-pending-${ticket.id}`}>
                                      <span className="w-2.5 h-2.5 bg-sky-500 rounded-full animate-ping shrink-0" />
                                      <span>🕒 Transferência pendente para: <strong className="text-sky-950">{ticket.transfer.toName}</strong></span>
                                    </div>
                                  )}
                                  
                                  {ticket.transfer.status === 'ACEITO' && (
                                    <div className="text-[11.5px] font-semibold text-emerald-900 bg-emerald-100 border border-emerald-300 rounded-xl p-3 flex items-center gap-2" id={`card-transfer-accepted-${ticket.id}`}>
                                      <span>🔄 Transferido de: <strong className="text-emerald-950">{ticket.transfer.fromName}</strong></span>
                                    </div>
                                  )}
                                  
                                  {ticket.transfer.status === 'RECUSADO' && ticket.transfer.fromId === currentUser.id && (
                                    <div className="text-[11.5px] font-semibold text-rose-900 bg-rose-100 border border-rose-300 rounded-xl p-3 flex flex-col gap-2" id={`card-transfer-refused-${ticket.id}`}>
                                      <div className="flex items-center justify-between">
                                        <span>❌ Recusado por: <strong className="text-rose-950">{ticket.transfer.toName}</strong></span>
                                        <button 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            handleClearTransferRefusedMessage(ticket.id);
                                          }} 
                                          className="text-[10px] text-slate-600 hover:text-slate-900 underline font-bold cursor-pointer"
                                        >
                                          Redefinir
                                        </button>
                                      </div>
                                      <p className="text-[10px] text-rose-800 italic">Motivo: "{ticket.transfer.reason}"</p>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>

                            {/* Footer card containing technician identifier and modifications */}
                            <div className="pt-3.5 border-t border-slate-100 flex justify-between items-center gap-2">
                              <div className="space-y-0.5">
                                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wide">Vinculado a:</p>
                                <span className="font-black text-slate-700 dark:text-slate-300 block text-[13.5px] truncate max-w-[155px]" title={ticket.technicianName}>
                                  {ticket.technicianName}
                                </span>
                                <span className="text-[11px] text-slate-450 dark:text-slate-400 block font-mono font-medium">
                                  {displayDate} às {displayTime}
                                </span>
                                <span className={`block font-mono ${durationColor}`}>
                                  {durationText}
                                </span>
                              </div>

                              <div className="flex items-center gap-1 shrink-0">
                                {ticket.status === 'EM_ANDAMENTO' ? (
                                  <>
                                    {canModify && (
                                      <button
                                        id={`btn-edit-${ticket.id}`}
                                        onClick={() => triggerEdit(ticket)}
                                        className="p-2 text-cyan-600 hover:text-cyan-700 hover:bg-cyan-50 dark:hover:bg-cyan-950/30 rounded-xl transition-all cursor-pointer"
                                        title="Editar Atendimento"
                                      >
                                        <Edit3 className="w-4.5 h-4.5" />
                                      </button>
                                    )}
                                    {canModify && (
                                      <button
                                        id={`btn-finalize-${ticket.id}`}
                                        onClick={() => initiateTicketFinalize(ticket)}
                                        className="p-2 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 rounded-xl transition-all cursor-pointer"
                                        title="Finalizar Chamado"
                                      >
                                        <CheckCircle2 className="w-4.5 h-4.5" />
                                      </button>
                                    )}
                                    {isAdmin && (
                                      <button
                                        id={`btn-delete-${ticket.id}`}
                                        onClick={() => setTicketToDelete(ticket)}
                                        className="p-2 text-rose-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-955/35 rounded-xl transition-all cursor-pointer"
                                        title="Excluir Atendimento"
                                      >
                                        <Trash2 className="w-4.5 h-4.5" />
                                      </button>
                                    )}
                                  </>
                                ) : (
                                  <>
                                    <button
                                      id={`btn-detail-${ticket.id}`}
                                      onClick={() => setActiveDetailTicket(ticket)}
                                      className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                                      title="Ver Detalhes do Chamado"
                                    >
                                      <Info className="w-4.5 h-4.5" />
                                    </button>
    
                                    {isAdmin && (
                                      <button
                                        id={`btn-edit-${ticket.id}`}
                                        onClick={() => triggerEdit(ticket)}
                                        className="p-2 text-cyan-600 hover:text-cyan-700 hover:bg-cyan-50 rounded-xl transition-all cursor-pointer"
                                        title="Editar Atendimento"
                                      >
                                        <Edit3 className="w-4.5 h-4.5" />
                                      </button>
                                    )}
    
                                    {/* Delete button (restricted admin only) */}
                                    {isAdmin && (
                                      <button
                                        id={`btn-delete-${ticket.id}`}
                                        onClick={() => setTicketToDelete(ticket)}
                                        className="p-2 text-rose-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-955/35 rounded-xl transition-all cursor-pointer"
                                        title="Excluir Atendimento"
                                      >
                                        <Trash2 className="w-4.5 h-4.5" />
                                      </button>
                                    )}
                                  </>
                                )}
                              </div>
                            </div>

                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    /* Compact List View */
                    <div className="bg-white dark:bg-[#1E293B] rounded-2xl border border-slate-200/90 dark:border-slate-800/80 shadow-premium overflow-hidden" id="tickets-compact-list">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-850 text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                              <th className="py-3.5 px-4 font-mono w-[80px] notranslate" translate="no">ID</th>
                              <th className="py-3.5 px-4">Status</th>
                              <th className="py-3.5 px-4">Empresa / Cliente</th>
                              <th className="py-3.5 px-4">Aparelho / Modelo</th>
                              <th className="py-3.5 px-4">Problema Relatado</th>
                              <th className="py-3.5 px-4">Técnico</th>
                              <th className="py-3.5 px-4">Data/Hora</th>
                              <th className="py-3.5 px-4 text-right w-[140px]">Ações</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-700 dark:text-slate-300">
                            {filteredTickets.map((ticket) => {
                              const statusObj = STATUS_LABELS[ticket.status] || { label: ticket.status, theme: 'bg-slate-100 text-slate-755' };
                              const ticketDateObj = new Date(ticket.dateTime);
                              const displayDate = ticketDateObj.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
                              const displayTime = ticketDateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

                              const isOwner = ticket.technicianId === currentUser.id;
                              const canModify = true; // Permite que técnicos alterem chamados de outros, como se fossem deles

                              let durationText = "";
                              let durationColor = "";
                              const diffMins = (new Date(ticket.finishedAt || new Date().toISOString()).getTime() - new Date(ticket.dateTime).getTime()) / 60000;
                              if (ticket.status === 'EM_ANDAMENTO') {
                                durationText = formatDuration(ticket.dateTime, new Date().toISOString());
                                if (diffMins > 120) durationColor = 'text-rose-600 dark:text-rose-500 font-black';
                                else if (diffMins > 60) durationColor = 'text-amber-500 dark:text-amber-400 font-bold';
                                else durationColor = 'text-blue-500 dark:text-blue-400 font-medium';
                              } else {
                                durationText = formatDuration(ticket.dateTime, ticket.finishedAt || new Date().toISOString());
                                durationColor = 'text-emerald-600 dark:text-emerald-500 font-bold';
                              }

                              // SLA accent left border on the row
                              const leftBorderColor = ticket.status === 'RESOLVIDO'
                                ? 'border-l-4 border-l-emerald-500'
                                : 'border-l-4 border-l-amber-500';

                              return (
                                <tr 
                                  key={ticket.id}
                                  id={`ticket-row-${ticket.id}`}
                                  className={`hover:bg-slate-50/55 dark:hover:bg-slate-800/40 transition-colors ${leftBorderColor}`}
                                >
                                  <td className="py-3 px-4 whitespace-nowrap">
                                    <span className="font-mono text-[10.5px] bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-extrabold px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-800 notranslate" translate="no">
                                      {ticket.id}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4 whitespace-nowrap">
                                    <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase border tracking-wider ${statusObj.theme}`}>
                                      {statusObj.label}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4">
                                    <div className="font-extrabold text-slate-850 dark:text-slate-100 truncate max-w-[160px]" title={ticket.companyName}>
                                      {ticket.companyName}
                                    </div>
                                    <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-[150px]" title={ticket.clientName}>
                                      {ticket.clientName}
                                    </div>
                                  </td>
                                  <td className="py-3 px-4">
                                    <span className="text-[11px] font-bold text-slate-600 dark:text-slate-300">
                                      {['Informações sobre produtos', 'Falha de funcionamento', 'Instalação'].includes(ticket.problemCategory) ? ticket.productInfoCause || 'N/A' : (ticket.deviceModel || 'N/A')}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4">
                                    <div className="font-semibold text-slate-800 dark:text-slate-200 line-clamp-1 max-w-[200px]" title={ticket.problemCategory}>
                                      {ticket.problemCategory}
                                    </div>
                                    {ticket.transfer && ticket.transfer.status === 'PENDENTE' && (
                                      <span className="text-[9.5px] text-sky-600 dark:text-sky-400 font-bold block">
                                        🕒 Trf. Pendente → {ticket.transfer.toName}
                                      </span>
                                    )}
                                  </td>
                                  <td className="py-3 px-4 whitespace-nowrap">
                                    <span className="font-extrabold text-slate-700 dark:text-slate-300 text-[11px]">
                                      {ticket.technicianName}
                                    </span>
                                  </td>
                                  <td className="py-3 px-4 whitespace-nowrap text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                                    <div className="flex flex-col gap-0.5">
                                      <span>{displayDate} <span className="text-[10px] text-slate-400 dark:text-slate-500">{displayTime}</span></span>
                                      {durationText && (
                                        <span className={`text-[11px] ${durationColor}`} title="Duração / Tempo Aberto">
                                          {durationText}
                                        </span>
                                      )}
                                    </div>
                                  </td>
                                  <td className="py-3 px-4 whitespace-nowrap text-right">
                                    <div className="flex items-center justify-end gap-1">
                                      {ticket.status === 'EM_ANDAMENTO' ? (
                                        <>
                                          {canModify && (
                                            <button
                                              id={`btn-row-edit-${ticket.id}`}
                                              onClick={() => triggerEdit(ticket)}
                                              className="p-1.5 text-cyan-600 hover:text-cyan-705 dark:hover:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-955/35 rounded-lg transition-all cursor-pointer"
                                              title="Editar Atendimento"
                                            >
                                              <Edit3 className="w-4 h-4" />
                                            </button>
                                          )}
                                          {canModify && (
                                            <button
                                              id={`btn-row-finalize-${ticket.id}`}
                                              onClick={() => initiateTicketFinalize(ticket)}
                                              className="p-1.5 text-emerald-600 hover:text-emerald-705 dark:hover:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-955/35 rounded-lg transition-all cursor-pointer"
                                              title="Finalizar Chamado"
                                            >
                                              <CheckCircle2 className="w-4 h-4" />
                                            </button>
                                          )}
                                          {isAdmin && (
                                            <button
                                              id={`btn-row-delete-${ticket.id}`}
                                              onClick={() => setTicketToDelete(ticket)}
                                              className="p-1.5 text-rose-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-955/35 rounded-lg transition-all cursor-pointer"
                                              title="Excluir Atendimento"
                                            >
                                              <Trash2 className="w-4 h-4" />
                                            </button>
                                          )}
                                        </>
                                      ) : (
                                        <>
                                          <button
                                            id={`btn-row-detail-${ticket.id}`}
                                            onClick={() => setActiveDetailTicket(ticket)}
                                            className="p-1.5 text-slate-400 hover:text-slate-705 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                                            title="Ver Detalhes do Chamado"
                                          >
                                            <Info className="w-4 h-4" />
                                          </button>
    
                                          {isAdmin && (
                                            <button
                                              id={`btn-row-edit-${ticket.id}`}
                                              onClick={() => triggerEdit(ticket)}
                                              className="p-1.5 text-cyan-600 hover:text-cyan-705 dark:hover:text-cyan-400 hover:bg-cyan-50 dark:hover:bg-cyan-955/35 rounded-lg transition-all cursor-pointer"
                                              title="Editar Atendimento"
                                            >
                                              <Edit3 className="w-4 h-4" />
                                            </button>
                                          )}
    
                                          {isAdmin && (
                                            <button
                                              id={`btn-row-delete-${ticket.id}`}
                                              onClick={() => setTicketToDelete(ticket)}
                                              className="p-1.5 text-rose-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-955/35 rounded-lg transition-all cursor-pointer"
                                              title="Excluir Atendimento"
                                            >
                                              <Trash2 className="w-4 h-4" />
                                            </button>
                                          )}
                                        </>
                                      )}
                                    </div>
                                  </td>
                                </tr>
                              );
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                </div>
              )}

            </div>
          )}

        </div>

      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-5 text-center text-xs text-slate-400 font-medium" id="footer">
        <p>© 2026 UPX Tecnologia Integrada de Conectividade & Redes. Todos os direitos reservados aos técnicos credenciados.</p>
        <p className="text-[10px] text-slate-300 mt-1">SGA - Sistema de Gestão de Atendimentos • Versão de Distribuição Homologada v3.2</p>
      </footer>

      {/* MODAL / BOTTOM SHEET OVERLAY: Ticket Full Inspector View */}
      <AnimatePresence>
        {activeDetailTicket && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4" id="ticket-detail-modal">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white w-full max-w-2xl rounded-2xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col justify-between"
            >
              {/* Header */}
              <div className="bg-slate-900 px-6 py-4 text-white flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs bg-slate-800 text-cyan-400 px-2.5 py-1 rounded-md font-bold notranslate" translate="no">
                                                    Chamado: #{activeDetailTicket.id}
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${STATUS_LABELS[activeDetailTicket.status]?.theme}`}>
                    {STATUS_LABELS[activeDetailTicket.status]?.label}
                  </span>
                </div>
                <button 
                  id="btn-close-detail"
                  onClick={() => setActiveDetailTicket(null)}
                  className="p-1 px-2.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors cursor-pointer text-sm font-bold"
                >
                  ✕
                </button>
              </div>

              {/* Body */}
              <div className="p-6 md:p-8 space-y-5 text-slate-750">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase block">Empresa Cliente</span>
                    <p className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
                      <Building className="w-4 h-4 text-slate-500 shrink-0" />
                      {activeDetailTicket.companyName}
                    </p>
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">Contato Cliente</span>
                    <p className="text-sm font-semibold text-slate-800 flex items-center gap-1.5">
                      <UserCheck className="w-4 h-4 text-slate-400 shrink-0" />
                      {activeDetailTicket.clientName}
                    </p>
                    {activeDetailTicket.clientPhone && (
                      <p className="text-[11px] font-medium text-slate-500 mt-0.5 ml-5.5">
                        {activeDetailTicket.clientPhone}
                      </p>
                    )}
                  </div>
                </div>

                <div className="py-3 border-t border-b border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">Data de Abertura</span>
                    <p className="text-xs font-medium text-slate-800 flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-slate-400 shrink-0" />
                      {new Date(activeDetailTicket.dateTime).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}
                    </p>
                  </div>
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">Técnico Encarregado</span>
                    <p className="text-xs font-semibold text-cyan-700 flex items-center gap-1.5">
                      <Wrench className="w-4 h-4 text-cyan-600 shrink-0" />
                      {activeDetailTicket.technicianName}
                    </p>
                  </div>
                  {activeDetailTicket.finishedAt && (
                    <>
                      <div className="space-y-0.5">
                        <span className="text-[10px] font-bold text-slate-400 block uppercase">Término do Chamado</span>
                        <p className="text-xs font-medium text-slate-800 flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                          {new Date(activeDetailTicket.finishedAt).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}
                        </p>
                      </div>
                      <div className="space-y-0.5">
                        <span className="text-[10px] font-bold text-slate-400 block uppercase">Duração do Atendimento</span>
                        <p className="text-xs font-medium text-slate-800 flex items-center gap-1.5">
                          <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                          {formatDuration(activeDetailTicket.dateTime, activeDetailTicket.finishedAt)}
                        </p>
                      </div>
                    </>
                  )}
                </div>

                {/* Problem category block */}
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Problema Diagnósticado</span>
                  <div className="p-3 bg-rose-50/40 rounded-xl border border-rose-100 flex items-start gap-2.5">
                    <AlertTriangle className="w-4.5 h-4.5 text-rose-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-bold text-slate-850">{activeDetailTicket.problemCategory}</p>
                      {['Informações sobre produtos', 'Falha de funcionamento', 'Instalação'].includes(activeDetailTicket.problemCategory) && activeDetailTicket.productInfoCause && (
                        <p className="text-xs text-slate-600 dark:text-slate-400 font-semibold mt-1">Causa: {activeDetailTicket.productInfoCause}</p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Solution category block if solved */}
                {activeDetailTicket.status === 'RESOLVIDO' && activeDetailTicket.solutionCategory && (
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">Ação Resolutiva Aplicada</span>
                    <div className="p-3 bg-emerald-50/40 rounded-xl border border-emerald-100 flex items-start gap-2.5">
                      <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500 shrink-0 mt-0.5" />
                      <div>
                        <p className="text-xs font-bold text-slate-850">{activeDetailTicket.solutionCategory}</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* Observations */}
                <div className="space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Observações Operacionais / Prontuário</span>
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-700 font-medium leading-relaxed leading-5 italic min-h-[60px]">
                    {activeDetailTicket.observations ? (
                      `"${activeDetailTicket.observations}"`
                    ) : (
                      "Nenhuma observação técnica adicional registrada para este chamado corporativo."
                    )}
                  </div>
                </div>

                {/* Transfer history display within details */}
                {activeDetailTicket.transfer && (
                  <div className="space-y-1 mt-3">
                    <span className="text-[10px] font-bold text-slate-400 block uppercase">Histórico de Transferência</span>
                    <div className={`p-4 rounded-xl border text-xs leading-relaxed ${
                      activeDetailTicket.transfer.status === 'PENDENTE' ? 'bg-amber-50/50 border-amber-200 text-amber-900' :
                      activeDetailTicket.transfer.status === 'ACEITO' ? 'bg-cyan-50/55 border-cyan-200 text-cyan-900' :
                      'bg-rose-50/40 border-rose-200 text-rose-900'
                    }`} id="detail-transfer-box-info">
                      <div className="flex items-center gap-2 mb-1">
                        <ArrowRightLeft className="w-4 h-4 shrink-0" />
                        <span className="font-bold">
                          {activeDetailTicket.transfer.status === 'PENDENTE' ? 'Solicitação de Transferência Pendente' :
                           activeDetailTicket.transfer.status === 'ACEITO' ? 'Transferência Concluída com Sucesso' :
                           'Transferência Recusada'}
                        </span>
                      </div>
                      <p className="font-medium text-slate-700">
                        De: <span className="font-semibold text-slate-800">{activeDetailTicket.transfer.fromName}</span>
                      </p>
                      <p className="font-medium text-slate-700">
                        Para: <span className="font-semibold text-slate-800">{activeDetailTicket.transfer.toName}</span>
                      </p>
                      <p className="mt-1 font-semibold">
                        Motivo de Transferência:
                      </p>
                      <p className="italic text-slate-650 bg-white/60 p-2 rounded mt-0.5 border border-slate-100">
                        "{activeDetailTicket.transfer.reason}"
                      </p>
                      {activeDetailTicket.transfer.status === 'PENDENTE' && activeDetailTicket.transfer.toId === currentUser.id && (
                        <div className="flex gap-2 mt-3 pt-2.5 border-t border-amber-200/60">
                          <button
                            onClick={() => handleAcceptTransfer(activeDetailTicket.id)}
                            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg text-xs cursor-pointer shadow-xs"
                          >
                            ✓ Aceitar Atendimento
                          </button>
                          <button
                            onClick={() => handleDeclineTransfer(activeDetailTicket.id)}
                            className="bg-slate-250 hover:bg-rose-50 hover:text-rose-600 text-slate-705 font-bold px-3 py-1.5 rounded-lg text-xs cursor-pointer"
                          >
                            Recusar
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                )}

              </div>

              {/* Footer */}
              <div className="bg-slate-50 dark:bg-slate-850 border-t border-slate-100 dark:border-slate-800 p-4 px-6 flex justify-end gap-2">

                <button
                  id="btn-close-detail-footer"
                  onClick={() => setActiveDetailTicket(null)}
                  className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-650 dark:text-slate-300 hover:bg-slate-105 dark:hover:bg-slate-800 font-bold text-xs transition-colors cursor-pointer"
                >
                  Fechar Visualização
                </button>
                
                {true && (
                  <div className="flex gap-2">
                    {activeDetailTicket.status !== 'RESOLVIDO' && (
                      <button
                        type="button"
                        onClick={() => initiateTicketFinalize(activeDetailTicket)}
                        className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-sm shadow-emerald-900/10"
                      >
                        Finalizar Chamado
                      </button>
                    )}
                    {isAdmin && (
                      <button
                        id="btn-delete-detail-footer"
                        type="button"
                        onClick={() => setTicketToDelete(activeDetailTicket)}
                        className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-550 hover:bg-rose-500 text-white font-bold text-xs transition-colors cursor-pointer shadow-sm shadow-rose-900/10"
                      >
                        Excluir Chamado
                      </button>
                    )}
                    {(activeDetailTicket.status !== 'RESOLVIDO' || isAdmin) && (
                      <button
                        id="btn-edit-detail-footer"
                        type="button"
                        onClick={() => triggerEdit(activeDetailTicket)}
                        className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs transition-colors cursor-pointer"
                      >
                        Editar Atendimento
                      </button>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* TICKET FINALIZE MODAL */}
      <AnimatePresence>
        {ticketToFinalize && (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="finalize-ticket-modal">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative space-y-5"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl text-emerald-500 shrink-0">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div className="space-y-1.5 flex-1 mt-1">
                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 leading-tight">
                    Finalizar Chamado #{ticketToFinalize.id}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Insira a solução aplicada e confirme o horário de término.
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Descrição da Solução Aplicada
                  </label>
                  <select
                    value={finalizeSolutionCategory}
                    onChange={(e) => setFinalizeSolutionCategory(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 px-4 py-2.5 rounded-xl text-sm focus:outline-none focus:border-emerald-500 dark:text-slate-100 cursor-pointer"
                  >
                    {SOLUTION_CATEGORIES.map((solution) => (
                      <option key={solution} value={solution} className="dark:bg-slate-900">
                        {solution}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                    Horário de Término
                  </label>
                  <input
                    type="time"
                    value={finalizeTime}
                    disabled
                    className="w-full bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 px-4 py-2.5 rounded-xl text-sm focus:outline-none dark:text-slate-400 cursor-not-allowed opacity-80"
                  />
                </div>
              </div>

              <div className="pt-4 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setTicketToFinalize(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-slate-250 dark:border-slate-700 text-slate-650 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={confirmTicketFinalize}
                  className="px-5 py-2 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white shadow-md transition-colors cursor-pointer"
                >
                  Confirmar Finalização
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* TICKET DELETION CONFIRMATION MODAL */}
      <AnimatePresence>
        {ticketToDelete && (
          <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="delete-ticket-confirm-modal">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl relative space-y-5"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 bg-rose-50 dark:bg-rose-950/30 rounded-xl text-rose-500 shrink-0">
                  <Trash2 className="w-6 h-6" />
                </div>
                <div className="space-y-1.5 flex-1">
                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 leading-tight">
                    Confirmar Exclusão de Chamado?
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    Você está prestes a excluir permanentemente o chamado <strong className="text-slate-755 text-slate-700 dark:text-slate-200">#{ticketToDelete.id}</strong> estruturado para <strong className="text-slate-755 text-slate-700 dark:text-slate-200">{ticketToDelete.companyName}</strong>. Esta ação não poderá ser desfeita.
                  </p>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2.5">
                <button
                  type="button"
                  id="btn-cancel-delete"
                  onClick={() => setTicketToDelete(null)}
                  className="px-4 py-2 rounded-xl text-xs font-bold border border-slate-250 dark:border-slate-700 text-slate-650 dark:text-slate-350 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  id="btn-confirm-delete"
                  onClick={confirmTicketDelete}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-rose-600 hover:bg-rose-500 text-white transition-colors cursor-pointer shadow-md shadow-rose-900/10"
                >
                  Sim, Excluir Atendimento
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
