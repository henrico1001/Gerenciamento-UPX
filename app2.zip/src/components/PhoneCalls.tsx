import { useState, useEffect, useMemo, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PhoneCall, User } from '../types';
import { onSnapshot, collection, doc, setDoc, deleteDoc, updateDoc, db } from '../lib/api';
import { 
  Phone, 
  PhoneIncoming, 
  PhoneOutgoing, 
  PlusCircle, 
  Search, 
  Clock, 
  User as UserIcon, 
  Building, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Filter, 
  Calendar, 
  Check, 
  X, 
  Edit3, 
  Trash2,
  ListFilter
} from 'lucide-react';

interface PhoneCallsProps {
  currentUser: User;
  tickets?: any[];
}

export default function PhoneCalls({ currentUser, tickets = [] }: PhoneCallsProps) {
  const [calls, setCalls] = useState<PhoneCall[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Estados de Simulação do Webhook Automático (Integração)
  const [showSimPanel, setShowSimPanel] = useState(true);
  const [simPhone, setSimPhone] = useState('');
  const [simSubject, setSimSubject] = useState('Dúvida sobre andamento de chamado de assistência');
  const [simSuccessMsg, setSimSuccessMsg] = useState<string | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);

  const handleTriggerSimulatedWebhook = async (presetPhone?: string) => {
    setIsSimulating(true);
    setSimSuccessMsg(null);
    try {
      // Use preset or random phone number
      const phoneToUse = presetPhone || simPhone || `(31) 9${Math.floor(1000 + Math.random() * 9000)}-${Math.floor(1000 + Math.random() * 9000)}`;
      
      const res = await fetch('/api/webhooks/voice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          From: phoneToUse,
          subject: simSubject,
          notes: 'Aviso: Chamada automática detectada no telefone e capturada via Webhook API de Integração.'
        })
      });
      
      const data = await res.json();
      if (data.success) {
        setSimSuccessMsg(`Sucesso! Ligação de "${data.data.clientName}" (${data.data.companyName || 'Empresa Nova'}) identificada e catalogada no banco de dados com sucesso!`);
        setTimeout(() => setSimSuccessMsg(null), 8500);
      } else {
        alert("Erro na integração do webhook: " + data.error);
      }
    } catch (err: any) {
      console.error("Falha na simulação do webhook:", err);
      alert("Erro ao comunicar com a API do Webhook local. Garanta que o servidor esteja rodando.");
    } finally {
      setIsSimulating(false);
    }
  };

  // Form states
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingCall, setEditingCall] = useState<PhoneCall | null>(null);
  
  // New/Edit Call fields
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [direction, setDirection] = useState<'RECEBIDA' | 'EFETUADA'>('RECEBIDA');
  const [recipientName, setRecipientName] = useState('');
  const [subject, setSubject] = useState('');
  const [status, setStatus] = useState<'ATENDIDA_RESOLVIDA' | 'PENDENTE_RETORNO' | 'RECADO_ANOTADO'>('ATENDIDA_RESOLVIDA');
  const [notes, setNotes] = useState('');
  const [customDateTime, setCustomDateTime] = useState('');

  // Search and Advanced Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [directionFilter, setDirectionFilter] = useState<string>('TODOS');
  const [statusFilter, setStatusFilter] = useState<string>('TODOS');
  const [dateFilter, setDateFilter] = useState<string>('');

  // Load phone calls from API using our simulated onSnapshot polling
  useEffect(() => {
    setLoading(true);
    const unsub = onSnapshot(collection(db, 'phone_calls'), (snap: any) => {
      if (snap && snap.docs) {
        const callsData = snap.docs.map((d: any) => d.data() as PhoneCall);
        // Sort by dateTime desc
        callsData.sort((a, b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime());
        setCalls(callsData);
      }
      setLoading(false);
    }, (err) => {
      console.error("Error fetching phone calls:", err);
      setError("Erro ao carregar dados do provedor de chamadas.");
      setLoading(false);
    });

    return () => {
      unsub();
    };
  }, []);

  // Pre-fill form on edit mode
  useEffect(() => {
    if (editingCall) {
      setClientName(editingCall.clientName || '');
      setClientPhone(editingCall.clientPhone || '');
      setCompanyName(editingCall.companyName || '');
      setDirection(editingCall.direction || 'RECEBIDA');
      setRecipientName(editingCall.recipientName || '');
      setSubject(editingCall.subject || '');
      setStatus(editingCall.status || 'ATENDIDA_RESOLVIDA');
      setNotes(editingCall.notes || '');
      
      // format to local datetime string: YYYY-MM-DDTHH:MM
      const dateObj = new Date(editingCall.dateTime);
      if (!isNaN(dateObj.getTime())) {
        const tzoffset = dateObj.getTimezoneOffset() * 60000; // offset in milliseconds
        const localISOTime = (new Date(dateObj.getTime() - tzoffset)).toISOString().slice(0, 16);
        setCustomDateTime(localISOTime);
      } else {
        setCustomDateTime('');
      }
    } else {
      resetForm();
    }
  }, [editingCall]);

  const resetForm = () => {
    setClientName('');
    setClientPhone('');
    setCompanyName('');
    setDirection('RECEBIDA');
    setRecipientName('Gestor'); // Default recipient name can be the Manager
    setSubject('');
    setStatus('ATENDIDA_RESOLVIDA');
    setNotes('');
    
    // Set current date/time in local format
    const now = new Date();
    const tzoffset = now.getTimezoneOffset() * 60000;
    const localISOTime = (new Date(now.getTime() - tzoffset)).toISOString().slice(0, 16);
    setCustomDateTime(localISOTime);
  };

  const handleOpenNewForm = () => {
    setEditingCall(null);
    resetForm();
    setIsFormOpen(true);
  };

  const handleSaveCall = async (e: FormEvent) => {
    e.preventDefault();
    if (!clientName.trim() || !subject.trim()) {
      alert("Por favor, preencha o Nome do Cliente e o Assunto/Motivo.");
      return;
    }

    try {
      const callId = editingCall ? editingCall.id : `call_${Date.now()}`;
      
      let finalDateTime = new Date().toISOString();
      if (customDateTime) {
        const dObj = new Date(customDateTime);
        if (!isNaN(dObj.getTime())) {
          finalDateTime = dObj.toISOString();
        }
      }

      const callData: PhoneCall = {
        id: callId,
        clientName: clientName.trim(),
        clientPhone: clientPhone.trim() || undefined,
        companyName: companyName.trim() || undefined,
        dateTime: finalDateTime,
        direction,
        recipientName: recipientName.trim() || undefined,
        subject: subject.trim(),
        status,
        notes: notes.trim() || undefined,
        loggedById: editingCall ? editingCall.loggedById : currentUser.id,
        loggedByName: editingCall ? editingCall.loggedByName : currentUser.name
      };

      await setDoc(doc(db, 'phone_calls', callId), callData);
      
      setIsFormOpen(false);
      setEditingCall(null);
      resetForm();
    } catch (err) {
      console.error("Error saving call log:", err);
      alert("Houve um erro ao enviar os dados para o MySQL.");
    }
  };

  const handleDeleteCall = async (id: string) => {
    if (confirm("Tem certeza que deseja excluir permanentemente este registro de ligação?")) {
      try {
        await deleteDoc(doc(db, 'phone_calls', id));
      } catch (err) {
        console.error("Error deleting call log:", err);
        alert("Não foi possível excluir o registro.");
      }
    }
  };

  // List processing (searching & filtering)
  const filteredCalls = useMemo(() => {
    return calls.filter(call => {
      // 1. Search Query
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const clientMatch = call.clientName?.toLowerCase().includes(q);
        const companyMatch = call.companyName?.toLowerCase().includes(q);
        const phoneMatch = call.clientPhone?.includes(q);
        const subjectMatch = call.subject?.toLowerCase().includes(q);
        const recMatch = call.recipientName?.toLowerCase().includes(q);
        if (!clientMatch && !companyMatch && !phoneMatch && !subjectMatch && !recMatch) {
          return false;
        }
      }

      // 2. Direction filter
      if (directionFilter !== 'TODOS' && call.direction !== directionFilter) {
        return false;
      }

      // 3. Status filter
      if (statusFilter !== 'TODOS' && call.status !== statusFilter) {
        return false;
      }

      // 4. Date filter
      if (dateFilter) {
        const cDate = new Date(call.dateTime);
        const formattedDate = `${cDate.getFullYear()}-${String(cDate.getMonth() + 1).padStart(2, '0')}-${String(cDate.getDate()).padStart(2, '0')}`;
        if (formattedDate !== dateFilter) {
          return false;
        }
      }

      return true;
    });
  }, [calls, searchQuery, directionFilter, statusFilter, dateFilter]);

  // Statistics Computations
  const stats = useMemo(() => {
    const today = new Date();
    const formattedToday = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
    
    let total = calls.length;
    let receivedToday = 0;
    let pendingReturn = 0;
    let resolved = 0;

    calls.forEach(call => {
      if (call.status === 'PENDENTE_RETORNO') pendingReturn++;
      if (call.status === 'ATENDIDA_RESOLVIDA') resolved++;
      
      const cDate = new Date(call.dateTime);
      const formattedCDate = `${cDate.getFullYear()}-${String(cDate.getMonth() + 1).padStart(2, '0')}-${String(cDate.getDate()).padStart(2, '0')}`;
      if (formattedCDate === formattedToday && call.direction === 'RECEBIDA') {
        receivedToday++;
      }
    });

    return { total, receivedToday, pendingReturn, resolved };
  }, [calls]);

  return (
    <div className="space-y-6 animate-fadeIn" id="phone-calls-component">
      
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-[#1E293B] p-6 rounded-2xl border border-slate-200 dark:border-slate-800/60 shadow-sm">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 tracking-tight flex items-center gap-2">
            <Phone className="w-5.5 h-5.5 text-cyan-600" />
            Controle de Ligações Telefônicas
          </h2>
          <p className="text-xs text-slate-550 dark:text-slate-450 mt-1 leading-relaxed">
            Painel voltado ao Gestor para busca e acompanhamento em tempo real de chamadas recebidas e efetuadas da base central UPX de forma integrada e automática.
          </p>
        </div>
      </div>

      {/* KPI Stats Widgets */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Stat 1 */}
        <div className="bg-white dark:bg-[#1E293B] p-5 rounded-2xl border border-slate-205 dark:border-slate-800/60 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-cyan-500/10 dark:bg-cyan-500/15 rounded-xl text-cyan-500">
            <Phone className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">Total de Ligações</span>
            <span className="text-xl font-bold text-slate-850 dark:text-white">{stats.total}</span>
          </div>
        </div>

        {/* Stat 2 */}
        <div className="bg-white dark:bg-[#1E293B] p-5 rounded-2xl border border-slate-205 dark:border-slate-800/60 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-500/10 dark:bg-amber-500/15 rounded-xl text-amber-500">
            <PhoneIncoming className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">Recebidas Hoje</span>
            <span className="text-xl font-bold text-slate-850 dark:text-white">{stats.receivedToday}</span>
          </div>
        </div>

        {/* Stat 3 */}
        <div className="bg-white dark:bg-[#1E293B] p-5 rounded-2xl border border-slate-205 dark:border-slate-800/60 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-rose-500/10 dark:bg-rose-500/15 rounded-xl text-rose-500 animate-pulse">
            <AlertCircle className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">Pendente de Retorno</span>
            <span className="text-xl font-bold text-rose-600 dark:text-rose-400">{stats.pendingReturn}</span>
          </div>
        </div>

        {/* Stat 4 */}
        <div className="bg-white dark:bg-[#1E293B] p-5 rounded-2xl border border-slate-205 dark:border-slate-800/60 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-500/10 dark:bg-emerald-500/15 rounded-xl text-emerald-50">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
          </div>
          <div>
            <span className="text-[10px] uppercase font-black tracking-wider text-slate-400 block">Resolvidas</span>
            <span className="text-xl font-bold text-emerald-650 dark:text-emerald-400">{stats.resolved}</span>
          </div>
        </div>

      </div>

      {/* Painel de Integração Telefônica & Simulador de Webhook */}
      <div className="bg-white dark:bg-[#1E293B] p-5 rounded-2xl border border-slate-200 dark:border-slate-800/60 shadow-sm space-y-4">
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h3 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500"></span>
              </span>
              Integração Automática - Webhook PABX / Telefonia Virtual
            </h3>
            <p className="text-[11.5px] text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
              O sistema possui uma API Webhook real ativa. Configure o seu telefone virtual ou PABX (ex: Twilio, Asterisk, Zg VoIP) para enviar um evento HTTP POST enviando o número originador para registrar chamadas em tempo real de forma automática.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowSimPanel(!showSimPanel)}
            className="text-xs text-cyan-600 dark:text-cyan-400 font-bold hover:underline cursor-pointer select-none"
          >
            {showSimPanel ? 'Ocultar Simulador de Ligações' : 'Mostrar Simulador de Ligações'}
          </button>
        </div>

        {showSimPanel && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-3 border-t border-slate-200 dark:border-slate-800/60 overflow-hidden"
          >
            {/* Como funciona a Integração de Produção */}
            <div className="lg:col-span-5 bg-slate-50 dark:bg-slate-900/10 p-4 rounded-xl border border-slate-100 dark:border-slate-800 space-y-3">
              <span className="text-[10px] uppercase font-black tracking-wider text-cyan-500 block">Link de Integração do Telefone para o PABX</span>
              
              <div className="bg-slate-100 dark:bg-[#0F172A] p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 font-mono text-[9px] text-slate-650 dark:text-slate-400 break-all select-all">
                POST {window.location.origin}/api/webhooks/voice
              </div>
              
              <div className="space-y-1.5 text-[10.5px] text-slate-500 dark:text-slate-400 leading-relaxed">
                <p>💡 **Identificação Inteligente de Clientes:**</p>
                <p>Ao receber a chamada de um número (ex: <code className="bg-slate-200 dark:bg-slate-800 px-1 rounded font-mono text-xs text-rose-500 font-semibold">(11) 98888-7777</code>), o nosso backend busca instantaneamente se possui esse telefone vinculado a algum chamado aberto na base.</p>
                <p>Se coincidir, o sistema **preenche automaticamente** o Nome do Cliente e a Empresa na ligação sem intervenção do operador!</p>
              </div>
            </div>

            {/* Simulação Interativa (Ambiente de Testes) */}
            <div className="lg:col-span-7 bg-slate-50 dark:bg-slate-900/10 p-4 rounded-xl border border-slate-100 dark:border-slate-800 space-y-4">
              <span className="text-[10px] uppercase font-black tracking-wider text-amber-500 block">Simulador de Chamadas de Entrada</span>
              
              {simSuccessMsg && (
                <div className="p-3 bg-emerald-500/10 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 text-[11px] font-semibold rounded-lg border border-emerald-500/20 animate-fadeIn flex items-center gap-2">
                  <Check className="w-4 h-4 shrink-0 text-emerald-500" />
                  {simSuccessMsg}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="text-[9px] font-bold text-slate-450 uppercase tracking-widest block mb-1">Escolher um Cliente para Simular</label>
                  <select
                    onChange={(e) => {
                      if (e.target.value) {
                        setSimPhone(e.target.value);
                      }
                    }}
                    className="w-full p-2 bg-white dark:bg-[#0F172A] border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-100 focus:ring-1 focus:ring-cyan-500 outline-none"
                  >
                    <option value="">-- Usar Telefone de Amostra --</option>
                    <option value="(31) 98765-4321">Cliente Novo Desconhecido (Sem chamado prévio)</option>
                    {tickets && tickets.filter(t => t.clientPhone).map((t, idx) => (
                      <option key={idx} value={t.clientPhone}>
                        {t.clientName} ({t.clientPhone})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[9px] font-bold text-slate-450 uppercase tracking-widest block mb-1">Telefone Originador (Chamador)</label>
                  <input
                    type="text"
                    value={simPhone}
                    onChange={(e) => setSimPhone(e.target.value)}
                    placeholder="Ex: (31) 98888-1111"
                    className="w-full p-2 bg-white dark:bg-[#0F172A] border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-100 focus:ring-1 focus:ring-cyan-500 outline-none font-mono"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="text-[9px] font-bold text-slate-450 uppercase tracking-widest block mb-1">Assunto / Motivo Inicial Desejado</label>
                  <input
                    type="text"
                    value={simSubject}
                    onChange={(e) => setSimSubject(e.target.value)}
                    className="w-full p-2 bg-white dark:bg-[#0F172A] border border-slate-200 dark:border-slate-800 rounded-lg text-xs text-slate-800 dark:text-slate-100 focus:ring-1 focus:ring-cyan-500 outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-between items-center gap-2 pt-1">
                <span className="text-[9px] text-slate-400 italic">Isso disparará o Webhook de produção para testar</span>
                <button
                  type="button"
                  disabled={isSimulating}
                  onClick={() => handleTriggerSimulatedWebhook()}
                  className="bg-amber-500 hover:bg-amber-400 text-slate-900 font-extrabold text-[11px] px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all select-none cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-md"
                >
                  <PhoneIncoming className="w-3.5 h-3.5 text-slate-900" />
                  {isSimulating ? 'Simulando...' : 'Fazer Chamada Entrar via API'}
                </button>
              </div>

            </div>
          </motion.div>
        )}

      </div>

      {/* Editor & Registration Modal/Section */}
      <AnimatePresence>
        {isFormOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-white dark:bg-[#1E293B] p-6 rounded-2xl border-2 border-cyan-500/35 dark:border-cyan-500/25 shadow-xl space-y-4"
          >
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <Phone className="w-4 h-4 text-cyan-600" />
                {editingCall ? 'Editar Registro de Ligação' : 'Registrar Nova Ligação Telefônica'}
              </h3>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="p-1 px-2.5 rounded-lg text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveCall} className="grid grid-cols-1 md:grid-cols-12 gap-4">
              
              {/* Cliente */}
              <div className="md:col-span-4">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Cliente / Solicitante *</label>
                <div className="relative">
                  <UserIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="Nome da pessoa"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>

              {/* Telefone */}
              <div className="md:col-span-4">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Telefone para Contato</label>
                <div className="relative">
                  <Phone className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={clientPhone}
                    onChange={(e) => setClientPhone(e.target.value)}
                    placeholder="(00) 00000-0000"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>

              {/* Empresa */}
              <div className="md:col-span-4">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Empresa / Unidade</label>
                <div className="relative">
                  <Building className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Ex: Comercial LTDA"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                  />
                </div>
              </div>

              {/* Sentido da Ligacao */}
              <div className="md:col-span-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Sentido da Ligação</label>
                <select
                  value={direction}
                  onChange={(e) => setDirection(e.target.value as 'RECEBIDA' | 'EFETUADA')}
                  className="w-full p-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-slate-400 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                >
                  <option value="RECEBIDA">📥 Recebida (Entrada)</option>
                  <option value="EFETUADA">📤 Efetuada (Saída)</option>
                </select>
              </div>

              {/* Atendente/Destinatário */}
              <div className="md:col-span-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Pertence à / Destinado à</label>
                <input
                  type="text"
                  value={recipientName}
                  onChange={(e) => setRecipientName(e.target.value)}
                  placeholder="Ex: Gestor, Suporte, Nome do Setor"
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              {/* Horário Registro */}
              <div className="md:col-span-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Data / Hora Ocorrência</label>
                <input
                  type="datetime-local"
                  value={customDateTime}
                  onChange={(e) => setCustomDateTime(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              {/* Status */}
              <div className="md:col-span-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Status da Ligação</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                >
                  <option value="ATENDIDA_RESOLVIDA">🟢 Resolvida / Finalizada</option>
                  <option value="PENDENTE_RETORNO">🔴 Pendente de Retorno</option>
                  <option value="RECADO_ANOTADO">🟡 Recado Anotado</option>
                </select>
              </div>

              {/* Assunto / Motivo */}
              <div className="md:col-span-12">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Assunto / Motivo do Contato *</label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Breve e clara descrição do porquê ligou (Ex: Reclamação sobre etiqueta, pedido de suporte, proposta comercial)"
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              {/* Detalhes/Observações */}
              <div className="md:col-span-12">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Observações / Detalhamento do Telefonema</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Digite anotações ou detalhes sobre a conversa..."
                  rows={3}
                  className="w-full px-4 py-2.5 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-850 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
                />
              </div>

              {/* Form Buttons */}
              <div className="md:col-span-12 flex justify-end gap-2.5 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2.5 bg-slate-105 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs rounded-xl transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-extrabold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-md"
                >
                  <Check className="w-4 h-4" />
                  Salvar Telefonema
                </button>
              </div>

            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter and Search Panel */}
      <div className="bg-white dark:bg-[#1E293B] p-4 rounded-2xl border border-slate-200 dark:border-slate-800/60 shadow-sm space-y-4">
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Quick Search */}
          <div className="relative w-full md:max-w-sm">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar por cliente, empresa, assunto, destinatário..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-850 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-cyan-500"
            />
          </div>

          {/* Quick Dropdown Filters */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto justify-start md:justify-end">
            
            {/* Direction Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-[#0f172a] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-850">
              <ListFilter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={directionFilter}
                onChange={(e) => setDirectionFilter(e.target.value)}
                className="bg-transparent border-none text-[11px] font-semibold text-slate-600 dark:text-slate-350 focus:outline-none"
              >
                <option value="TODOS">Qualquer Sentido</option>
                <option value="RECEBIDA">📥 Apenas Recebidas</option>
                <option value="EFETUADA">📤 Apenas Efetuadas</option>
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-[#0f172a] px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-850">
              <Filter className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="bg-transparent border-none text-[11px] font-semibold text-slate-600 dark:text-slate-350 focus:outline-none"
              >
                <option value="TODOS">Todos os Status</option>
                <option value="ATENDIDA_RESOLVIDA">🟢 Resolvidas</option>
                <option value="PENDENTE_RETORNO">🔴 Pendente de Retorno</option>
                <option value="RECADO_ANOTADO">🟡 Recados</option>
              </select>
            </div>

            {/* Date filter */}
            <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-[#0f172a] px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-850">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <input
                type="date"
                value={dateFilter}
                onChange={(e) => setDateFilter(e.target.value)}
                className="bg-transparent border-none text-[11px] font-semibold text-slate-600 dark:text-slate-350 focus:outline-none outline-none"
              />
              {dateFilter && (
                <button onClick={() => setDateFilter('')} className="text-slate-400 hover:text-slate-650 ml-1">
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

          </div>

        </div>

      </div>

      {/* Main Call Records List */}
      <div className="bg-white dark:bg-[#1E293B] rounded-2xl border border-slate-200 dark:border-slate-800/60 shadow-sm overflow-hidden">
        {loading ? (
          <div className="p-12 text-center text-slate-450 text-xs">
            <Clock className="w-6 h-6 text-cyan-400 animate-spin mx-auto mb-2" />
            Carregando histórico de ligações...
          </div>
        ) : error ? (
          <div className="p-8 text-center text-rose-500 text-xs">
            {error}
          </div>
        ) : filteredCalls.length === 0 ? (
          <div className="p-12 text-center text-slate-450 text-xs text-slate-400">
            <Phone className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            Nenhum registro de ligação encontrado com os filtros ativos.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50/70 dark:bg-slate-900/40 border-b border-slate-150 dark:border-slate-800 text-[10px] font-extrabold uppercase text-slate-400 tracking-wider">
                  <th className="py-3.5 px-4 text-center max-w-[50px]">Sentido</th>
                  <th className="py-3.5 px-4">Cliente / Contato</th>
                  <th className="py-3.5 px-4">Empresa</th>
                  <th className="py-3.5 px-5">Motivo / Assunto</th>
                  <th className="py-3.5 px-4">Destinado à</th>
                  <th className="py-3.5 px-4">Horário</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {filteredCalls.map((call) => {
                  const callDate = new Date(call.dateTime);
                  const isToday = new Date().toLocaleDateString() === callDate.toLocaleDateString();
                  
                  return (
                    <tr 
                      key={call.id} 
                      className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors"
                      id={`phone-call-row-${call.id}`}
                    >
                      {/* Direction Icon */}
                      <td className="py-4 px-4 text-center">
                        {call.direction === 'RECEBIDA' ? (
                          <span className="inline-flex p-1.5 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-lg" title="Chamada Recebida">
                            <PhoneIncoming className="w-4 h-4" />
                          </span>
                        ) : (
                          <span className="inline-flex p-1.5 bg-cyan-500/10 text-cyan-600 dark:text-cyan-400 rounded-lg" title="Chamada Efetuada">
                            <PhoneOutgoing className="w-4 h-4" />
                          </span>
                        )}
                      </td>

                      {/* Client info */}
                      <td className="py-4 px-4 font-bold text-slate-800 dark:text-slate-100">
                        <div>
                          {call.clientName}
                          {call.clientPhone && (
                            <span className="block text-[10px] text-slate-400 dark:text-slate-500 font-mono mt-0.5 font-normal">
                              {call.clientPhone}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Company */}
                      <td className="py-4 px-4 text-slate-500 dark:text-slate-400 max-w-[140px] truncate">
                        {call.companyName || <span className="text-slate-300 italic">-</span>}
                      </td>

                      {/* Subject with notes tooltip or display */}
                      <td className="py-4 px-5">
                        <div className="max-w-[280px]">
                          <p className="font-semibold text-slate-700 dark:text-slate-200 truncate">{call.subject}</p>
                          {call.notes && (
                            <span className="block text-[10px] text-slate-405 dark:text-slate-450 font-normal italic leading-relaxed mt-1 line-clamp-1">
                              Obs: {call.notes}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Recipient */}
                      <td className="py-4 px-4 font-mono text-[10px] text-slate-500 dark:text-slate-400 uppercase tracking-wide">
                        {call.recipientName || 'Geral'}
                      </td>

                      {/* Timestamp */}
                      <td className="py-4 px-4 whitespace-nowrap">
                        <span className="font-semibold text-slate-700 dark:text-slate-300">
                          {isToday 
                            ? `Hoje, às ${callDate.toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}` 
                            : callDate.toLocaleDateString('pt-BR')
                          }
                        </span>
                        <span className="block text-[9px] text-slate-400 font-normal mt-0.5">
                          {callDate.toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit', second: '2-digit'})}
                        </span>
                      </td>

                      {/* Status badge */}
                      <td className="py-4 px-4 whitespace-nowrap">
                        {call.status === 'ATENDIDA_RESOLVIDA' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-250 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20">
                            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full" />
                            Atendida e Resolvida
                          </span>
                        )}
                        {call.status === 'PENDENTE_RETORNO' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-50 text-rose-700 border border-rose-250 dark:bg-rose-500/10 dark:text-rose-400 dark:border-rose-500/20">
                            <span className="w-1.5 h-1.5 bg-rose-500 rounded-full" />
                            Retorno Pendente
                          </span>
                        )}
                        {call.status === 'RECADO_ANOTADO' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold bg-cyan-50 text-cyan-700 border border-cyan-250 dark:bg-cyan-500/10 dark:text-cyan-400 dark:border-cyan-500/20">
                            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
                            Recado Anotado
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-4 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => {
                              setEditingCall(call);
                              setIsFormOpen(true);
                            }}
                            className="p-1.5 text-slate-450 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg hover:text-cyan-600 dark:hover:text-cyan-400 transition-all cursor-pointer"
                            title="Editar este telefonema"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteCall(call.id)}
                            className="p-1.5 text-slate-450 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded-lg hover:text-rose-600 transition-all cursor-pointer"
                            title="Excluir este telefonema"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
}
