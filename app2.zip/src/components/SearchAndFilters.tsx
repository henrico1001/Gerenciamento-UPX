/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, RefreshCw, Layers, Calendar, UserCheck, HelpCircle } from 'lucide-react';
import { TicketStatus, User } from '../types';

export interface FilterState {
  searchQuery: string;      // search client name or keyword
  technicianId: string;     // selected tech id (empty for all)
  status: string;           // selected status (empty for all)
  date: string;             // selected YYYY-MM-DD date (empty for all)
  minDuration: string;      // minimum duration in minutes (empty for all)
}

interface SearchAndFiltersProps {
  technicians: User[];
  isAdmin: boolean;
  onFilterChange: (filters: FilterState) => void;
  currentFilters: FilterState;
  currentUser?: User;
}

export default function SearchAndFilters({ technicians, isAdmin, onFilterChange, currentFilters, currentUser }: SearchAndFiltersProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [technicianId, setTechnicianId] = useState('');
  const [status, setStatus] = useState('');
  const [date, setDate] = useState('');
  const [minDuration, setMinDuration] = useState('');

  // Synchronize local states with props so they update dynamically when set externally (e.g. from Dashboard click)
  useEffect(() => {
    setSearchQuery(currentFilters.searchQuery || '');
    setTechnicianId(currentFilters.technicianId || '');
    setStatus(currentFilters.status || '');
    setDate(currentFilters.date || '');
    setMinDuration(currentFilters.minDuration || '');
    if (currentFilters.status || currentFilters.technicianId || currentFilters.date || currentFilters.minDuration) {
      setShowAdvanced(true);
    }
  }, [currentFilters]);

  const handleApply = (newFilters: Partial<FilterState>) => {
    const updated = {
      searchQuery: newFilters.searchQuery !== undefined ? newFilters.searchQuery : searchQuery,
      technicianId: newFilters.technicianId !== undefined ? newFilters.technicianId : technicianId,
      status: newFilters.status !== undefined ? newFilters.status : status,
      date: newFilters.date !== undefined ? newFilters.date : date,
      minDuration: newFilters.minDuration !== undefined ? newFilters.minDuration : minDuration,
    };
    onFilterChange(updated);
  };

  const handleReset = () => {
    setSearchQuery('');
    setTechnicianId('');
    setStatus('');
    setDate('');
    setMinDuration('');
    onFilterChange({
      searchQuery: '',
      technicianId: '',
      status: '',
      date: '',
      minDuration: '',
    });
  };

  return (
    <div className="bg-white dark:bg-[#1E293B]/90 backdrop-blur-md p-5 rounded-2xl border border-slate-200/80 dark:border-slate-800/60 shadow-sm space-y-4" id="search-filter-section">
      
      {/* Quick Search and Toggle Row */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-550" />
          <input
            type="text"
            id="searchInputField"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              handleApply({ searchQuery: e.target.value });
            }}
            placeholder="Pesquisar por nome do cliente ou empresa..."
            className="w-full bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800/80 pl-10 pr-4 py-2.5 text-xs rounded-xl focus:outline-none focus:border-cyan-500 focus:bg-white dark:focus:bg-[#1E293B] dark:focus:border-cyan-500/50 transition-all text-slate-700 dark:text-slate-205 placeholder-slate-400 dark:placeholder-slate-500"
          />
        </div>
        
        <div className="flex gap-2">
          {/* Advanced filters toggling */}
          <button
            id="btn-toggle-advanced-filters"
            onClick={() => setShowAdvanced(!showAdvanced)}
            className={`px-4 py-2.5 rounded-xl text-xs font-semibold flex items-center gap-2 border transition-all cursor-pointer hover:scale-[1.01] active:scale-[0.99] ${
              showAdvanced || status || date || minDuration || technicianId
                ? 'bg-cyan-50 dark:bg-cyan-500/10 border-cyan-200 dark:border-cyan-500/20 text-cyan-700 dark:text-cyan-400 font-bold'
                : 'bg-white dark:bg-slate-900/50 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-600 dark:text-slate-300'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-500" />
            <span>Filtros {showAdvanced ? 'Ativos' : 'Avançados'}</span>
          </button>

          {/* Reset Filters */}
          <button
            id="btn-reset-filters"
            onClick={handleReset}
            className="px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/50 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-500 dark:text-slate-400 text-xs transition-all cursor-pointer hover:scale-[1.01] active:scale-[0.99]"
            title="Limpar Filtros"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Advanced Filters Expandable Card */}
      {showAdvanced && (
        <div className={`pt-4 border-t border-slate-100 dark:border-slate-800/50 grid grid-cols-1 sm:grid-cols-2 ${(isAdmin || currentUser?.role === "TECNICO") ? 'lg:grid-cols-4' : 'lg:grid-cols-3'} gap-4 animate-slideDown`} id="advanced-filters-panel">
          
          {/* Filter 1: Status */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-550 dark:text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <Layers className="w-3 h-3 text-slate-400" />
              Status do <span className="notranslate" translate="no">Chamado</span>
            </label>
            <select
              id="filter-status-select"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                handleApply({ status: e.target.value });
              }}
              className="w-full bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 py-2 px-3 rounded-xl text-xs focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-500/50 cursor-pointer"
            >
              <option value="">Todos os status</option>
              <option value="RESOLVIDO">Resolvido</option>
              <option value="EM_ANDAMENTO">Em Andamento</option>
            </select>
          </div>

          {/* Filter 2: Date select */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-550 dark:text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <Calendar className="w-3 h-3 text-slate-400" />
              Data do Atendimento
            </label>
            <input
              type="date"
              id="filter-date-input"
              value={date}
              onChange={(e) => {
                setDate(e.target.value);
                handleApply({ date: e.target.value });
              }}
              className="w-full bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 py-2 px-3 rounded-xl text-xs focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-500/50 cursor-pointer"
            />
          </div>

          {/* Filter 3: Technician / Responsibility */}
          {(isAdmin || currentUser?.role === 'TECNICO') && (
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-550 dark:text-slate-500 uppercase tracking-wider flex items-center gap-1">
                <UserCheck className="w-3 h-3 text-slate-400" />
                Filtrar por Responsável
              </label>
              <select
                id="filter-tech-select"
                value={technicianId}
                onChange={(e) => {
                  setTechnicianId(e.target.value);
                  handleApply({ technicianId: e.target.value });
                }}
                className="w-full bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 py-2 px-3 rounded-xl text-xs focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-500/50 cursor-pointer text-ellipsis overflow-hidden"
              >
                {isAdmin ? (
                  <>
                    <option value="">Todos os técnicos</option>
                    {technicians.filter(u => u.role === 'TECNICO').map(tech => (
                      <option key={tech.id} value={tech.id}>{tech.name}</option>
                    ))}
                  </>
                ) : (
                  <>
                    <option value="">Todos os chamados</option>
                    <option value={currentUser?.id || ""}>Meus chamados</option>
                  </>
                )}
              </select>
            </div>
          )}

          {/* Filter 4: Duration search */}
          <div className="space-y-1">
            <label className="text-[10px] font-bold text-slate-550 dark:text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <HelpCircle className="w-3 h-3 text-slate-400" />
              Aberto/Durou mais de (minutos)
            </label>
            <input
              type="number"
              id="filter-duration-input"
              value={minDuration}
              onChange={(e) => {
                setMinDuration(e.target.value);
                handleApply({ minDuration: e.target.value });
              }}
              placeholder="Ex: 10, 20, 60..."
              className="w-full bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-slate-705 dark:text-slate-200 py-2 px-3 rounded-xl text-xs focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-500/50"
              min="0"
            />
          </div>

        </div>
      )}
    </div>
  );
}
