import React, { useState, useEffect } from 'react';
import { collection, doc, setDoc, deleteDoc, onSnapshot, updateDoc, db } from '../lib/api';
import { query, orderBy } from '../lib/api-query-helpers';
import { User, TambasaTicket } from '../types';
import { Search, Plus, Trash2, Clock, CheckCircle2, ChevronRight, Mail, UploadCloud, X, Calendar, User as UserIcon, FileCode, AlertTriangle } from 'lucide-react';
import { parseEml } from '../lib/emlParser';

interface TambasaTicketsProps {
  currentUser: User;
  isAdmin: boolean;
}

const formatDuration = (startIso: string, endIso: string) => {
  const diff = new Date(endIso).getTime() - new Date(startIso).getTime();
  if (diff < 0) return 'Duração inválida';
  const m = Math.floor(diff / 60000);
  const h = Math.floor(m / 60);
  if (h > 0) return `${h}h ${m % 60}m`;
  return `${m}m`;
};

const compressImage = (file: File, maxWidth = 1200, maxHeight = 1200, quality = 0.7): Promise<string> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => {
        resolve(event.target?.result as string); // fallback
      };
    };
    reader.onerror = () => {
      resolve('');
    };
    reader.readAsDataURL(file);
  });
};

const openBase64InNewTab = (base64Data: string, mimeType = 'application/pdf') => {
  try {
    const parts = base64Data.split(';base64,');
    let contentType = mimeType;
    let base64String = base64Data;
    if (parts.length > 1) {
      contentType = parts[0].split(':')[1] || mimeType;
      base64String = parts[1];
    }
    const raw = window.atob(base64String);
    const rawLength = raw.length;
    const uInt8Array = new Uint8Array(rawLength);
    for (let i = 0; i < rawLength; ++i) {
      uInt8Array[i] = raw.charCodeAt(i);
    }
    const blob = new Blob([uInt8Array], { type: contentType });
    const blobUrl = URL.createObjectURL(blob);
    window.open(blobUrl, '_blank');
  } catch (error) {
    console.error("Erro ao converter base64 em blob URL:", error);
    const w = window.open();
    if (w) {
      w.document.write(`<iframe src="${base64Data}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
    }
  }
};

export default function TambasaTickets({ currentUser, isAdmin }: TambasaTicketsProps) {
  const [tickets, setTickets] = useState<TambasaTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [search, setSearch] = useState('');
  
  // Custom non-browser feedback & warning dialogues:
  const [errorAlert, setErrorAlert] = useState<string | null>(null);
  const [ticketToDelete, setTicketToDelete] = useState<TambasaTicket | null>(null);
  
  // Form State
  const [emailOrigin, setEmailOrigin] = useState('');
  const [receivedAtDate, setReceivedAtDate] = useState('');
  const [receivedAtTime, setReceivedAtTime] = useState('');
  const [photoBase64, setPhotoBase64] = useState('');
  const [emlRaw, setEmlRaw] = useState('');
  const [emlParsedData, setEmlParsedData] = useState<any>(null);
  const [fileName, setFileName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // New Customer & Representative Fields (For creation/registration)
  const [clientFinalName, setClientFinalName] = useState('');
  const [clientFinalPhone, setClientFinalPhone] = useState('');
  const [representativeName, setRepresentativeName] = useState('');
  const [representativePhone, setRepresentativePhone] = useState('');

  // Invoice attachment states
  const [ticketEditingInvoice, setTicketEditingInvoice] = useState<TambasaTicket | null>(null);
  const [invoiceBase64, setInvoiceBase64] = useState('');
  const [invoiceFileName, setInvoiceFileName] = useState('');
  const [invoiceIssueDate, setInvoiceIssueDate] = useState('');
  const [isSavingInvoice, setIsSavingInvoice] = useState(false);

  // Viewer State
  const [selectedEmlTicket, setSelectedEmlTicket] = useState<TambasaTicket | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'tambasa_tickets'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snap) => {
      const data: TambasaTicket[] = [];
      snap.forEach(d => data.push(d.data() as TambasaTicket));
      setTickets(data);
      setLoading(false);
    });
    return () => unsub();
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const extension = file.name.split('.').pop()?.toLowerCase();
      if (extension === 'eml') {
        const reader = new FileReader();
        reader.onload = (ev) => {
          if (ev.target?.result) {
            const rawContent = ev.target.result.toString();
            const parsed = parseEml(rawContent);
            setEmlRaw(rawContent);
            setEmlParsedData(parsed);
            setFileName(file.name);
            setPhotoBase64(''); // Clear existing image if any
            
            // Auto fill the inputs from EML extracted data!
            if (parsed.from) {
              setEmailOrigin(parsed.from);
            }
            if (parsed.date) {
              try {
                const dateObj = new Date(parsed.date);
                if (!isNaN(dateObj.getTime())) {
                  const yyyy = dateObj.getFullYear();
                  const mm = String(dateObj.getMonth() + 1).padStart(2, '0');
                  const dd = String(dateObj.getDate()).padStart(2, '0');
                  setReceivedAtDate(`${yyyy}-${mm}-${dd}`);
                  
                  const hh = String(dateObj.getHours()).padStart(2, '0');
                  const min = String(dateObj.getMinutes()).padStart(2, '0');
                  setReceivedAtTime(`${hh}:${min}`);
                }
              } catch (err) {
                console.error("Failed to set EML auto-fill date", err);
              }
            }
          }
        };
        reader.readAsText(file);
      } else {
        // If it's an image, attempt to compress it to stay well under the size limit!
        if (file.type.startsWith('image/')) {
          compressImage(file).then((compressed) => {
            setPhotoBase64(compressed);
            setFileName(file.name);
            setEmlRaw('');
            setEmlParsedData(null);
          }).catch((err) => {
            console.error("Erro ao comprimir imagem de anexo:", err);
            const reader = new FileReader();
            reader.onload = (ev) => {
              if (ev.target?.result) {
                setPhotoBase64(ev.target.result.toString());
                setFileName(file.name);
                setEmlRaw('');
                setEmlParsedData(null);
              }
            };
            reader.readAsDataURL(file);
          });
        } else {
          // Warning if non-image/non-eml is too larger than 750KB
          if (file.size > 750 * 1024) {
            setErrorAlert(`O limite de tamanho para arquivos não-eml é de 750 KB para garantir salvamento imediato nas bases. Por favor, anexe uma imagem que nosso sistema irá comprimir automaticamente.`);
            e.target.value = '';
            return;
          }
          
          const reader = new FileReader();
          reader.onload = (ev) => {
            if (ev.target?.result) {
              setPhotoBase64(ev.target.result.toString());
              setFileName(file.name);
              setEmlRaw('');
              setEmlParsedData(null);
            }
          };
          reader.readAsDataURL(file);
        }
      }
    }
  };

  const formatBrazilianPhone = (value: string): string => {
    const digits = value.replace(/\D/g, '');
    const truncated = digits.slice(0, 11);
    
    if (truncated.length <= 2) {
      return truncated ? `(${truncated}` : '';
    }
    if (truncated.length <= 6) {
      return `(${truncated.slice(0, 2)}) ${truncated.slice(2)}`;
    }
    if (truncated.length <= 10) {
      return `(${truncated.slice(0, 2)}) ${truncated.slice(2, 6)}-${truncated.slice(6)}`;
    }
    return `(${truncated.slice(0, 2)}) ${truncated.slice(2, 7)}-${truncated.slice(7)}`;
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    if (!emailOrigin || !receivedAtDate || !receivedAtTime) return;
    
    if (!clientFinalName.trim() || !clientFinalPhone.trim()) {
      setErrorAlert('O nome e o telefone do cliente final são obrigatórios!');
      return;
    }

    setIsSubmitting(true);
    const receivedIso = new Date(`${receivedAtDate}T${receivedAtTime}:00`).toISOString();
    const id = 'tmb_' + Math.random().toString(36).substring(2, 9);
    const now = new Date().toISOString();

    const newTicket: TambasaTicket = {
      id,
      emailOrigin,
      receivedAt: receivedIso,
      photoUrl: photoBase64,
      clientFinalName: clientFinalName.trim(),
      clientFinalPhone: clientFinalPhone.trim(),
      status: 'EM_ANDAMENTO',
      openedBy: currentUser.id,
      openedByName: currentUser.name,
      createdAt: now,
    };

    if (emlParsedData) {
      newTicket.emlParsed = {
        subject: emlParsedData.subject || '',
        from: emlParsedData.from || '',
        to: emlParsedData.to || '',
        date: emlParsedData.date || '',
        body: emlParsedData.body || '',
        isHtml: emlParsedData.isHtml || false,
        fileName: fileName || 'email.eml'
      };
    }

    if (representativeName.trim()) {
      newTicket.representativeName = representativeName.trim();
    }

    if (representativePhone.trim()) {
      newTicket.representativePhone = representativePhone.trim();
    }

    try {
      await setDoc(doc(db, 'tambasa_tickets', id), newTicket);
      setIsFormOpen(false);
      setEmailOrigin('');
      setPhotoBase64('');
      setEmlRaw('');
      setEmlParsedData(null);
      setFileName('');
      setReceivedAtDate('');
      setReceivedAtTime('');
      setClientFinalName('');
      setClientFinalPhone('');
      setRepresentativeName('');
      setRepresentativePhone('');
    } catch (err) {
      console.error("Erro detalhado ao criar chamado Tambasa:", err);
      setErrorAlert(`Erro ao criar chamado Tambasa nas bases de dados: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleStatus = async (ticket: TambasaTicket) => {
    // Permite que qualquer técnico logado possa alterar o status
    const newStatus = ticket.status === 'EM_ANDAMENTO' ? 'RESOLVIDO' : 'EM_ANDAMENTO';
    const finishedAt = newStatus === 'RESOLVIDO' ? new Date().toISOString() : undefined;
    
    try {
      await updateDoc(doc(db, 'tambasa_tickets', ticket.id), {
        status: newStatus,
        finishedAt: finishedAt || null
      });
    } catch (err) {
      console.error("Erro ao alterar status:", err);
      setErrorAlert(`Erro ao alterar o status do chamado: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleDeleteClick = (ticket: TambasaTicket) => {
    // Permite que qualquer técnico logado possa excluir
    setTicketToDelete(ticket);
  };

  const handleConfirmDelete = async () => {
    if (!ticketToDelete) return;
    try {
      await deleteDoc(doc(db, 'tambasa_tickets', ticketToDelete.id));
      setTicketToDelete(null);
    } catch (err) {
      console.error("Erro ao deletar chamado:", err);
      setErrorAlert(`Erro ao deletar o chamado: ${err instanceof Error ? err.message : String(err)}`);
    }
  };

  const handleInvoiceUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type.startsWith('image/')) {
        try {
          const compressed = await compressImage(file);
          setInvoiceBase64(compressed);
          setInvoiceFileName(file.name);
        } catch (err) {
          console.error("Erro ao comprimir imagem da nota fiscal:", err);
          const reader = new FileReader();
          reader.onload = (ev) => {
            if (ev.target?.result) {
              setInvoiceBase64(ev.target.result.toString());
              setInvoiceFileName(file.name);
            }
          };
          reader.readAsDataURL(file);
        }
      } else {
        // PDF or other non-image format
        // Warn if size too large for Firestore limit (base64 string can be up to 1MB, so original file max ~750KB is safe)
        if (file.size > 750 * 1024) {
          setErrorAlert(`O limite de tamanho para arquivos PDF é de 750 KB para garantir salvamento imediato nas bases de dados. Por favor, comprima seu PDF em ferramentas como "I Love PDF" antes de anexar, ou tire uma foto da NF (o nosso sistema irá comprimir a foto da nota fiscal automaticamente mantendo ótima qualidade!).`);
          e.target.value = ''; // clear input
          return;
        }

        const reader = new FileReader();
        reader.onload = (ev) => {
          if (ev.target?.result) {
            setInvoiceBase64(ev.target.result.toString());
            setInvoiceFileName(file.name);
          }
        };
        reader.readAsDataURL(file);
      }
    }
  };

  const handleSaveInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketEditingInvoice) return;
    if (!invoiceIssueDate) {
      setErrorAlert('A data de emissão da nota fiscal é obrigatória!');
      return;
    }
    if (!invoiceBase64) {
      setErrorAlert('Por favor, anexe o arquivo ou foto da nota fiscal!');
      return;
    }

    setIsSavingInvoice(true);
    try {
      await updateDoc(doc(db, 'tambasa_tickets', ticketEditingInvoice.id), {
        invoiceUrl: invoiceBase64,
        invoiceFileName: invoiceFileName || 'nota_fiscal.png',
        invoiceIssueDate: invoiceIssueDate
      });
      setTicketEditingInvoice(null);
      setInvoiceBase64('');
      setInvoiceFileName('');
      setInvoiceIssueDate('');
    } catch (err) {
      console.error("Erro ao salvar nota fiscal:", err);
      setErrorAlert(`Erro ao salvar nota fiscal: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setIsSavingInvoice(false);
    }
  };

  const viewableTickets = tickets;
  const filteredTickets = viewableTickets.filter(t => t.emailOrigin.toLowerCase().includes(search.toLowerCase()));

  const openTicketsCount = tickets.filter(t => t.status === 'EM_ANDAMENTO').length;
  const resolvedTicketsCount = tickets.filter(t => t.status === 'RESOLVIDO').length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header Info */}
      <div className="bg-white dark:bg-[#1E293B] rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-[140px] h-[140px] bg-blue-50 dark:bg-slate-800 rounded-xl flex items-center justify-center shrink-0 border border-blue-100 dark:border-slate-700 overflow-hidden shadow-sm">
            <img src="https://play-lh.googleusercontent.com/gHsheu64wlAI3KuMiX4efhkK_RxRNz8hfRJ1QVl8Vp9McJya58qKVKM7JptPC6J2_9Gi=w400-h400-rw" alt="Tambasa Logo" className="w-[140px] h-[140px] object-cover" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">Atendimentos Tambasa</h2>
            <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Gestão especializada de chamados iniciados via E-mail</p>
          </div>
        </div>
        {isAdmin && (
          <div className="flex gap-4 items-center bg-slate-50 dark:bg-slate-900 px-4 py-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
            <div className="text-center">
              <span className="block text-[10px] uppercase font-bold text-slate-400">Em Aberto</span>
              <span className="block text-lg font-black text-blue-500">{openTicketsCount}</span>
            </div>
            <div className="w-px h-8 bg-slate-200 dark:bg-slate-700"></div>
            <div className="text-center">
              <span className="block text-[10px] uppercase font-bold text-slate-400">Resolvidos</span>
              <span className="block text-lg font-black text-emerald-500">{resolvedTicketsCount}</span>
            </div>
          </div>
        )}
      </div>

      {isFormOpen ? (
        <form onSubmit={handleCreate} className="bg-white dark:bg-[#1E293B] rounded-2xl border border-slate-200 dark:border-slate-800 p-6 shadow-sm space-y-6">
          <div className="flex justify-between items-center pb-4 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
              <Mail className="w-5 h-5 text-blue-500" />
              Novo E-mail Tambasa
            </h3>
            <button type="button" onClick={() => setIsFormOpen(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Email de Origem (Remetente)</label>
              <input required type="email" value={emailOrigin} onChange={e => setEmailOrigin(e.target.value)} placeholder="ex: gerente@tambasa.com.br" className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 dark:text-white" />
            </div>
            
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Data de Recebimento</label>
              <input required type="date" value={receivedAtDate} onChange={e => setReceivedAtDate(e.target.value)} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 dark:text-white" />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Hora de Recebimento</label>
              <input required type="time" value={receivedAtTime} onChange={e => setReceivedAtTime(e.target.value)} className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 dark:text-white" />
            </div>

            <div className="space-y-1.5 md:col-span-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Importar E-mail (.eml) ou Anexo de Imagem</label>
              <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                {emlParsedData ? (
                  <div className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2 text-left relative max-w-full">
                    <div className="flex justify-between items-center pb-2 border-b border-slate-200 dark:border-slate-700">
                      <span className="text-[10px] font-extrabold text-blue-600 dark:text-blue-400 uppercase tracking-wider flex items-center gap-1">
                        <FileCode className="w-4 h-4" />
                        E-mail importado preenchido automaticamente
                      </span>
                      <button type="button" onClick={() => { setEmlRaw(''); setEmlParsedData(null); setFileName(''); setEmailOrigin(''); setReceivedAtDate(''); setReceivedAtTime(''); }} className="bg-rose-500 text-white hover:bg-rose-600 rounded-full p-1 transition-colors" title="Remover e-mail">
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                    <div className="text-xs space-y-1 mt-2">
                      <p><span className="font-bold text-slate-500">Arquivo:</span> <span className="text-slate-800 dark:text-slate-200 font-mono">{fileName}</span></p>
                      <p><span className="font-bold text-slate-500">Assunto:</span> <span className="text-slate-900 dark:text-slate-100 font-semibold">{emlParsedData.subject || '(Sem assunto)'}</span></p>
                      <p><span className="font-bold text-slate-500">Remetente:</span> <span className="text-slate-800 dark:text-slate-200">{emlParsedData.from || '(Não identificado)'}</span></p>
                    </div>
                  </div>
                ) : photoBase64 ? (
                  <div className="relative inline-block">
                    <img src={photoBase64} alt="Preview" className="max-h-48 rounded animate-fadeIn" />
                    <button type="button" onClick={() => { setPhotoBase64(''); setFileName(''); }} className="absolute -top-2 -right-2 bg-rose-500 text-white rounded-full p-1"><X className="w-3 h-3" /></button>
                  </div>
                ) : (
                  <label className="cursor-pointer flex flex-col items-center gap-2 py-4">
                    <UploadCloud className="w-10 h-10 text-blue-500 dark:text-blue-400" />
                    <span className="text-sm font-semibold text-blue-600 dark:text-blue-400">Clique ou arraste um arquivo</span>
                    <span className="text-xs text-slate-400 dark:text-slate-500">Suporta arquivos de exportação .eml ou de imagem (PNG, JPG)</span>
                    <input type="file" accept="image/*,.eml" className="hidden" onChange={handleFileUpload} />
                  </label>
                )}
              </div>
            </div>

            {/* Dados do Cliente Final (Obrigatório) */}
            <div className="md:col-span-2 border-t border-slate-100 dark:border-slate-800/80 pt-6">
              <h4 className="text-xs font-black uppercase text-blue-600 dark:text-blue-400 tracking-wider mb-4 flex items-center gap-1.5">
                <span className="w-1.5 h-3 bg-blue-500 rounded-xs"></span>
                Dados do Cliente Final (Obrigatório)
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Nome do Cliente Final *</label>
                  <input required type="text" value={clientFinalName} onChange={e => setClientFinalName(e.target.value)} placeholder="Nome completo ou Razão Social" className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 dark:text-white" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Telefone do Cliente Final *</label>
                  <input required type="text" value={clientFinalPhone} onChange={e => setClientFinalPhone(formatBrazilianPhone(e.target.value))} placeholder="(XX) XXXXX-XXXX" className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 dark:text-white" />
                </div>
              </div>
            </div>

            {/* Dados do Representante (Opcional) */}
            <div className="md:col-span-2 border-t border-slate-100 dark:border-slate-800/80 pt-6">
              <h4 className="text-xs font-black uppercase text-slate-400 dark:text-slate-500 tracking-wider mb-4 flex items-center gap-1.5">
                <span className="w-1.5 h-3 bg-slate-400 dark:bg-slate-600 rounded-xs"></span>
                Dados do Representante (Opcional)
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Nome do Representante</label>
                  <input type="text" value={representativeName} onChange={e => setRepresentativeName(e.target.value)} placeholder="Nome do Representante" className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 dark:text-white" />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Telefone do Representante</label>
                  <input type="text" value={representativePhone} onChange={e => setRepresentativePhone(formatBrazilianPhone(e.target.value))} placeholder="(XX) XXXXX-XXXX" className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 dark:text-white" />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
            <button type="button" onClick={() => setIsFormOpen(false)} className="px-5 py-2.5 text-slate-600 dark:text-slate-300 font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-colors">Cancelar</button>
            <button type="submit" disabled={isSubmitting} className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold rounded-xl shadow-lg shadow-blue-500/30 disabled:shadow-none transition-all flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed">
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Registrando...
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  Registrar Chamado Tambasa
                </>
              )}
            </button>
          </div>
        </form>
      ) : (
        <div className="space-y-6">
          <div className="flex justify-between items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input type="text" placeholder="Filtrar por email de origem..." value={search} onChange={e => setSearch(e.target.value)} className="w-full bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-800 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:border-blue-500 dark:text-white shadow-sm" />
            </div>
            <button onClick={() => setIsFormOpen(true)} className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center gap-2">
              <Plus className="w-4 h-4" />
              Registrar Recebimento
            </button>
          </div>

          {loading ? (
             <div className="p-8 text-center text-slate-500">Carregando...</div>
          ) : filteredTickets.length === 0 ? (
             <div className="p-12 text-center bg-white dark:bg-[#1E293B] rounded-2xl border border-dashed border-slate-300 dark:border-slate-700">
               <Mail className="w-10 h-10 text-slate-300 mx-auto mb-3" />
               <p className="font-semibold text-slate-500">Nenhum chamado de email encontrado.</p>
             </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {filteredTickets.map(ticket => {
                const isResolved = ticket.status === 'RESOLVIDO';
                const receivedDateObj = new Date(ticket.receivedAt);
                const rDate = receivedDateObj.toLocaleDateString('pt-BR', {day: '2-digit', month: '2-digit', year: 'numeric'});
                const rTime = receivedDateObj.toLocaleTimeString('pt-BR', {hour: '2-digit', minute: '2-digit'});
                const duration = isResolved && ticket.finishedAt ? formatDuration(ticket.createdAt, ticket.finishedAt) : formatDuration(ticket.createdAt, new Date().toISOString());

                return (
                  <div key={ticket.id} className={`bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-sm flex flex-col gap-4 relative overflow-hidden group hover:border-blue-300 dark:hover:border-blue-800 transition-colors ${isResolved ? 'border-l-4 border-l-emerald-500' : 'border-l-4 border-l-blue-500'}`}>
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${isResolved ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400' : 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-500/10 dark:text-blue-400'}`}>
                            {isResolved ? 'Resolvido' : 'Em Andamento'}
                          </span>
                          <span className="text-xs font-mono text-slate-400 block break-all">{ticket.emailOrigin}</span>
                        </div>
                        <h3 className="font-bold text-slate-800 dark:text-slate-100 text-sm mt-2 flex items-center gap-1.5">
                          E-mail Recebido
                          <ChevronRight className="w-3 h-3 text-slate-400" />
                          <span className="text-blue-600 dark:text-blue-400">{rDate} às {rTime}</span>
                        </h3>
                        {ticket.emlParsed?.subject && (
                          <p className="text-xs text-slate-600 dark:text-slate-350 font-medium mt-1 pl-1.5 border-l-2 border-blue-400 dark:border-blue-500/50 line-clamp-1 italic text-left" title={ticket.emlParsed.subject}>
                            "{ticket.emlParsed.subject}"
                          </p>
                        )}
                      </div>
                      {true && (
                        <button onClick={() => handleDeleteClick(ticket)} className="p-1.5 text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition-colors" title="Apagar">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Informações do Cliente Final & Representante */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pb-1 border-b border-slate-100 dark:border-slate-800/60">
                      <div className="p-2.5 rounded-xl bg-blue-50/40 dark:bg-blue-950/10 border border-blue-50 dark:border-blue-900/20 text-left">
                        <span className="text-[9px] uppercase font-black text-blue-500 block mb-0.5">Cliente Final</span>
                        <span className="text-xs font-black text-slate-800 dark:text-slate-100 block">{ticket.clientFinalName || 'Não Cadastrado'}</span>
                        <span className="text-xs font-mono text-slate-500 block mt-0.5">{ticket.clientFinalPhone || 'N/A'}</span>
                      </div>
                      <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100/80 dark:border-slate-800/80 text-left">
                        <span className="text-[9px] uppercase font-bold text-slate-400 block mb-0.5">Representante Comercial</span>
                        <span className="text-xs font-bold text-slate-700 dark:text-slate-350 block leading-tight">
                          {ticket.representativeName || <span className="text-slate-400 font-normal italic">Não informado</span>}
                        </span>
                        {ticket.representativePhone && (
                          <span className="text-xs font-mono text-slate-500 block mt-0.5">{ticket.representativePhone}</span>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex gap-4 items-center">
                      {ticket.emlParsed ? (
                        <div onClick={() => setSelectedEmlTicket(ticket)} className="w-24 h-24 bg-blue-50 hover:bg-blue-100 dark:bg-slate-800 dark:hover:bg-slate-750 rounded-xl border border-blue-100 dark:border-slate-700 flex flex-col items-center justify-center text-blue-600 dark:text-blue-400 cursor-pointer transition-all shadow-sm shrink-0 group/icon" title="Clique para ler o e-mail completo">
                          <Mail className="w-8 h-8 mb-1 group-hover/icon:scale-110 transition-transform" />
                          <span className="text-[10px] font-extrabold uppercase tracking-wider text-center px-1">Ver E-mail</span>
                          {ticket.emlParsed.fileName && (
                            <span className="text-[7px] text-slate-400 dark:text-slate-500 max-w-[80px] truncate block px-1 mt-0.5" title={ticket.emlParsed.fileName}>
                              {ticket.emlParsed.fileName}
                            </span>
                          )}
                        </div>
                      ) : ticket.photoUrl ? (
                        <img src={ticket.photoUrl} alt="Anexo Email" className="w-24 h-24 object-cover rounded-xl border border-slate-100 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 cursor-pointer hover:opacity-80" onClick={() => window.open(ticket.photoUrl, '_blank')} />
                      ) : (
                        <div className="w-24 h-24 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-100 dark:border-slate-700 flex items-center justify-center flex-col text-slate-400">
                          <Mail className="w-6 h-6 mb-1 opacity-50" />
                          <span className="text-[9px] font-bold">Sem Foto</span>
                        </div>
                      )}
                      
                      <div className="flex-1 space-y-2">
                        <div className="bg-slate-50 dark:bg-slate-900/50 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 font-bold uppercase mb-0.5">Técnico Responsável</p>
                          <p className="text-xs font-medium text-slate-700 dark:text-slate-300">{ticket.openedByName}</p>
                        </div>
                        <div className="flex justify-between items-center text-xs">
                          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                            <Clock className="w-3.5 h-3.5" />
                            <span className={isResolved ? "text-emerald-600 dark:text-emerald-400 font-semibold" : ""}>{isResolved ? 'Durou' : 'Aberto'} {duration}</span>
                          </div>
                          <button onClick={() => handleToggleStatus(ticket)} className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all ${isResolved ? 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700' : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-sm'}`}>
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            {isResolved ? 'Reabrir' : 'Finalizar'}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Nota Fiscal do Cliente */}
                    <div className="border-t border-slate-100 dark:border-slate-800/80 pt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/50 dark:bg-slate-900/10 p-3 rounded-xl border border-slate-100 dark:border-slate-800 mt-1">
                      <div className="flex items-center gap-2.5">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${ticket.invoiceUrl ? 'bg-amber-100 text-amber-700 dark:bg-amber-500/10 dark:text-amber-400' : 'bg-slate-100 text-slate-400 dark:bg-slate-800'}`}>
                          <FileCode className="w-4 h-4" />
                        </div>
                        <div className="text-left">
                          <span className="text-[9px] font-black uppercase text-slate-400 block tracking-wider">Nota Fiscal do Cliente</span>
                          {ticket.invoiceUrl ? (
                            <div className="space-y-0.5">
                              <button
                                type="button"
                                onClick={() => {
                                  if (ticket.invoiceUrl) {
                                    openBase64InNewTab(ticket.invoiceUrl);
                                  }
                                }}
                                className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:text-amber-700 hover:underline flex items-center gap-1 cursor-pointer text-left break-all max-w-[200px] truncate"
                              >
                                {ticket.invoiceFileName || 'nota_fiscal.png'}
                              </button>
                              {ticket.invoiceIssueDate && (
                                <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono block">
                                  Emissão: {(() => {
                                    const [y, m, d] = ticket.invoiceIssueDate.split('-');
                                    return `${d}/${m}/${y}`;
                                  })()}
                                </span>
                              )}
                            </div>
                          ) : (
                            <span className="text-xs text-slate-400 font-medium">Nenhuma nota fiscal anexada</span>
                          )}
                        </div>
                      </div>
                      
                      <button
                        type="button"
                        onClick={() => {
                          setInvoiceBase64(ticket.invoiceUrl || '');
                          setInvoiceFileName(ticket.invoiceFileName || '');
                          setInvoiceIssueDate(ticket.invoiceIssueDate || '');
                          setTicketEditingInvoice(ticket);
                        }}
                        className="px-3 py-1.5 bg-amber-50 dark:bg-amber-500/10 hover:bg-amber-100 dark:hover:bg-amber-500/20 text-amber-600 dark:text-amber-400 border border-amber-200/50 dark:border-amber-500/20 font-bold rounded-lg text-[10px] uppercase tracking-wider transition-colors shrink-0 cursor-pointer flex items-center gap-1.5 self-start sm:self-center"
                      >
                        <UploadCloud className="w-3.5 h-3.5" />
                        {ticket.invoiceUrl ? 'Alterar Nota' : 'Anexar Nota'}
                      </button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}

      {/* Reader Modal */}
      {selectedEmlTicket && selectedEmlTicket.emlParsed && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="eml-modal">
          <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-slideUp">
            
            {/* Modal Header */}
            <div className="bg-slate-50 dark:bg-slate-900 px-6 py-4 flex justify-between items-center border-b border-slate-200 dark:border-slate-800 shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-xl flex items-center justify-center text-blue-600 dark:text-blue-400">
                  <Mail className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-sm font-extrabold uppercase text-slate-400 tracking-wider">Leitor de E-mail Outlook (.eml)</h4>
                  <p className="text-xs text-slate-500 font-mono font-medium max-w-[280px] sm:max-w-md truncate" title={selectedEmlTicket.emlParsed.fileName}>
                    {selectedEmlTicket.emlParsed.fileName || 'email.eml'}
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setSelectedEmlTicket(null)} 
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors p-2 rounded-xl bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-800 hover:shadow-xs"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Email Metadata */}
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-[#1E293B] space-y-2 grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-1.5 shrink-0 text-xs">
              <div className="flex items-start gap-2 col-span-1 md:col-span-2">
                <span className="font-extrabold text-slate-500 uppercase min-w-[70px]">Assunto:</span>
                <span className="text-slate-900 dark:text-white font-black text-[13px]">{selectedEmlTicket.emlParsed.subject || '(Sem assunto)'}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-500 uppercase min-w-[70px]">De:</span>
                <span className="bg-blue-50 dark:bg-blue-950/40 text-blue-700 dark:text-blue-300 px-2 py-0.5 rounded-md font-medium font-mono border border-blue-100/50 dark:border-blue-900/30 break-all">{selectedEmlTicket.emlParsed.from || '(Não identificado)'}</span>
              </div>
              {selectedEmlTicket.emlParsed.to && (
                <div className="flex items-center gap-2">
                  <span className="font-extrabold text-slate-500 uppercase min-w-[70px]">Para:</span>
                  <span className="text-slate-700 dark:text-slate-300 font-medium font-mono max-w-xs truncate">{selectedEmlTicket.emlParsed.to}</span>
                </div>
              )}
              <div className="flex items-center gap-2 col-span-1 md:col-span-2">
                <span className="font-extrabold text-slate-500 uppercase min-w-[70px]">Recebido:</span>
                <span className="text-slate-700 dark:text-slate-300 font-semibold">
                  {selectedEmlTicket.emlParsed.date ? new Date(selectedEmlTicket.emlParsed.date).toLocaleString('pt-BR') : 'Data não identificada'}
                </span>
              </div>
            </div>

            {/* Email Body */}
            <div className="flex-1 p-6 overflow-y-auto bg-slate-50 dark:bg-slate-950/40">
              <div className="bg-white dark:bg-[#1E293B] rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden p-1">
                {selectedEmlTicket.emlParsed.isHtml ? (
                  <iframe
                    title="Conteúdo do Email"
                    srcDoc={selectedEmlTicket.emlParsed.body}
                    className="w-full h-[380px] bg-white rounded-lg"
                    sandbox="allow-same-origin"
                  />
                ) : (
                  <div className="w-full h-[380px] overflow-y-auto p-4 font-mono text-sm leading-relaxed text-slate-700 dark:text-slate-300 bg-white dark:bg-[#1E293B] whitespace-pre-wrap break-words">
                    {selectedEmlTicket.emlParsed.body || '(Sem conteúdo)'}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="bg-slate-50 dark:bg-slate-900 px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-3 shrink-0">
              <button 
                onClick={() => setSelectedEmlTicket(null)} 
                className="px-5 py-2 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 font-bold rounded-xl text-slate-700 dark:text-slate-300 transition-colors text-xs cursor-pointer"
              >
                Fechar Visualização
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Custom Error Warning Modal (Replacing window.alert) */}
      {errorAlert && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-[60] animate-fadeIn">
          <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-sm p-6 shadow-2xl flex flex-col items-center text-center animate-scaleIn">
            <div className="w-12 h-12 bg-rose-100 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-full flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h4 className="text-base font-bold text-slate-800 dark:text-slate-100 mb-2">Atenção</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-6">{errorAlert}</p>
            <button 
              onClick={() => setErrorAlert(null)} 
              className="w-full py-2.5 bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 dark:hover:bg-slate-600 text-white font-bold rounded-xl text-xs transition-colors cursor-pointer"
            >
              Entendido
            </button>
          </div>
        </div>
      )}

      {/* Custom Delete Confirmation Modal (Replacing window.confirm) */}
      {ticketToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="delete-confirm-modal">
          <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl animate-scaleIn animate-slideUp">
            <div className="flex items-start gap-4 mb-5">
              <div className="w-12 h-12 bg-rose-100 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400 rounded-2xl flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="text-left flex-1">
                <h4 className="text-base font-black text-slate-800 dark:text-slate-100">Excluir chamado?</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mt-1">
                  Tem certeza que deseja excluir o chamado aberto para <span className="font-bold text-slate-700 dark:text-slate-300 font-mono">{ticketToDelete.emailOrigin}</span>? Esta ação não pode ser desfeita.
                </p>
                {ticketToDelete.emlParsed?.subject && (
                  <div className="mt-2.5 p-2.5 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 text-xs italic text-slate-500/95 dark:text-slate-400 line-clamp-2">
                    "{ticketToDelete.emlParsed.subject}"
                  </div>
                )}
              </div>
            </div>
            <div className="flex justify-end gap-3 border-t border-slate-100 dark:border-slate-800 pt-4">
              <button 
                type="button" 
                onClick={() => setTicketToDelete(null)} 
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button 
                type="button" 
                onClick={handleConfirmDelete} 
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-rose-500/20 cursor-pointer"
              >
                Sim, Excluir
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Invoice Dialog (Adding / Changing Nota Fiscal) */}
      {ticketEditingInvoice && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn" id="invoice-modal">
          <form 
            onSubmit={handleSaveInvoice} 
            className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-5 animate-scaleIn"
          >
            <div className="flex justify-between items-center pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-sm font-black text-slate-800 dark:text-slate-100 flex items-center gap-2 uppercase tracking-tight">
                <FileCode className="w-5 h-5 text-amber-500 animate-pulse" />
                Nota Fiscal do Cliente
              </h3>
              <button 
                type="button" 
                onClick={() => setTicketEditingInvoice(null)} 
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed text-left">
              Insira os dados da nota fiscal do cliente <span className="font-bold text-slate-700 dark:text-slate-200">{ticketEditingInvoice.clientFinalName}</span>.
            </div>

            {/* Inputs block */}
            <div className="space-y-4 text-left">
              <div className="space-y-1.5">
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-400 block">
                  Data de Emissão da Nota *
                </label>
                <input 
                  required 
                  type="date" 
                  value={invoiceIssueDate} 
                  onChange={e => setInvoiceIssueDate(e.target.value)} 
                  className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:border-amber-500 dark:text-white" 
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-400 block">
                  Arquivo da Nota Fiscal *
                </label>
                <div className="border border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-4 text-center hover:bg-slate-50 dark:hover:bg-slate-850/30 transition-colors">
                  {invoiceBase64 ? (
                    <div className="bg-amber-100/10 border border-amber-200/50 dark:border-amber-900/40 rounded-xl p-3 text-left relative max-w-full flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 text-xs truncate">
                        <FileCode className="w-4 h-4 text-amber-500 shrink-0" />
                        <span className="text-amber-700 dark:text-amber-400 font-medium truncate font-mono max-w-[150px]" title={invoiceFileName}>
                          {invoiceFileName || 'invoice_file'}
                        </span>
                      </div>
                      <button 
                        type="button" 
                        onClick={() => { setInvoiceBase64(''); setInvoiceFileName(''); }} 
                        className="bg-rose-500 text-white hover:bg-rose-600 rounded-full p-1 transition-colors" 
                        title="Remover anexo"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <label className="cursor-pointer flex flex-col items-center gap-1.5 py-3">
                      <UploadCloud className="w-8 h-8 text-amber-500" />
                      <span className="text-xs font-bold text-amber-600 dark:text-amber-400">Selecionar arquivo NF</span>
                      <span className="text-[10px] text-slate-400">Imagem (JPG, PNG) ou PDF</span>
                      <input 
                        required 
                        type="file" 
                        accept="image/*,application/pdf" 
                        className="hidden" 
                        onChange={handleInvoiceUpload} 
                      />
                    </label>
                  )}
                </div>
              </div>

              {invoiceBase64 && (
                <div className="space-y-1.5 animate-fadeIn">
                  <label className="text-[10px] font-extrabold uppercase tracking-wider text-slate-600 dark:text-slate-400 block">
                    Pré-visualização do Documento
                  </label>
                  <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden bg-slate-50 dark:bg-slate-900/60 flex flex-col relative min-h-[180px]">
                    {invoiceBase64.startsWith('data:application/pdf') ? (
                      <div className="w-full flex flex-col items-center justify-center p-6 text-center space-y-4">
                        <div className="w-16 h-16 bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-400 rounded-2xl flex items-center justify-center shadow-inner">
                          <FileCode className="w-8 h-8 animate-pulse" />
                        </div>
                        <div className="space-y-1.5 max-w-xs">
                          <h4 className="text-xs font-black text-slate-800 dark:text-slate-200">Arquivo PDF Carregado</h4>
                          <p className="text-[10px] font-mono text-slate-500 truncate" title={invoiceFileName}>
                            {invoiceFileName || 'nota_fiscal.pdf'}
                          </p>
                          <p className="text-[10px] text-slate-400 leading-relaxed">
                            Por segurança contra ameaças e restrições de navegadores, o PDF não pode ser renderizado em miniaturas internas. Clique no botão abaixo para visualizá-lo completo com segurança.
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => openBase64InNewTab(invoiceBase64)}
                          className="px-4 py-2 bg-amber-50 dark:bg-amber-500/10 hover:bg-amber-100 dark:hover:bg-amber-500/25 text-amber-600 dark:text-amber-400 border border-amber-200/50 dark:border-amber-500/35 font-extrabold rounded-xl text-xs uppercase tracking-wider transition-all duration-200 flex items-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <UploadCloud className="w-4 h-4 shrink-0" />
                          Visualizar PDF em Tela Cheia
                        </button>
                      </div>
                    ) : (
                      <div className="w-full flex flex-col items-center">
                        <div className="w-full p-2.5 flex items-center justify-center bg-slate-100/50 dark:bg-slate-900/40">
                          <img 
                            src={invoiceBase64} 
                            alt="Preview da Nota" 
                            className="max-h-60 max-w-full object-contain rounded-lg shadow-xs"
                            referrerPolicy="no-referrer"
                          />
                        </div>
                        <div className="w-full p-2.5 bg-slate-100 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-755 text-center">
                          <a 
                            href={invoiceBase64} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:underline inline-flex items-center gap-1 justify-center cursor-pointer"
                          >
                            Ver imagem em tamanho original
                          </a>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Footer Buttons */}
            <div className="flex justify-end gap-3 border-t border-slate-100 dark:border-slate-800 pt-4">
              <button 
                type="button" 
                onClick={() => setTicketEditingInvoice(null)} 
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button 
                type="submit" 
                disabled={isSavingInvoice} 
                className="px-4 py-2 bg-amber-600 hover:bg-amber-700 disabled:bg-amber-400 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-amber-500/10 cursor-pointer disabled:cursor-not-allowed flex items-center gap-1.5"
              >
                {isSavingInvoice ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Salvando...
                  </>
                ) : (
                  'Salvar Nota Fiscal'
                )}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}
