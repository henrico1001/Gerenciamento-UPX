// Helper functions just to prevent undefined imports.
// Note: query/orderBy in the shim aren't fully implemented locally but returning the collection is enough for basic shim functionality.

export function query(collectionRef: any, ...args: any[]) {
    // Return collectionRef unmodified as the shim currently fetches the entire collection
    return collectionRef;
}

export function orderBy(str: string, ascDesc?: string) {
    return { type: 'orderBy', field: str, direction: ascDesc };
}
