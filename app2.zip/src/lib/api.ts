/**
 * This is a shim to replace Firebase with REST API calls pointing to server.ts
 */

export const db = {}; 

export function collection(db: any, name: string) {
    return { type: 'collection', name };
}

export function doc(db: any, name: string, id: string) {
    return { type: 'doc', name, id };
}

export async function getDoc(docRef: any) {
    const res = await fetch(`/api/${docRef.name}/${docRef.id}`);
    if (!res.ok) {
        if (res.status === 404) return { exists: () => false, data: () => null };
        const text = await res.text();
        throw new Error(`Failed to get doc: ${res.statusText} - ${text}`);
    }
    const data = await res.json();
    return {
        exists: () => !!data && !data.error,
        data: () => data
    };
}

export async function setDoc(docRef: any, data: any) {
    const res = await fetch(`/api/${docRef.name}/${docRef.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Failed to set doc: ${res.statusText} - ${text}`);
    }
}

export async function updateDoc(docRef: any, data: any) {
    const res = await fetch(`/api/${docRef.name}/${docRef.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });
    if (!res.ok) throw new Error("Failed to update doc");
}

export async function deleteDoc(docRef: any) {
    const res = await fetch(`/api/${docRef.name}/${docRef.id}`, {
        method: 'DELETE'
    });
    if (!res.ok) throw new Error("Failed to delete doc");
}

export function onSnapshot(ref: any, callback: (snap: any) => void, errorCallback?: (err: any) => void) {
    let isCancelled = false;
    const fetchLoop = async () => {
        while(!isCancelled) {
            try {
                if (ref.type === 'collection') {
                    const res = await fetch(`/api/${ref.name}`);
                    if (res.ok) {
                        const data = await res.json();
                        const docs = data.map((d: any) => ({
                            id: d.id,
                            exists: () => true,
                            data: () => d
                        }));
                        const snap = {
                            docs,
                            empty: docs.length === 0,
                            size: docs.length,
                            forEach(cb: any) {
                                docs.forEach(cb);
                            }
                        };
                        callback(snap);
                    }
                } else if (ref.type === 'doc') {
                    const res = await fetch(`/api/${ref.name}/${ref.id}`);
                    if (res.ok) {
                        const data = await res.json();
                        const snap = {
                            id: ref.id,
                            exists: () => !!data && !data.error,
                            data: () => data,
                            empty: !data || !!data.error
                        };
                        callback(snap);
                    }
                }
            } catch(e) {
                console.error("Polling error", e);
                if (errorCallback) {
                    try {
                        errorCallback(e);
                    } catch (err) {
                        console.error("Error in onSnapshot errorCallback:", err);
                    }
                }
            }
            await new Promise(r => setTimeout(r, 5000)); // Poll every 5 seconds
        }
    }
    
    // Initial fetch immediately
    fetchLoop();
    
    return () => { isCancelled = true; };
}

export function writeBatch(db: any) {
    return {
        _operations: [] as any[],
        set: function(docRef: any, data: any) { this._operations.push({ type: 'set', docRef, data }) },
        commit: async function() {
            for (const op of this._operations) {
               if (op.type === 'set') await setDoc(op.docRef, op.data);
            }
        }
    }
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
    console.error(`Error on ${operationType} at ${path}:`, error);
}
