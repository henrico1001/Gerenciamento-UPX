import { db } from './src/lib/api.js';

async function testFetch() {
  const res = await fetch('http://localhost:3000/api/counters');
  console.log(await res.text());
}
testFetch();
