import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import fs from 'fs';

const firebaseConfig = JSON.parse(fs.readFileSync('./firebase-applet-config.json', 'utf8'));
const app = initializeApp(firebaseConfig);
const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

async function listDocs() {
  const ticketsSnap = await getDocs(collection(db, 'tickets'));
  console.log('--- TICKETS ---');
  ticketsSnap.forEach(doc => {
    console.log(doc.id, typeof doc.id, doc.data());
  });

  const tambasaSnap = await getDocs(collection(db, 'tambasa_tickets'));
  console.log('--- TAMBASA TICKETS ---');
  tambasaSnap.forEach(doc => {
    console.log(doc.id, typeof doc.id, doc.data());
  });
}

listDocs().catch(console.error);
