import React, { useState } from 'react';
import { User, UserPosition, UserDepartment, UserRole } from '../types';
import { Users, Search, Shield, Briefcase, ChevronRight, Edit2, UserPlus, Trash2, KeyRound, X, Check, Save } from 'lucide-react';

interface AdminSettingsProps {
  users: User[];
  onUpdateUser: (user: User) => void;
  onAddUser: (user: Omit<User, 'id'>) => { success: boolean; message: string };
  onDeleteUser: (userId: string) => void;
  currentUser: User | null;
}

const DEPARTMENTS = ['Todos', 'Suporte', 'Comercial', 'Fábrica', 'Financeiro', 'Estoque', 'Estratégico'];

export default function AdminSettings({ users, onUpdateUser, onAddUser, onDeleteUser, currentUser }: AdminSettingsProps) {
  const [activeTab, setActiveTab] = useState('Todos');
  const [searchQuery, setSearchQuery] = useState('');

  const [editingUser, setEditingUser] = useState<User | null>(null);
  
  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchQuery.toLowerCase()) || user.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesDepartment = activeTab === 'Todos' || user.department === activeTab;
    return matchesSearch && matchesDepartment;
  });

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUser) {
      onUpdateUser(editingUser);
      setEditingUser(null);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-cyan-100 dark:bg-cyan-500/20 flex items-center justify-center">
          <Shield className="w-5 h-5 text-cyan-600 dark:text-cyan-400" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100">Configurações de Administrador</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">Gerencie todos os colaboradores e defina suas hierarquias e setores.</p>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm">
        <div className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 p-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex flex-wrap items-center gap-2">
            {DEPARTMENTS.map(dept => (
              <button
                key={dept}
                onClick={() => setActiveTab(dept)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
                  activeTab === dept
                    ? 'bg-cyan-500 text-white shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                {dept}
              </button>
            ))}
          </div>
          
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar colaborador..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-cyan-500 transition-colors text-slate-800 dark:text-slate-100 placeholder-slate-400"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/50 border-b border-slate-200 dark:border-slate-800">
                <th className="px-6 py-4 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Colaborador</th>
                <th className="px-6 py-4 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Setor</th>
                <th className="px-6 py-4 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Cargo / Tipo</th>
                <th className="px-6 py-4 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Status</th>
                <th className="px-6 py-4 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredUsers.length > 0 ? (
                filteredUsers.map(user => (
                  <tr key={user.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 font-bold text-xs">
                          {user.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 dark:text-slate-200 text-sm">{user.name}</p>
                          <p className="text-xs text-slate-500 dark:text-slate-400">{user.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {user.department || 'Não definido'}
                      </span>
                    </td>
                    <td className="px-6 py-4 space-y-1">
                      <span className={`inline-flex px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                        user.position === 'DONO' ? 'bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-500/10 dark:text-amber-400 dark:border-amber-500/20' :
                        user.position === 'CHEFE_SETOR' ? 'bg-indigo-50 text-indigo-600 border-indigo-200 dark:bg-indigo-500/10 dark:text-indigo-400 dark:border-indigo-500/20' :
                        'bg-slate-50 text-slate-600 border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700'
                      }`}>
                        {user.position === 'DONO' ? 'Administrador Geral (Dono)' :
                         user.position === 'CHEFE_SETOR' ? 'Chefe de Setor' : 
                         user.position === 'FUNCIONARIO' ? 'Funcionário' : 'Não definido'}
                      </span>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 font-medium ml-1">
                        Permissão: {user.role === 'ADMIN' ? 'Administrador' : 'Técnico'}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${user.status === 'ATIVO' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                        <span className="text-xs font-medium text-slate-700 dark:text-slate-300">
                          {user.status}
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => setEditingUser(user)}
                        className="p-2 text-slate-400 hover:text-cyan-500 transition-colors rounded-lg hover:bg-cyan-50 dark:hover:bg-slate-800 inline-flex items-center justify-center">
                        <Edit2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center">
                    <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Nenhum colaborador encontrado neste setor.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {editingUser && (
        <div className="fixed inset-0 bg-slate-900/40 dark:bg-slate-900/80 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-2xl shadow-xl overflow-hidden animate-fadeInScale border border-slate-200 dark:border-slate-800">
            <div className="flex justify-between items-center p-5 border-b border-slate-100 dark:border-slate-800">
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-cyan-500" />
                Editar Colaborador
              </h3>
              <button 
                onClick={() => setEditingUser(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleUpdate} className="p-5 space-y-5">
              <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl">
                <div className="w-10 h-10 rounded-full bg-cyan-100 dark:bg-cyan-500/20 flex items-center justify-center text-cyan-700 dark:text-cyan-400 font-bold">
                  {editingUser.name.charAt(0)}
                </div>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">{editingUser.name}</p>
                  <p className="text-xs text-slate-500 dark:text-slate-400">{editingUser.email}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-1">Setor (Departamento)</label>
                  <select 
                    value={editingUser.department || ''}
                    onChange={(e) => setEditingUser({...editingUser, department: e.target.value as UserDepartment})}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500 text-slate-800 dark:text-slate-100"
                  >
                    <option value="">Selecione um setor...</option>
                    {DEPARTMENTS.filter(d => d !== 'Todos').map(dept => (
                      <option key={dept} value={dept}>{dept}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-1">Hierarquia (Cargo)</label>
                  <select 
                    value={editingUser.position || ''}
                    onChange={(e) => setEditingUser({...editingUser, position: e.target.value as UserPosition})}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500 text-slate-800 dark:text-slate-100"
                  >
                    <option value="">Selecione a hierarquia...</option>
                    <option value="DONO">Administrador Geral (Dono)</option>
                    <option value="CHEFE_SETOR">Chefe de Setor</option>
                    <option value="FUNCIONARIO">Funcionário</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-600 dark:text-slate-400 block mb-1">Permissão Sistêmica</label>
                  <select 
                    value={editingUser.role}
                    onChange={(e) => setEditingUser({...editingUser, role: e.target.value as UserRole})}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-cyan-500 text-slate-800 dark:text-slate-100"
                  >
                    <option value="TECNICO">Técnico / Funcionario Padrão</option>
                    <option value="ADMIN">Administrador de Sistema (Acesso Total)</option>
                  </select>
                  <p className="text-[10px] text-slate-500 mt-1.5">Permissão de sistema determina se o usuário tem controle e visão de toda as áreas da aplicação.</p>
                </div>
              </div>

              <div className="bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/20 rounded-xl p-3 text-[11px] text-amber-700 dark:text-amber-400">
                Lembre-se: "Permissão Sistêmica" como Administrador dá controle total sobre as configurações da plataforma e listagem de chamados.
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 px-4 rounded-xl flex items-center justify-center gap-2 transition-colors shadow-sm"
                >
                  <Save className="w-4 h-4" />
                  Salvar Alterações
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
