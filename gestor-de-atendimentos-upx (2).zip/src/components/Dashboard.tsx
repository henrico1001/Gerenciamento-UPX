/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo } from 'react';
import { motion } from 'motion/react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { Ticket, User, TicketStatus, STATUS_LABELS } from '../types';
import { 
  CheckCircle2, 
  Clock, 
  TrendingUp, 
  Activity,
  Award,
  CalendarDays,
  ArrowRightLeft,
  ChevronRight,
  Sparkles,
  Inbox,
  AlertCircle
} from 'lucide-react';

interface DashboardProps {
  tickets: Ticket[];
  currentUser: User;
  allTechnicians: User[];
  onMetricClick?: (status: string) => void;
  onTicketClick?: (ticket: Ticket) => void;
}

export default function Dashboard({ tickets, currentUser, allTechnicians, onMetricClick, onTicketClick }: DashboardProps) {
  const isAdmin = currentUser.role === 'ADMIN';

  // Filter tickets according to role permissions (technician only sees their own)
  const scopedTickets = useMemo(() => {
    if (isAdmin) return tickets;
    return tickets.filter(t => t.technicianId === currentUser.id);
  }, [tickets, currentUser, isAdmin]);

  // Compute standard metrics
  const metrics = useMemo(() => {
    const total = scopedTickets.length;
    const resolved = scopedTickets.filter(t => t.status === 'RESOLVIDO').length;
    const inProgress = scopedTickets.filter(t => t.status === 'EM_ANDAMENTO').length;
    const pendingTransfers = scopedTickets.filter(t => t.transfer?.status === 'PENDENTE').length;

    return {
      total,
      resolved,
      inProgress,
      pendingTransfers,
      resolutionRate: total > 0 ? Math.round((resolved / total) * 100) : 0
    };
  }, [scopedTickets]);

  // Procedural Timeline of Genuine Activities in the System
  const recentActivities = useMemo(() => {
    interface SystemActivity {
      id: string;
      type: 'creation' | 'resolution' | 'transfer' | 'transfer_accepted';
      time: Date;
      text: string;
      boldTag?: string;
      user: string;
    }

    const events: SystemActivity[] = [];
    
    scopedTickets.forEach(t => {
      const ticketTime = new Date(t.dateTime);
      
      // 1. Open Event
      events.push({
        id: `${t.id}-creation`,
        type: 'creation',
        time: ticketTime,
        boldTag: `#${t.id}`,
        text: `aberto para ${t.companyName}`,
        user: t.technicianName
      });
      
      // 2. Closed Event
      if (t.status === 'RESOLVIDO') {
        const resolutionTime = new Date(ticketTime.getTime() + 1800000); // offset slightly
        events.push({
          id: `${t.id}-resolution`,
          type: 'resolution',
          time: resolutionTime,
          boldTag: `#${t.id}`,
          text: `declarado Resolvido em faturamento`,
          user: t.technicianName
        });
      }
      
      // 3. Transfer Events
      if (t.transfer) {
        const transferTime = new Date(t.transfer.timestamp);
        events.push({
          id: `${t.id}-transfer`,
          type: 'transfer',
          time: transferTime,
          boldTag: `#${t.id}`,
          text: `solicitada transferência para ${t.transfer.toName}`,
          user: t.transfer.fromName
        });

        if (t.transfer.status === 'ACEITO') {
          events.push({
            id: `${t.id}-transfer-accepted`,
            type: 'transfer_accepted',
            time: new Date(transferTime.getTime() + 900000),
            boldTag: `#${t.id}`,
            text: `transferência aceita e vinculada`,
            user: t.transfer.toName
          });
        }
      }
    });

    // Sort descending by date and return top 5
    return events
      .sort((a, b) => b.time.getTime() - a.time.getTime())
      .slice(0, 5);
  }, [scopedTickets]);

  // List of the latest registered calls
  const latestTickets = useMemo(() => {
    return [...scopedTickets]
      .sort((a, b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime())
      .slice(0, 5);
  }, [scopedTickets]);

  // Prepare Series Data: Tickets per Period (Last 10 days)
  const ticketsOverTimeData = useMemo(() => {
    const last10Days: { date: string; dateStr: string; Resolvidos: number; Em_Andamento: number; Total: number }[] = [];
    
    for (let i = 9; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateKey = d.toISOString().split('T')[0];
      const displayDate = d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
      
      const dayTickets = scopedTickets.filter(t => t.dateTime.startsWith(dateKey));
      const resolved = dayTickets.filter(t => t.status === 'RESOLVIDO').length;
      const other = dayTickets.length - resolved;

      last10Days.push({
        date: dateKey,
        dateStr: displayDate,
        Resolvidos: resolved,
        Em_Andamento: other,
        Total: dayTickets.length
      });
    }
    return last10Days;
  }, [scopedTickets]);

  // Prepare Support Team Performance Data
  const techProductivityData = useMemo(() => {
    const list = isAdmin ? allTechnicians.filter(u => u.role === 'TECNICO') : [currentUser];
    
    return list.map(tech => {
      const techTickets = tickets.filter(t => t.technicianId === tech.id);
      const resolved = techTickets.filter(t => t.status === 'RESOLVIDO').length;
      const inProgress = techTickets.filter(t => t.status === 'EM_ANDAMENTO').length;
      const transferredOut = tickets.filter(t => t.transfer?.fromId === tech.id && t.transfer?.status === 'ACEITO').length;
      
      return {
        name: tech.name.split(' ')[0],
        Resolvidos: resolved,
        'Em Andamento': inProgress,
        'Transferidos': transferredOut,
        Total: techTickets.length + transferredOut
      };
    }).sort((a, b) => b.Total - a.Total);
  }, [tickets, allTechnicians, currentUser, isAdmin]);

  // Pie chart status distribution
  const statusDistributionData = useMemo(() => {
    return [
      { name: 'Resolvidos', value: metrics.resolved, color: '#22c55e' },
      { name: 'Em Andamento', value: metrics.inProgress, color: '#f59e0b' }
    ].filter(item => item.value > 0);
  }, [metrics]);  return (
    <div className="space-y-6 animate-fadeIn" id="dashboard-tab-panel">
      
      {/* SaaS Welcome Intro */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-800/80 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold text-cyan-300 bg-cyan-950/60 border border-cyan-800/50 px-2.5 py-1 rounded-full tracking-wider flex items-center gap-1.5 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Support Core Console
            </span>
          </div>
          <h2 className="text-2xl font-black text-[#F8FAFC] mt-1 tracking-tight flex items-center gap-2.5">
            <Activity className="w-6 h-6 text-cyan-500 animate-pulse shrink-0" />
            Visão Geral do SGA
          </h2>
          <p className="text-[#94A3B8] text-xs mt-1 max-w-2xl font-medium leading-relaxed">
            {isAdmin 
              ? "Console consolidado de produtividade, faturamento técnico, volumetria de chamados e conformidade com SLA corporativo."
              : `Bem-vindo de volta, ${currentUser.name}! Veja aqui suas métricas de atendimento em tempo real.`
            }
          </p>
        </div>
        
        <div className="p-3 bg-[#1E293B]/90 border border-slate-800/80 text-[#94A3B8] rounded-xl text-xs font-mono flex items-center gap-2.5 select-none shadow-sm shadow-[#0F172A]">
          <CalendarDays className="w-4 h-4 text-cyan-500" />
          <span className="font-semibold text-[#F8FAFC]">Fuso Oficial: {new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })}</span>
        </div>
      </div>

      {/* Modern Bento SaaS Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-3 gap-5">
        
        {/* Metric 1: Total volume (Blue Indicator) */}
        <div 
          onClick={() => onMetricClick?.('')}
          className="bg-[#1E293B]/80 backdrop-blur-md p-6 rounded-2xl border border-slate-800/70 shadow-premium flex items-start justify-between relative overflow-hidden cursor-pointer hover:border-cyan-500 hover:-translate-y-1 hover:shadow-[#06b6d4]/5 hover:shadow-lg transition-all duration-300 active:scale-[0.99] select-none group" 
          id="metric-total"
        >
          {/* Subtle side glowing lines */}
          <div className="absolute top-0 left-0 w-1 bg-cyan-500 h-full"></div>
          <div className="space-y-2.5 flex-1 pl-1">
            <span className="text-[11px] font-extrabold text-[#94A3B8] uppercase tracking-widest block group-hover:text-cyan-400 transition-colors">Volume Total</span>
            <div className="flex items-baseline gap-2">
              <span className="text-3.5xl font-black text-[#F8FAFC] tracking-tight group-hover:scale-[1.01] transition-transform duration-300 block">{metrics.total}</span>
              <span className="text-xs text-slate-400 font-semibold">chamados</span>
            </div>
            <span className="text-[10.5px] text-[#94A3B8] block font-semibold group-hover:text-slate-100 transition-colors">
              Registros no banco • <span className="underline decoration-cyan-500 font-bold text-cyan-400">Ver todos</span>
            </span>
          </div>
          <div className="p-3.5 bg-cyan-500/10 text-cyan-420 text-cyan-400 rounded-xl border border-cyan-505/20 group-hover:bg-cyan-500/20 group-hover:border-cyan-505/40 transition-colors shrink-0">
            <Inbox className="w-5 h-5 text-cyan-400" />
          </div>
        </div>

        {/* Metric 2: Solved (Green/Sucesso Indicator) */}
        <div 
          onClick={() => onMetricClick?.('RESOLVIDO')}
          className="bg-[#1E293B]/80 backdrop-blur-md p-6 rounded-2xl border border-slate-800/70 shadow-premium flex items-start justify-between relative overflow-hidden cursor-pointer hover:border-emerald-500 hover:-translate-y-1 hover:shadow-[#22c55e]/5 hover:shadow-lg transition-all duration-300 active:scale-[0.99] select-none group" 
          id="metric-solved"
        >
          {/* Subtle side glowing lines */}
          <div className="absolute top-0 left-0 w-1 bg-emerald-500 h-full"></div>
          <div className="space-y-2.5 flex-1 pl-1">
            <span className="text-[11px] font-extrabold text-[#94A3B8] uppercase tracking-widest block group-hover:text-emerald-400 transition-colors">Resolvidos</span>
            <div className="flex items-baseline gap-2">
              <span className="text-3.5xl font-black text-emerald-400 tracking-tight group-hover:scale-[1.01] transition-transform duration-300 block">{metrics.resolved}</span>
              <span className="text-xs text-slate-400 font-semibold">finalizados</span>
            </div>
            <div className="flex items-center gap-1.5 text-[10.5px] text-emerald-400 font-bold transition-colors">
              <TrendingUp className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
              <span>SLA {metrics.resolutionRate}% concluído • <span className="underline font-bold text-emerald-450 text-emerald-400">Ver lista</span></span>
            </div>
          </div>
          <div className="p-3.5 bg-emerald-500/10 text-emerald-420 text-emerald-400 rounded-xl border border-emerald-505/20 group-hover:bg-emerald-500/20 group-hover:border-emerald-505/40 transition-colors shrink-0">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          </div>
        </div>

        {/* Metric 3: Em Andamento (Yellow/Atenção Indicator) */}
        <div 
          onClick={() => onMetricClick?.('EM_ANDAMENTO')}
          className="bg-[#1E293B]/80 backdrop-blur-md p-6 rounded-2xl border border-slate-800/70 shadow-premium flex items-start justify-between relative overflow-hidden cursor-pointer hover:border-amber-500 hover:-translate-y-1 hover:shadow-[#f59e0b]/5 hover:shadow-lg transition-all duration-300 active:scale-[0.99] select-none group" 
          id="metric-pending"
        >
          {/* Subtle side glowing lines */}
          <div className="absolute top-0 left-0 w-1 bg-amber-500 h-full"></div>
          <div className="space-y-2.5 flex-1 pl-1">
            <span className="text-[11px] font-extrabold text-[#94A3B8] uppercase tracking-widest block group-hover:text-amber-450 text-amber-400 transition-colors">Em Andamento</span>
            <div className="flex items-baseline gap-2">
              <span className="text-3.5xl font-black text-amber-500 tracking-tight group-hover:scale-[1.01] transition-transform duration-300 block">{metrics.inProgress}</span>
              <span className="text-xs text-slate-445 text-slate-400 font-semibold">em andamento</span>
            </div>
            <span className="text-[10.5px] text-[#94A3B8] block font-bold group-hover:text-slate-100 transition-colors">
              Aguardando ação • <span className="underline decoration-amber-500 font-bold text-amber-405 text-amber-400">Gerenciar</span>
            </span>
          </div>
          <div className="p-3.5 bg-amber-500/10 text-amber-420 text-amber-400 rounded-xl border border-amber-505/20 group-hover:bg-amber-500/20 group-hover:border-amber-505/40 transition-colors shrink-0">
            <Clock className="w-5 h-5 text-amber-400" />
          </div>
        </div>
      </div>

      {/* Main Charts & Analytics Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Interactive Chart: Volume over time (SaaS Custom design) */}
        <div className="lg:col-span-8 bg-[#1E293B]/80 backdrop-blur-lg p-6 rounded-2xl border border-slate-800/85 hover:border-cyan-500/35 shadow-premium space-y-4 transition-all duration-350">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <h3 className="text-sm font-extrabold text-[#F8FAFC] uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 shadow-sm shadow-cyan-500/30"></span> Projeção Diária de Atendimentos
              </h3>
              <p className="text-xs text-[#94A3B8] font-semibold">Análise de chamados criados e faturados nos últimos 10 dias de operação.</p>
            </div>
            <span className="text-[10px] bg-[#0F172A] border border-slate-800/80 px-2.5 py-1 text-cyan-405 font-mono rounded-lg font-bold">
              Histórico Operacional Activo
            </span>
          </div>

          <div className="h-[280px] w-full mt-2" id="period-chart-container">
            {metrics.total === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-[#94A3B8] border border-dashed border-slate-800 rounded-xl bg-slate-950/25">
                Nenhum chamado registrado para gerar gráficos.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={ticketsOverTimeData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorTotalSaaS" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.25}/>
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                    </linearGradient>
                    <linearGradient id="colorResolvidosSaaS" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#22c55e" stopOpacity={0.25}/>
                      <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#334155" opacity={0.3} />
                  <XAxis dataKey="dateStr" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} allowDecimals={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '12px', color: '#fff', fontSize: '11px', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.5)' }}
                    labelClassName="font-bold text-cyan-400"
                  />
                  <Area type="monotone" name="Total Criado" dataKey="Total" stroke="#06b6d4" strokeWidth={2.5} fillOpacity={1} fill="url(#colorTotalSaaS)" />
                  <Area type="monotone" name="Resolvidos" dataKey="Resolvidos" stroke="#22c55e" strokeWidth={2.5} fillOpacity={1} fill="url(#colorResolvidosSaaS)" />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>
          <div className="flex gap-5 items-center justify-center text-xs text-[#94A3B8] font-bold pt-3 border-t border-slate-800/60 mt-2">
            <div className="flex items-center gap-2">
              <div className="w-3 h-1.5 rounded-full bg-cyan-550 bg-cyan-500 shadow-sm shadow-cyan-500/30"></div>
              <span>Total de Chamados Abertos</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-1.5 rounded-full bg-emerald-555 bg-emerald-500 shadow-sm shadow-emerald-500/30"></div>
              <span>Chamados Resolvidos</span>
            </div>
          </div>
        </div>

        {/* Doughnut Chart: Distribution of Statuses (SaaS Model) */}
        <div className="lg:col-span-4 bg-[#1E293B]/80 backdrop-blur-lg p-6 rounded-2xl border border-slate-800/85 hover:border-emerald-500/35 shadow-premium flex flex-col justify-between transition-all duration-350">
          <div>
            <h3 className="text-sm font-extrabold text-[#F8FAFC] uppercase tracking-wider flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/30"></span> Proporção de SLA
            </h3>
            <p className="text-xs text-[#94A3B8] font-semibold">Taxa de resolução e eficiência em tempo real.</p>
          </div>

          <div className="h-[185px] flex items-center justify-center relative my-4" id="doughnut-chart-container">
            {metrics.total === 0 ? (
              <span className="text-xs text-slate-500 font-bold">Sem dados estatísticos</span>
            ) : (
              <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusDistributionData}
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={75}
                      paddingAngle={4}
                      dataKey="value"
                    >
                      {statusDistributionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ fontSize: '11px', borderRadius: '12px', backgroundColor: '#0f172a', border: '1px solid #334155' }} />
                  </PieChart>
                </ResponsiveContainer>
                
                {/* Center Badge with resolving rate */}
                <div className="absolute flex flex-col items-center justify-center">
                  <span className="text-3.5xl font-black text-[#F8FAFC] tracking-tight">{metrics.resolutionRate}%</span>
                  <span className="text-[9px] text-[#94A3B8] uppercase tracking-widest font-extrabold mt-0.5">Taxa Corrente</span>
                </div>
              </>
            )}
          </div>

          <div className="space-y-2 border-t border-slate-800/60 pt-3.5 text-xs text-[#94A3B8] font-bold">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/20"></span>
                <span className="font-semibold text-slate-350">Resolvidos</span>
              </div>
              <span className="font-extrabold text-[#F8FAFC]">{metrics.resolved}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-sm shadow-amber-500/20"></span>
                <span className="font-semibold text-slate-350">Em Andamento</span>
              </div>
              <span className="font-extrabold text-[#F8FAFC]">{metrics.inProgress}</span>
            </div>
          </div>
        </div>

      </div>

      {/* Row 2: Bento Split containing Team Performance, Recent Real Activities & Latest Tickets */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Performance Grid (8 columns) */}
        <div className="lg:col-span-8 bg-[#1E293B]/85 backdrop-blur-lg p-6 rounded-2xl border border-slate-800/85 shadow-premium space-y-5 hover:border-amber-500/30 transition-all duration-350">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-extrabold text-[#F8FAFC] uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shadow-sm shadow-amber-500/20"></span>
                {isAdmin ? "Desempenho Geral do Time de Logística" : "Estatísticas Técnicas Pessoais"}
              </h3>
              <p className="text-xs text-[#94A3B8] font-semibold">Indicadores de progresso de tickets pendentes e faturados por técnico.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            
            <div className="md:col-span-12 h-[230px] w-full" id="productivity-chart-container">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={techProductivityData} margin={{ top: 5, right: 10, left: -25, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.25} vertical={false} />
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} allowDecimals={false} />
                  <Tooltip cursor={{ fill: 'rgba(30, 41, 59, 0.4)' }} contentStyle={{ fontSize: '11px', borderRadius: '12px', backgroundColor: '#0f172a', border: '1px solid #334155' }} />
                  <Bar name="Resolvidos" dataKey="Resolvidos" stackId="a" fill="#22c55e" />
                  <Bar name="Em Andamento" dataKey="Em Andamento" stackId="a" fill="#f59e0b" />
                  <Bar name="Transf. Aceitas" dataKey="Transferidos" stackId="a" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Right Side: Status Distribution indicator (4 columns) */}
        <div className="lg:col-span-4 bg-[#1E293B]/85 backdrop-blur-lg p-6 rounded-2xl border border-slate-800/85 shadow-premium flex flex-col justify-between hover:border-cyan-500/30 transition-all duration-350">
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-extrabold text-[#F8FAFC] uppercase tracking-wider flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-500 animate-ping"></span>
                Eficiência Operacional
              </h3>
              <p className="text-xs text-[#94A3B8] mt-0.5 font-semibold">Visão consolidada da conformidade geral de prazos.</p>
            </div>

            <div className="bg-[#0F172A]/50 p-4 rounded-xl border border-slate-800/70 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[11px] text-slate-400 font-bold">Total de Chamados</span>
                <span className="text-xs font-bold font-mono text-slate-200">{metrics.total}</span>
              </div>
              <div className="w-full bg-slate-800/60 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-cyan-500 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${metrics.total > 0 ? 100 : 0}%` }}
                />
              </div>

              <div className="flex justify-between items-center pt-1">
                <span className="text-[11px] text-slate-400 font-bold">Resolvidos</span>
                <span className="text-xs font-bold font-mono text-slate-200">{metrics.resolved}</span>
              </div>
              <div className="w-full bg-slate-800/60 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${metrics.total > 0 ? (metrics.resolved / metrics.total) * 100 : 0}%` }}
                />
              </div>

              <div className="flex justify-between items-center pt-1">
                <span className="text-[11px] text-slate-400 font-bold">Em Andamento</span>
                <span className="text-xs font-bold font-mono text-slate-200">{metrics.inProgress}</span>
              </div>
              <div className="w-full bg-slate-800/60 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-amber-500 h-full rounded-full transition-all duration-500" 
                  style={{ width: `${metrics.total > 0 ? (metrics.inProgress / metrics.total) * 100 : 0}%` }}
                />
              </div>
            </div>

            <div className="text-[11px] text-[#94A3B8] leading-relaxed italic bg-[#0F172A]/30 p-3.5 rounded-lg border border-slate-800/50 font-medium">
              💡 Os dados acima refletem as ações imediatas inseridas no banco da UPX de forma persistente.
            </div>
          </div>
        </div>

      </div>

      {/* Row 3: Procedural Real-time Activities feed & Latest calls registered */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
        
        {/* Panel 1: Atividades Recentes (Procedural System Timeline) */}
        <div className="bg-[#1E293B]/80 backdrop-blur-lg p-6 rounded-2xl border border-slate-800/85 hover:border-cyan-500/30 shadow-premium flex flex-col justify-between transition-all duration-350">
          <div>
            <h3 className="text-sm font-extrabold text-[#F8FAFC] uppercase tracking-wider flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-500" />
              Painel de Atividades Recentes
            </h3>
            <p className="text-xs text-[#94A3B8] mt-0.5 font-semibold">Feed procedimental de integridade operacional com rastreabilidade de suporte.</p>
          </div>

          <div className="mt-5 space-y-4 max-h-[310px] overflow-y-auto pr-1">
            {recentActivities.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl font-medium">
                Nenhuma atividade recente registrada em atendimentos.
              </div>
            ) : (
              recentActivities.map((act) => {
                const isCreation = act.type === 'creation';
                const isResolution = act.type === 'resolution';
                const isTransfer = act.type === 'transfer' || act.type === 'transfer_accepted';

                let iconBg = 'bg-cyan-500/10 border-cyan-800/40 text-cyan-400';
                if (isResolution) iconBg = 'bg-emerald-500/10 border-emerald-800/40 text-emerald-400';
                if (isTransfer) iconBg = 'bg-amber-500/10 border-amber-800/40 text-amber-400';

                return (
                  <div key={act.id} className="flex gap-3 text-xs items-start border-b border-slate-800 pb-3 last:border-0 last:pb-0 hover:bg-[#0F172A]/35 p-1.5 rounded-lg transition-colors group">
                    <div className={`p-1.5 rounded-lg border ${iconBg} shrink-0 mt-0.5 font-bold font-mono text-[9px] uppercase tracking-wide`}>
                      {act.type === 'creation' && 'aberto'}
                      {act.type === 'resolution' && 'resolvido'}
                      {act.type === 'transfer' && 'transf'}
                      {act.type === 'transfer_accepted' && 'vinc'}
                    </div>
                    
                    <div className="space-y-0.5 flex-1 select-text">
                      <p className="text-[#94A3B8] leading-relaxed font-semibold">
                        <strong className="text-[#F8FAFC] group-hover:text-cyan-400 transition-colors font-bold">{act.user}</strong> {act.text} {act.boldTag && <strong className="text-slate-200 bg-[#0F172A] border border-slate-800 px-1.5 py-0.5 rounded font-mono font-bold text-[10px]">{act.boldTag}</strong>}
                      </p>
                      
                      <p className="text-[10px] text-slate-400 font-mono flex items-center gap-1 mt-1 font-semibold">
                        <Clock className="w-3.5 h-3.5 text-slate-400" />
                        <span>{new Date(act.time).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })} — {new Date(act.time).toLocaleDateString('pt-BR')}</span>
                      </p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Panel 2: Últimos Chamados Cadastrados */}
        <div className="bg-[#1E293B]/80 backdrop-blur-lg p-6 rounded-2xl border border-slate-800/85 hover:border-emerald-500/30 shadow-premium flex flex-col justify-between transition-all duration-350">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-sm font-extrabold text-[#F8FAFC] uppercase tracking-wider flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                Últimos Chamados Cadastrados
              </h3>
              <p className="text-xs text-[#94A3B8] mt-0.5 font-semibold">Últimos atendimentos para respostas rápidas.</p>
            </div>
            
            <span className="text-[9px] bg-[#0F172A] border border-slate-800 px-2.5 py-1 text-slate-350 font-mono rounded font-bold uppercase">
              Recém-Inseridos
            </span>
          </div>

          <div className="mt-5 space-y-3.5 max-h-[310px] overflow-y-auto pr-1">
            {latestTickets.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-500 border border-dashed border-slate-800 rounded-xl font-medium">
                Nenhum chamado cadastrado disponível.
              </div>
            ) : (
              latestTickets.map((t) => {
                const isResolved = t.status === 'RESOLVIDO';
                const statusBadge = isResolved
                  ? 'bg-emerald-550/15 border-emerald-800/30 text-emerald-400'
                  : 'bg-amber-555/15 border-amber-800/30 text-amber-400';

                return (
                  <div 
                    key={t.id} 
                    onClick={() => onTicketClick?.(t)}
                    className="p-3 bg-[#0F172A]/40 rounded-xl border border-slate-850 flex items-center justify-between gap-3 text-xs hover:border-slate-705 dark:hover:border-slate-700/80 hover:bg-[#0F172A]/60 transition-all cursor-pointer group"
                  >
                    <div className="space-y-1 truncate flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[10.5px] bg-slate-850 text-slate-300 border border-slate-750 px-1.5 py-0.5 rounded">
                          #{t.id}
                        </span>
                        <h4 className="font-black text-[#F8FAFC] group-hover:text-cyan-450 group-hover:text-cyan-400 transition-colors truncate uppercase max-w-[170px]" title={t.companyName}>
                          {t.companyName}
                        </h4>
                      </div>
                      <p className="text-[11px] text-[#94A3B8] truncate font-medium">
                        Cliente: <span className="font-bold text-slate-200">{t.clientName}</span> | Prod: <span className="text-slate-300 font-semibold">{t.problemCategory.slice(0, 40)}...</span>
                      </p>
                      
                    </div>

                    <div className="text-right shrink-0 flex items-center gap-2.5">
                      <div className="space-y-1.5">
                        <span className={`px-2.5 py-0.5 rounded-full text-[9px] font-extrabold uppercase border tracking-wider ${statusBadge}`}>
                          {isResolved ? 'Resolvido' : 'Em Andamento'}
                        </span>
                        <span className="text-[9.5px] text-slate-400 block font-mono font-bold">
                          {new Date(t.dateTime).toLocaleDateString('pt-BR')}
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-cyan-400 group-hover:translate-x-0.5 transition-all" />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
