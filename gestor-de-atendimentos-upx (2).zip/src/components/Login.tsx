/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  KeyRound, 
  Shield, 
  AlertCircle, 
  Wrench, 
  UserPlus, 
  LogIn, 
  ChevronRight, 
  Check, 
  ArrowLeft,
  Lock,
  Mail,
  User as UserIcon
} from 'lucide-react';
import { User, UserRole } from '../types';
import { getStoredUsers, saveUsers } from '../utils/mockData';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';

interface LoginProps {
  onLoginSuccess: (user: User) => void;
  technicians: User[];
}

export default function Login({ onLoginSuccess, technicians }: LoginProps) {
  // Login form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  // First Access Setup states
  const [isFirstAccessMode, setIsFirstAccessMode] = useState(false);
  const [setupEmail, setSetupEmail] = useState('');
  const [setupPwd, setSetupPwd] = useState('');
  const [setupPwdConfirm, setSetupPwdConfirm] = useState('');
  const [setupError, setSetupError] = useState('');
  const [setupSuccess, setSetupSuccess] = useState('');

  const users = technicians && technicians.length > 0 ? technicians : getStoredUsers();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email || !password) {
      setError('Por favor, preencha todos os campos do formulário.');
      return;
    }

    // Admin login
    if (email.toLowerCase() === 'eng1@upxsolution.com.br' && password === '10011972') {
      const adminUser = users.find(u => u.role === 'ADMIN');
      if (adminUser) {
        onLoginSuccess(adminUser);
        return;
      }
    }

    // Technician login
    const foundUser = users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (foundUser) {
      if (foundUser.status === 'INATIVO') {
        setError('Este técnico de suporte está inativo. Contate o administrador.');
        return;
      }

      // Check user password; defaults to '' if not defined yet
      const expectedPassword = foundUser.password || '';
      
      if (!expectedPassword) {
        setError('Este técnico ainda não cadastrou uma senha de primeiro acesso! Clique no link "Primeiro acesso? Cadastre sua senha" abaixo.');
        return;
      }

      if (password === expectedPassword) {
        onLoginSuccess(foundUser);
        return;
      } else {
        setError('Senha incorreta para este técnico. Contate o administrador ou verifique a senha.');
        return;
      }
    }

    setError('Usuário não encontrado. O cadastro de novos técnicos deve ser solicitado ao Administrador.');
  };

  const handleFirstAccessSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSetupError('');
    setSetupSuccess('');

    if (!setupEmail || !setupPwd || !setupPwdConfirm) {
      setSetupError('Por favor, preencha todos os campos.');
      return;
    }

    if (setupPwd.length < 4) {
      setSetupError('A senha precisa conter pelo menos 4 caracteres.');
      return;
    }

    if (setupPwd !== setupPwdConfirm) {
      setSetupError('As senhas digitadas não batem.');
      return;
    }

    const allUsers = users;
    const userIndex = allUsers.findIndex(u => u.email.toLowerCase() === setupEmail.trim().toLowerCase() && u.role === 'TECNICO');

    if (userIndex === -1) {
      setSetupError('E-mail corporativo não cadastrado. Certifique-se de que o Administrador já efetuou seu cadastro inicial no painel.');
      return;
    }

    if (allUsers[userIndex].status === 'INATIVO') {
      setSetupError('Sua conta de técnico está desativada no momento. Solicite a reativação com o Administrador.');
      return;
    }

    // Update technician password and save securely to Firestore
    const techUserId = allUsers[userIndex].id;
    updateDoc(doc(db, 'users', techUserId), { password: setupPwd })
      .catch((err) => {
        handleFirestoreError(err, OperationType.UPDATE, `users/${techUserId}`);
      });

    setSetupSuccess('Senha cadastrada com sucesso! Ativação de credencial concluída.');
    
    // Auto fill and transition back to login form
    setTimeout(() => {
      setEmail(setupEmail);
      setIsFirstAccessMode(false);
      setSetupEmail('');
      setSetupPwd('');
      setSetupPwdConfirm('');
      setSetupSuccess('');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4 selection:bg-cyan-500 selection:text-white" id="login-container">
      {/* Background decoration */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-[10%] -right-[10%] w-[50%] h-[50%] bg-cyan-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-12 gap-8 items-center relative z-10">
        
        {/* Left Column: Branding Description */}
        <div className="col-span-1 md:col-span-5 text-left text-white space-y-8 animate-fadeIn">
          {/* Logo */}
          <div className="flex items-center gap-3">
             <img 
               src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNihFkMakDJ_PHpwVWeSTaeSkMGfg-xeTWvg&s" 
               alt="UPX Logo" 
               className="w-16 h-16 object-contain rounded-2xl" 
             />
             <span className="font-bold text-xl tracking-tight text-[#ffffff]">UPX</span>
          </div>

          {/* Heading */}
          <div className="space-y-3">
            <h1 className="text-5xl font-extrabold tracking-tighter leading-tight text-[#f2f2f2]">Olá,<br/>seja bem-vindo!</h1>
            <p className="text-blue-100 text-sm leading-relaxed max-w-sm font-medium">
              Plataforma corporativa centralizada para controle, abertura, edição e rastreabilidade de chamados de atendimento técnico.
            </p>
          </div>
        </div>

        {/* Right Column: Auth Portal Card */}
        <div className="col-span-1 md:col-span-7 space-y-4">
          
          {!isFirstAccessMode ? (
            /* STANDARD LOGIN INTERFACE */
            <div className="bg-slate-800/95 backdrop-blur-md rounded-2xl border border-slate-700/60 p-6 md:p-8 shadow-2xl space-y-6 animate-fadeIn">
              
              <div className="border-b border-slate-700 pb-4">
                <h3 className="text-lg font-semibold text-[#dcdcdc] flex items-center gap-2">
                  <LogIn className="w-5 h-5 text-cyan-400" />
                  Login no Sistema
                </h3>
              </div>

              {error && (
                <div className="p-3 bg-rose-955/40 border border-rose-800 text-rose-200 text-xs rounded-xl flex items-center gap-2 animate-shake" id="auth-error-alert">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4" id="form-login">
                <div>
                  <label className="block text-xs text-slate-400 mb-1.5 font-medium" htmlFor="email-input">
                    E-mail do Colaborador
                  </label>
                  <input
                    type="email"
                    id="email-input"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="ex: gabriel.mendes@upx.com"
                    className="w-full bg-slate-900 border border-slate-700 px-4 py-3 rounded-xl focus:border-cyan-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500 transition-colors"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="text-xs text-slate-400 font-medium" htmlFor="password-input">
                      Senha de Acesso
                    </label>
                  </div>
                  <input
                    type="password"
                    id="password-input"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Digite a sua senha"
                    className="w-full bg-slate-900 border border-slate-705 px-4 py-3 rounded-xl focus:border-cyan-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500 transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  id="btn-login-submit"
                  className="w-full bg-cyan-600 hover:bg-cyan-500 active:bg-cyan-700 text-white font-medium py-3 rounded-xl transition-all shadow-lg shadow-cyan-900/40 text-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  Continuar
                  <ChevronRight className="w-4 h-4" />
                </button>
              </form>

              {/* Action for first access */}
              <div className="pt-4 border-t border-slate-700/60 flex flex-col items-center justify-between gap-2.5 text-xs">
                <button 
                  type="button"
                  onClick={() => {
                    setSetupEmail('');
                    setSetupPwd('');
                    setSetupPwdConfirm('');
                    setSetupError('');
                    setSetupSuccess('');
                    setIsFirstAccessMode(true);
                  }}
                  className="text-cyan-400 hover:text-cyan-300 font-bold tracking-wide transition-colors cursor-pointer flex items-center gap-1.5"
                  id="btn-goto-first-access"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  Primeiro acesso? Cadastre sua senha de técnico
                </button>
                <span className="text-[10px] text-slate-500">
                  Dúvidas? Entre em contato com a equipe de engenharia e suporte.
                </span>
              </div>

            </div>
          ) : (
            /* FIRST ACCESS / ACCOUNT ACTIVATION INTERFACE */
            <div className="bg-slate-800/95 backdrop-blur-md rounded-2xl border border-slate-700/60 p-6 md:p-8 shadow-2xl space-y-6 animate-fadeIn">
              
              <div className="flex items-center justify-between border-b border-slate-700 pb-4">
                <h3 className="text-lg font-semibold text-slate-150 flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-cyan-400" />
                  Primeiro Acesso do Técnico
                </h3>
                <button
                  type="button"
                  onClick={() => setIsFirstAccessMode(false)}
                  className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-medium transition-colors cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" /> Voltar ao Login
                </button>
              </div>

              <p className="text-xs text-slate-400 leading-normal bg-slate-900 p-3 rounded-xl border border-slate-750">
                Se você foi cadastrado pelo Diretor/Admin no painel, digite seu e-mail corporativo cadastrado abaixo para definir sua senha de acesso exclusiva ao sistema de chamados.
              </p>

              {setupError && (
                <div className="p-3 bg-rose-955/40 border border-rose-800 text-rose-200 text-xs rounded-xl flex items-center gap-2" id="setup-error-alert">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{setupError}</span>
                </div>
              )}

              {setupSuccess && (
                <div className="p-3 bg-emerald-950/40 border border-emerald-800 text-emerald-250 text-xs rounded-xl flex items-center gap-2" id="setup-success-alert">
                  <Check className="w-4 h-4 text-emerald-450 shrink-0" />
                  <span>{setupSuccess}</span>
                </div>
              )}

              <form onSubmit={handleFirstAccessSubmit} className="space-y-4" id="form-first-access-setup">
                <div>
                  <label className="block text-xs text-slate-400 mb-1.5 font-medium" htmlFor="setup-email-input">
                    E-mail Corporativo Cadastrado
                  </label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                      <Mail className="w-4 h-4" />
                    </span>
                    <input
                      type="email"
                      id="setup-email-input"
                      value={setupEmail}
                      onChange={(e) => setSetupEmail(e.target.value)}
                      placeholder="ex: nome.sobrenome@upx.com"
                      className="w-full bg-slate-900 border border-slate-700 pl-9 pr-4 py-3 rounded-xl focus:border-cyan-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500 transition-colors"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5 font-medium" htmlFor="setup-pwd-input">
                      Crie sua Nova Senha
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                        <Lock className="w-4 h-4" />
                      </span>
                      <input
                        type="password"
                        id="setup-pwd-input"
                        value={setupPwd}
                        onChange={(e) => setSetupPwd(e.target.value)}
                        placeholder="Mínimo 4 dígitos"
                        className="w-full bg-slate-900 border border-slate-700 pl-9 pr-4 py-3 rounded-xl focus:border-cyan-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500 font-mono transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5 font-medium" htmlFor="setup-pwd-confirm-input">
                      Confirme a Nova Senha
                    </label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                        <Lock className="w-4 h-4" />
                      </span>
                      <input
                        type="password"
                        id="setup-pwd-confirm-input"
                        value={setupPwdConfirm}
                        onChange={(e) => setSetupPwdConfirm(e.target.value)}
                        placeholder="Redigite para confirmar"
                        className="w-full bg-slate-900 border border-slate-700 pl-9 pr-4 py-3 rounded-xl focus:border-cyan-500 focus:outline-none text-sm text-slate-100 placeholder-slate-500 font-mono transition-colors"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  id="btn-setup-submit"
                  className="w-full bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg text-sm flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Check className="w-4.5 h-4.5" />
                  Cadastrar Senha e Ativar Conta
                </button>
              </form>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
