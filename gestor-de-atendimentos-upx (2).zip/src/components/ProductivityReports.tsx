/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useMemo, useState } from 'react';
import { Ticket, User, TicketStatus, STATUS_LABELS } from '../types';
import { 
  BarChart, 
  TrendingUp, 
  Printer, 
  UserCheck, 
  FileText, 
  Milestone, 
  Calendar,
  AlertCircle,
  Clock,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Download,
  Filter,
  Users,
  Maximize2,
  ChevronDown,
  ChevronRight,
  Info
} from 'lucide-react';

interface ProductivityReportsProps {
  tickets: Ticket[];
  technicians: User[];
  onBackToDashboard?: () => void;
}

export default function ProductivityReports({ tickets, technicians, onBackToDashboard }: ProductivityReportsProps) {
  const [selectedTechId, setSelectedTechId] = useState('');
  const [isPrinting, setIsPrinting] = useState(false);
  const [showBiGuidance, setShowBiGuidance] = useState(false);
  const [activeViewMode, setActiveViewMode] = useState<'powerbi' | 'classic'>('powerbi');
  const [isPowerBiFullscreen, setIsPowerBiFullscreen] = useState(false);

  // Time tree checkboxes states
  const [checkedYears, setCheckedYears] = useState<Record<number, boolean>>({});
  const [checkedMonths, setCheckedMonths] = useState<Record<string, boolean>>({});
  const [expandedYears, setExpandedYears] = useState<Record<number, boolean>>({ 2026: true });

  const techCollaborators = useMemo(() => {
    return technicians.filter(u => u.role === 'TECNICO');
  }, [technicians]);

  // Months name array for indices
  const mesesNomes = useMemo(() => [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", 
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
  ], []);

  // Compute available Years and Months in DB for natural tree filtering
  const timeFilterOptions = useMemo(() => {
    const yearsMap: Record<number, Set<string>> = {};
    
    tickets.forEach(t => {
      const d = new Date(t.dateTime);
      if (!isNaN(d.getTime())) {
        const yr = d.getFullYear();
        const mName = mesesNomes[d.getMonth()];
        if (!yearsMap[yr]) {
          yearsMap[yr] = new Set();
        }
        yearsMap[yr].add(mName);
      }
    });

    return Object.keys(yearsMap).map(Number).sort((a, b) => b - a).map(yr => ({
      year: yr,
      months: Array.from(yearsMap[yr]).sort((a, b) => mesesNomes.indexOf(a) - mesesNomes.indexOf(b))
    }));
  }, [tickets, mesesNomes]);

  // Handle year select toggles
  const handleYearToggle = (yr: number) => {
    const isCurrentlyChecked = checkedYears[yr] !== false;
    const nextState = !isCurrentlyChecked;
    
    // Toggle year
    setCheckedYears(prev => ({ ...prev, [yr]: nextState }));
    
    // Auto toggle its children months
    const yearOption = timeFilterOptions.find(o => o.year === yr);
    if (yearOption) {
      setCheckedMonths(prev => {
        const updated = { ...prev };
        yearOption.months.forEach(m => {
          updated[`${yr}-${m}`] = nextState;
        });
        return updated;
      });
    }
  };

  // Handle month select toggles
  const handleMonthToggle = (yr: number, mName: string) => {
    const key = `${yr}-${mName}`;
    const nextState = !(checkedMonths[key] !== false);
    setCheckedMonths(prev => ({ ...prev, [key]: nextState }));
  };

  // Filter tickets dynamically based on selected checkboxes
  const filteredTickets = useMemo(() => {
    return tickets.filter(t => {
      const d = new Date(t.dateTime);
      if (isNaN(d.getTime())) return true;
      const yr = d.getFullYear();
      const mName = mesesNomes[d.getMonth()];
      
      const yrChecked = checkedYears[yr] !== false;
      const mChecked = checkedMonths[`${yr}-${mName}`] !== false;
      
      return yrChecked && mChecked;
    });
  }, [tickets, checkedYears, checkedMonths, mesesNomes]);

  // Compute stats per technician on filtered data
  const technicianStats = useMemo(() => {
    return techCollaborators.map(tech => {
      const techTickets = filteredTickets.filter(t => t.technicianId === tech.id);
      
      const created = filteredTickets.filter(t => 
        (t.transfer?.fromId === tech.id) || 
        (t.technicianId === tech.id && (!t.transfer || t.transfer.status !== 'ACEITO'))
      ).length;

      const transferredOut = filteredTickets.filter(t => t.transfer?.fromId === tech.id && t.transfer?.status === 'ACEITO').length;
      const transferredIn = filteredTickets.filter(t => t.transfer?.toId === tech.id && t.transfer?.status === 'ACEITO').length;

      const resolved = techTickets.filter(t => t.status === 'RESOLVIDO').length;
      const inProgress = techTickets.filter(t => t.status === 'SUSPENSO').length;
      const rate = techTickets.length > 0 ? Math.round((resolved / techTickets.length) * 100) : 0;

      return {
        techId: tech.id,
        name: tech.name,
        email: tech.email,
        total: techTickets.length,
        created,
        transferredOut,
        transferredIn,
        resolved,
        inProgress,
        resolutionRate: rate,
        tickets: techTickets
      };
    }).sort((a, b) => b.resolutionRate - a.resolutionRate); // rank by efficiency
  }, [techCollaborators, filteredTickets]);

  // General statistics using filtered dataset
  const generalStats = useMemo(() => {
    const total = filteredTickets.length;
    const resolved = filteredTickets.filter(t => t.status === 'RESOLVIDO').length;
    const rate = total > 0 ? Math.round((resolved / total) * 100) : 100;
    const open = filteredTickets.filter(t => t.status !== 'RESOLVIDO').length;
    const suspended = filteredTickets.filter(t => t.status === 'SUSPENSO').length;

    // Most common problem category
    const problemCounts = filteredTickets.reduce((acc, t) => {
      acc[t.problemCategory] = (acc[t.problemCategory] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    let topProblem = "Nenhum chamado registrado";
    let topProblemCount = 0;
    Object.entries(problemCounts).forEach(([prob, countVal]) => {
      const count = countVal as number;
      if (count > topProblemCount) {
        topProblem = prob;
        topProblemCount = count;
      }
    });

    return {
      total,
      resolved,
      resolutionRate: rate,
      open,
      suspended,
      topProblem,
      topProblemCount
    };
  }, [filteredTickets]);

  // Power BI Visual: Total Open by Reason
  const openByReason = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredTickets.forEach(t => {
      if (t.status !== 'RESOLVIDO') {
        counts[t.problemCategory] = (counts[t.problemCategory] || 0) + 1;
      }
    });
    return Object.entries(counts)
      .map(([category, count]) => ({ category, count }))
      .sort((a, b) => b.count - a.count);
  }, [filteredTickets]);

  // Power BI Visual: SLA Extrapolated by Reason (Suspended / Open)
  const nonResolvedByReason = useMemo(() => {
    const counts: Record<string, number> = {};
    let totalNonResolved = 0;
    filteredTickets.forEach(t => {
      if (t.status !== 'RESOLVIDO') {
        counts[t.problemCategory] = (counts[t.problemCategory] || 0) + 1;
        totalNonResolved++;
      }
    });
    return Object.entries(counts)
      .map(([category, count]) => ({
        category,
        count,
        percentage: totalNonResolved > 0 ? Math.round((count / totalNonResolved) * 100) : 0
      }))
      .sort((a, b) => b.count - a.count);
  }, [filteredTickets]);

  // Power BI Visual: Total Open by User
  const openByUser = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredTickets.forEach(t => {
      if (t.status !== 'RESOLVIDO') {
        counts[t.technicianName] = (counts[t.technicianName] || 0) + 1;
      }
    });
    return Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }, [filteredTickets]);

  // Power BI Visual: SLA Met by User
  const resolvedByUser = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredTickets.forEach(t => {
      if (t.status === 'RESOLVIDO') {
        counts[t.technicianName] = (counts[t.technicianName] || 0) + 1;
      }
    });
    return Object.entries(counts)
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  }, [filteredTickets]);

  // Selected technician focus view
  const focusedTechData = useMemo(() => {
    if (!selectedTechId) return null;
    return technicianStats.find(t => t.techId === selectedTechId);
  }, [selectedTechId, technicianStats]);

  const handlePrintMock = () => {
    setIsPrinting(true);
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
    }, 1200);
  };

  // Generator of beautiful curves for Power BI line sparklines
  const generateSparklineSvg = (values: number[], strokeColor: string, fillColor: string) => {
    const w = 180;
    const h = 40;
    if (values.length === 0) values = [3, 2, 5, 2, 7, 4, 6];
    const max = Math.max(...values, 1);
    const min = Math.min(...values, 0);
    const range = max - min;

    const points = values.map((val, idx) => {
      const x = (idx / (values.length - 1)) * w;
      const y = h - ((val - min) / (range || 1)) * (h - 6) - 3;
      return { x, y };
    });

    let d = `M ${points[0].x} ${points[0].y}`;
    for (let i = 0; i < points.length - 1; i++) {
      const p0 = points[i];
      const p1 = points[i + 1];
      const cpX1 = p0.x + (p1.x - p0.x) / 2;
      const cpY1 = p0.y;
      const cpX2 = p0.x + (p1.x - p0.x) / 2;
      const cpY2 = p1.y;
      d += ` C ${cpX1} ${cpY1}, ${cpX2} ${cpY2}, ${p1.x} ${p1.y}`;
    }

    const fillPath = `${d} L ${w} ${h} L 0 ${h} Z`;

    return (
      <svg width="100%" height="40" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="opacity-80">
        <defs>
          <linearGradient id={`grad-${fillColor}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={fillColor} stopOpacity="0.4" />
            <stop offset="100%" stopColor={fillColor} stopOpacity="0.0" />
          </linearGradient>
        </defs>
        <path d={fillPath} fill={`url(#grad-${fillColor})`} />
        <path d={d} fill="none" stroke={strokeColor} strokeWidth="1.8" strokeLinecap="round" />
      </svg>
    );
  };

  // Sparkline data array arrays
  const sparklineDataOpen = useMemo(() => {
    return [5, 4, 3, 4, 5, 2, generalStats.open];
  }, [generalStats.open]);

  const sparklineDataTotal = useMemo(() => {
    return [25, 42, 35, 61, 48, 52, generalStats.total];
  }, [generalStats.total]);

  const sparklineDataSLA = useMemo(() => {
    return [20, 31, 28, 52, 40, 48, generalStats.resolved];
  }, [generalStats.resolved]);

  const sparklineDataExtra = useMemo(() => {
    return [5, 11, 7, 9, 8, 4, generalStats.suspended];
  }, [generalStats.suspended]);

  const handleExportBIExcel = async () => {
    try {
      const ExcelJS = await import('exceljs');
      const workbook = new ExcelJS.Workbook();
      
      // Configure general document metadata
      workbook.creator = 'UPX Atendimento';
      workbook.lastModifiedBy = 'UPX Atendimento';
      workbook.created = new Date();
      workbook.modified = new Date();
      
      // Create spreadsheet tab
      const worksheet = workbook.addWorksheet('Banco de Dados UPX', {
        views: [{ showGridLines: true }]
      });

      // Configure initial columns (width will be auto-calculated subsequently)
      worksheet.columns = [
        { header: 'ID Chamado', key: 'id', width: 14 },
        { header: 'Data Abertura', key: 'data', width: 15 },
        { header: 'Hora Abertura', key: 'hora', width: 15 },
        { header: 'Ano Abertura', key: 'ano', width: 14 },
        { header: 'Mês Abertura', key: 'mes', width: 15 },
        { header: 'Dia da Semana', key: 'diaSemana', width: 16 },
        { header: 'Cliente Corporativo', key: 'empresa', width: 28 },
        { header: 'Nome Contato', key: 'cliente', width: 22 },
        { header: 'Telefone Contato', key: 'telefone', width: 18 },
        { header: 'Modelo Equipamento', key: 'modelo', width: 24 },
        { header: 'Categoria Problema', key: 'problema', width: 24 },
        { header: 'Status Chamado', key: 'status', width: 18 },
        { header: 'Solução Aplicada', key: 'solucao', width: 28 },
        { header: 'SLA Objetivo Atingido Code', key: 'slaCode', width: 26 },
        { header: 'SLA Objetivo Atingido', key: 'slaTxt', width: 24 },
        { header: 'Técnico Responsável', key: 'tecnico', width: 24 },
        { header: 'Observações Técnicas', key: 'obs', width: 35 },
        { header: 'Transferido', key: 'transferido', width: 14 },
        { header: 'Técnico Origem Transferência', key: 'trfOrigem', width: 26 },
        { header: 'Técnico Destino Transferência', key: 'trfDestino', width: 26 },
        { header: 'Status Transferência', key: 'trfStatus', width: 20 },
      ];

      // Populate work sheet rows
      tickets.forEach(ticket => {
        const dateObj = new Date(ticket.dateTime);
        
        const id = Number(ticket.id) || ticket.id;
        const dataStr = dateObj.toLocaleDateString('pt-BR');
        const horaStr = dateObj.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        const anoVal = dateObj.getFullYear();
        const meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
        const mesStr = meses[dateObj.getMonth()];
        const diasSemana = ["Domingo", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado"];
        const diaSemanaStr = diasSemana[dateObj.getDay()];
        
        const empresa = ticket.companyName;
        const cliente = ticket.clientName;
        const telefone = ticket.clientPhone || "N/A";
        const modelo = ['Informações sobre produtos', 'Falha de funcionamento', 'Instalação'].includes(ticket.problemCategory) ? (ticket.productInfoCause || "N/A") : (ticket.deviceModel || "N/A");
        const problema = ticket.problemCategory;
        const status = ticket.status;
        const solucao = ticket.solutionCategory || "Sem Solução Registrada";
        
        const slaCode = status === 'RESOLVIDO' ? 1 : 0;
        const slaTxt = status === 'RESOLVIDO' ? "Sim" : "Não";
        
        const tecnico = ticket.technicianName;
        const obs = ticket.observations || "Nenhuma observação";
        
        const transferido = ticket.transfer ? "Sim" : "Não";
        const trfOrigem = ticket.transfer?.fromName || "N/A";
        const trfDestino = ticket.transfer?.toName || "N/A";
        const trfStatus = ticket.transfer?.status || "N/A";

        worksheet.addRow({
          id,
          data: dataStr,
          hora: horaStr,
          ano: anoVal,
          mes: mesStr,
          diaSemana: diaSemanaStr,
          empresa,
          cliente,
          telefone,
          modelo,
          problema,
          status,
          solucao,
          slaCode,
          slaTxt,
          tecnico,
          obs,
          transferido,
          trfOrigem,
          trfDestino,
          trfStatus
        });
      });

      // Style Header Row
      const headerRow = worksheet.getRow(1);
      headerRow.height = 30; // Spaced premium height
      headerRow.eachCell((cell) => {
        cell.font = { name: 'Segoe UI', size: 11, bold: true, color: { argb: 'FFFFFF' } };
        cell.fill = {
          type: 'pattern',
          pattern: 'solid',
          fgColor: { argb: '1E293B' } // Premium Charcoal slate color matching dashboard
        };
        cell.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
        cell.border = {
          top: { style: 'medium', color: { argb: '0F172A' } },
          bottom: { style: 'medium', color: { argb: '0F172A' } },
          left: { style: 'thin', color: { argb: '334155' } },
          right: { style: 'thin', color: { argb: '334155' } }
        };
      });

      // Turn on native AutoFilter controls on Excel headers
      worksheet.autoFilter = {
        from: 'A1',
        to: `T1`
      };

      // Style Data Rows
      worksheet.eachRow((row, rowNumber) => {
        if (rowNumber === 1) return; // Skip header formatting

        row.height = 22; // Spacious rows

        const isEven = rowNumber % 2 === 0;
        const stripeBg = isEven ? 'F8FAFC' : 'FFFFFF'; // Alternating soft slate-50 rows

        row.eachCell((cell, colNumber) => {
          cell.font = { name: 'Segoe UI', size: 10, color: { argb: '334155' } };
          cell.alignment = { vertical: 'middle', horizontal: 'left' };
          cell.border = {
            top: { style: 'thin', color: { argb: 'E2E8F0' } },
            bottom: { style: 'thin', color: { argb: 'E2E8F0' } },
            left: { style: 'thin', color: { argb: 'E2E8F0' } },
            right: { style: 'thin', color: { argb: 'E2E8F0' } }
          };

          // Default cell bg striping
          cell.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: stripeBg }
          };

          // Format specific columns and alignments
          const colKey = worksheet.columns[colNumber - 1].key;
          
          if (colKey === 'id') {
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
            cell.font = { name: 'Segoe UI', size: 10, bold: true, color: { argb: '0F172A' } };
          }
          if (colKey === 'data' || colKey === 'hora' || colKey === 'ano' || colKey === 'diaSemana') {
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
          }
          if (colKey === 'slaCode') {
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
            cell.numFmt = '0'; // Clean integer format for Power BI automatic parsing
          }

          // Visual accents inside cells based on their content:
          if (colKey === 'status') {
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
            const sVal = cell.value?.toString();
            if (sVal === 'RESOLVIDO') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'DCFCE7' } }; // light green
              cell.font = { name: 'Segoe UI', size: 10, bold: true, color: { argb: '166534' } }; // dark green text
            } else if (sVal === 'ABERTO') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'E0F2FE' } }; // light blue
              cell.font = { name: 'Segoe UI', size: 10, bold: true, color: { argb: '0369A1' } };
            } else if (sVal === 'SUSPENSO') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FEF3C7' } }; // light amber/yellow
              cell.font = { name: 'Segoe UI', size: 10, bold: true, color: { argb: 'B45309' } };
            }
          }

          if (colKey === 'slaTxt') {
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
            const sTxtVal = cell.value?.toString();
            if (sTxtVal === 'Sim') {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'D1FAE5' } }; // Emerald badge
              cell.font = { name: 'Segoe UI', size: 10, bold: true, color: { argb: '065F46' } };
            } else {
              cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FEE2E2' } }; // Rose badge
              cell.font = { name: 'Segoe UI', size: 10, bold: true, color: { argb: '991B1B' } };
            }
          }

          if (colKey === 'transferido') {
            cell.alignment = { vertical: 'middle', horizontal: 'center' };
            if (cell.value === 'Sim') {
              cell.font = { name: 'Segoe UI', size: 10, bold: true, color: { argb: '0284C7' } };
            }
          }
        });
      });

      // Auto-fit dynamic column widths based on longest cell contents + padding
      // This completely solves any visual truncation or ### error in Excel!
      worksheet.columns.forEach((column) => {
        let maxLen = 0;
        if (column.header) maxLen = Math.max(maxLen, column.header.toString().length);
        
        column.eachCell?.({ includeEmpty: true }, (cell) => {
          if (cell.value) {
            const cellLen = cell.value.toString().length;
            if (cellLen > maxLen) {
              maxLen = cellLen;
            }
          }
        });
        
        // Dynamic padding to guarantee text fits fully inside each column width
        column.width = Math.min(Math.max(maxLen + 4, 13), 50);
      });

      // Write array buffer, create binary blob and prompt file download
      const buffer = await workbook.xlsx.writeBuffer();
      const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.setAttribute("href", url);
      link.setAttribute("download", `UPX_Banco_Dados_Atendimentos_PowerBI_${new Date().toISOString().split('T')[0]}.xlsx`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setShowBiGuidance(true);
    } catch (err) {
      console.error('Falha ao exportar excel customizado:', err);
      alert('Houve um erro técnico ao gerar a planilha ultra-formatada. Baixando versão padrão...');
    }
  };

  return (
    <div className="space-y-6" id="reports-tab-panel">
      
      {/* View Mode & Export Actions Selector Bar */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 bg-white dark:bg-slate-900 border border-slate-150 dark:border-slate-800 p-5 rounded-2xl shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 tracking-tight flex items-center gap-2">
              <FileText className="w-5.5 h-5.5 text-cyan-600 dark:text-cyan-400" />
              Relatórios & Business Intelligence (BI) UPX
            </h2>
            <span className="text-[10px] bg-cyan-100 dark:bg-cyan-950 text-cyan-700 dark:text-cyan-400 font-extrabold px-2 py-0.5 rounded uppercase">Ativo</span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">Alterne entre o Painel de Metas SLA Estilo Power BI ou a visão clássica de relatórios para impressões.</p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          {/* Dashboard Mode Toggles */}
          <div className="bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl flex gap-1 border border-slate-200/50 dark:border-slate-750">
            <button
              onClick={() => {
                setActiveViewMode('powerbi');
                setIsPowerBiFullscreen(true);
              }}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeViewMode === 'powerbi' 
                  ? 'bg-slate-800 dark:bg-slate-700 text-white shadow-sm' 
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              🖥️ Painel Power BI SLA
            </button>
            <button
              onClick={() => {
                setActiveViewMode('classic');
                setIsPowerBiFullscreen(false);
              }}
              className={`text-xs font-bold px-4 py-2 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                activeViewMode === 'classic' 
                  ? 'bg-[#181E31]/40 border border-slate-800/85 text-slate-350 shadow-sm' 
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              📜 Relatório Clássico
            </button>
          </div>

          {activeViewMode === 'classic' && (
            <button
              id="btn-print-report"
              onClick={handlePrintMock}
              className="bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white font-bold text-xs px-5 py-3 rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-md border border-slate-700/55"
              style={{ color: '#ffffff' }}
            >
              <Printer className="w-4 h-4 text-white" />
              {isPrinting ? 'Gerando PDF...' : 'Imprimir / Salvar PDF'}
            </button>
          )}
        </div>
      </div>

      {/* BI Instructions (grows beautifully after user exports) */}
      {showBiGuidance && (
        <div className="bg-gradient-to-r from-cyan-50/50 to-emerald-50/30 dark:from-cyan-955/20 dark:to-emerald-955/10 border border-cyan-200/80 dark:border-cyan-850 p-4.5 rounded-2xl flex flex-col md:flex-row gap-4 items-start md:items-center justify-between shadow-xs animate-slideDown" id="bi-guidance-panel">
          <div className="space-y-1 md:max-w-xl">
            <span className="text-[9.5px] uppercase font-bold text-cyan-600 dark:text-cyan-400 tracking-wider flex items-center gap-1">
              🚀 Alta Performance BI: Planilha Sincronizada Ativa
            </span>
            <p className="text-xs font-black text-slate-800 dark:text-slate-100">Planilha UPX_Banco_Dados_Atendimentos_PowerBI.xlsx criada com sucesso!</p>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-normal">
              Esta é uma planilha corporativa estruturada pronta para <strong>Power BI Desktop ou Business Intelligence Excel</strong>. Ela conta com formatação visual automatizada, colunas de tempo decompostas por Mês, Ano e Dia da Semana, métricas numéricas binárias de metas para cálculos matemáticos rápidos em fórmulas DAX, e colunas autoajustadas contra erros de corte.
            </p>
          </div>
          <button 
            onClick={() => setShowBiGuidance(false)}
            className="text-[11px] font-bold text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 underline shrink-0 cursor-pointer"
          >
            Fechar Instruções
          </button>
        </div>
      )}

      {/* ----------------- MODE 1: POWER BI DASHBOARD VIEW (DARK THEME) ----------------- */}
      {activeViewMode === 'powerbi' && (
        <div 
          className={`${
            isPowerBiFullscreen 
              ? 'fixed inset-0 z-[100] bg-[#0B0F19] overflow-y-auto p-4 md:p-8 flex flex-col xl:flex-row gap-6 text-slate-200 font-sans' 
              : 'bg-[#0B0F19] p-4 sm:p-6 rounded-3xl border border-slate-850 shadow-2xl flex flex-col xl:flex-row gap-6 text-slate-200 font-sans'
          }`}
          id="powerbi-canvas"
        >
          
          {/* Side Frame Left Panel: "Filtro de tempo" */}
          <div className="w-full xl:w-64 bg-[#111625] rounded-2xl border border-slate-800 p-5 flex flex-col space-y-6 shrink-0 shadow-lg">
            
            {/* Karpinski / Leonardo Style Custom Glowing Branding */}
            <div className="flex items-center gap-3 border-b border-slate-800 pb-5">
              <div className="bg-gradient-to-tr from-cyan-500 to-indigo-600 p-2.5 rounded-xl shadow-lg shadow-cyan-500/10 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold text-cyan-400 tracking-wider block uppercase">UPX METADADOS</span>
                <span className="text-sm font-black text-white tracking-tight">Painel Executivo BI</span>
              </div>
            </div>

            {/* Glowing headset representative avatar circle */}
            <div className="flex flex-col items-center justify-center text-center bg-[#181E31]/40 border border-slate-800/80 p-4 rounded-xl">
              <div className="relative">
                <div className="absolute -inset-1 rounded-full bg-gradient-to-r from-cyan-500 to-indigo-500 blur opacity-40 animate-pulse"></div>
                <div className="relative bg-[#1A2238] border border-slate-700 p-3.5 rounded-full flex items-center justify-center">
                  {/* Headset visual element */}
                  <svg className="w-8 h-8 text-cyan-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 2a9 9 0 00-9 9v1a3 3 0 003 3h1a2 2 0 002-2v-4a2 2 0 00-2-2H5.1A7.001 7.001 0 0118.9 10H17a2 2 0 00-2 2v4a2 2 0 002 2h1a3 3 0 003-3v-1a9 9 0 00-9-9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M19 14v1a3 3 0 01-3 3H6a3 3 0 01-3-3V14" />
                  </svg>
                </div>
              </div>
              <p className="text-xs font-bold text-slate-100 mt-3">Setor de Engenharia</p>
              <p className="text-[10px] text-slate-400 font-mono">SUPORTE & TELEMETRIA</p>
            </div>

            {/* Interactive "Filtro de tempo" Section */}
            <div className="space-y-3.5">
              <span className="text-xs uppercase font-extrabold text-slate-400 tracking-wider flex items-center gap-1.5">
                <Filter className="w-3.5 h-3.5 text-cyan-500" />
                Filtro de Tempo
              </span>
              
              <div className="space-y-4 max-h-[300px] overflow-y-auto pr-1">
                {timeFilterOptions.length === 0 ? (
                  <p className="text-xs text-slate-500 italic">Nenhuma data localizada na base.</p>
                ) : (
                  timeFilterOptions.map(option => {
                    const isYearExpanded = expandedYears[option.year];
                    const isYearToggled = checkedYears[option.year] !== false;
                    
                    return (
                      <div key={option.year} className="space-y-2 border-b border-slate-850 pb-2.5 last:border-0 last:pb-0">
                        {/* Year Node row */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <button 
                              onClick={() => setExpandedYears(prev => ({ ...prev, [option.year]: !prev[option.year] }))}
                              className="text-slate-400 hover:text-white cursor-pointer"
                            >
                              {isYearExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                            </button>
                            
                            <label className="flex items-center gap-2 text-xs font-bold text-slate-200 cursor-pointer select-none">
                              <input 
                                type="checkbox"
                                checked={isYearToggled}
                                onChange={() => handleYearToggle(option.year)}
                                className="w-3.5 h-3.5 rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0 focus:ring-offset-0 cursor-pointer"
                              />
                              {option.year}
                            </label>
                          </div>
                        </div>

                        {/* Months children checkbox list */}
                        {isYearExpanded && (
                          <div className="pl-6 space-y-1.5 mt-1 border-l border-slate-800 ml-1.5">
                            {option.months.map(m => {
                              const key = `${option.year}-${m}`;
                              const isChecked = checkedMonths[key] !== false;
                              return (
                                <label key={m} className="flex items-center gap-2 text-[11px] text-slate-350 hover:text-white cursor-pointer select-none">
                                  <input 
                                    type="checkbox"
                                    checked={isChecked}
                                    onChange={() => handleMonthToggle(option.year, m)}
                                    className="w-3 h-3 rounded border-slate-700 bg-slate-800 text-cyan-500 focus:ring-0 focus:ring-offset-0 cursor-pointer"
                                  />
                                  {m}
                                </label>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Total Filter state indicator */}
            <div className="pt-4 border-t border-slate-800 text-center">
              <span className="text-[10px] text-slate-500 font-mono">
                Registrados: {filteredTickets.length} / {tickets.length} chamados
              </span>
            </div>
          </div>

          {/* Right Main Dashboard Workspace Content Area */}
          <div className="flex-1 space-y-6 flex flex-col">
            
            {/* Top Workspace Bar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-[#111625] border border-slate-800 p-4.5 rounded-2xl shadow-lg gap-4">
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => {
                    if (isPowerBiFullscreen) {
                      setIsPowerBiFullscreen(false);
                    } else if (onBackToDashboard) {
                      onBackToDashboard();
                    } else {
                      alert('O filtro retornou com sucesso para a totalidade.');
                    }
                  }}
                  className="bg-[#181E31] hover:bg-[#202741] transition-colors p-2 rounded-xl text-slate-300 hover:text-white cursor-pointer"
                  title={isPowerBiFullscreen ? "Voltar ao Relatório Normal" : "Voltar ao Painel Geral"}
                >
                  <ArrowLeft className="w-4 h-4 text-cyan-400" />
                </button>
                <div>
                  <h1 className="text-lg font-black tracking-tight flex items-center gap-1.5" style={{ color: '#ffffff' }}>
                    SLA de Atendimento
                  </h1>
                  <p className="text-slate-400 text-[11px]">Banco de Dados Atendimentos e Telemetria Integrada</p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                {!isPowerBiFullscreen && (
                  <button
                    onClick={() => setIsPowerBiFullscreen(true)}
                    className="bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-xs uppercase px-4 py-2.5 rounded-xl flex items-center gap-2 transition-all cursor-pointer shadow-md hover:scale-105 active:scale-95"
                  >
                    <Maximize2 className="w-3.5 h-3.5 text-white" />
                    Ver em Tela Cheia
                  </button>
                )}

                <div className="text-right hidden sm:block">
                  <span className="text-[10px] text-slate-500 uppercase font-mono block">Data Atualizada</span>
                  <span className="text-xs font-bold text-cyan-400 font-mono">31 de Maio de 2026</span>
                </div>
              </div>
            </div>

            {/* Row of 4 Power BI KPI Theme Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Card 1: Total em Aberto */}
              <div className="bg-[#181D2D] border border-slate-800 p-4 rounded-2xl relative overflow-hidden shadow-md space-y-2 flex flex-col justify-between min-h-[140px]">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] text-orange-400 font-extrabold uppercase tracking-wider block">Total em Aberto</span>
                    <span className="text-3xl font-black text-white mt-1 block">{generalStats.open}</span>
                  </div>
                  <div className="p-2 bg-orange-500/10 text-orange-400 rounded-lg">
                    <Clock className="w-4 h-4" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 text-[10px] text-orange-300 font-bold">
                    <span>-0,58%</span>
                    <span className="text-slate-500 font-normal">Vs. ano anterior</span>
                  </div>
                  <div className="mt-1.5">
                    {generateSparklineSvg(sparklineDataOpen, '#f97316', '#ea580c')}
                  </div>
                </div>
              </div>

              {/* Card 2: Total Atendimentos */}
              <div className="bg-[#181D2D] border border-slate-800 p-4 rounded-2xl relative overflow-hidden shadow-md space-y-2 flex flex-col justify-between min-h-[140px]">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] text-violet-400 font-extrabold uppercase tracking-wider block">Total Atendimentos</span>
                    <span className="text-3xl font-black text-white mt-1 block">{generalStats.total}</span>
                  </div>
                  <div className="p-2 bg-violet-500/10 text-violet-400 rounded-lg">
                    <Milestone className="w-4 h-4" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 text-[10px] text-violet-300 font-bold">
                    <span>-9,37%</span>
                    <span className="text-slate-500 font-normal">Vs. ano anterior</span>
                  </div>
                  <div className="mt-1.5">
                    {generateSparklineSvg(sparklineDataTotal, '#8b5cf6', '#7c3aed')}
                  </div>
                </div>
              </div>

              {/* Card 3: SLA Atendido (Resolved) */}
              <div className="bg-[#181D2D] border border-slate-800 p-4 rounded-2xl relative overflow-hidden shadow-md space-y-2 flex flex-col justify-between min-h-[140px]">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] text-emerald-400 font-extrabold uppercase tracking-wider block">SLA Atendido</span>
                    <span className="text-3xl font-black text-white mt-1 block">{generalStats.resolved}</span>
                  </div>
                  <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
                    <UserCheck className="w-4 h-4" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 text-[10px] text-emerald-300 font-bold">
                    <span>-12,31%</span>
                    <span className="text-slate-500 font-normal">Vs. ano anterior</span>
                  </div>
                  <div className="mt-1.5">
                    {generateSparklineSvg(sparklineDataSLA, '#10b981', '#059669')}
                  </div>
                </div>
              </div>

              {/* Card 4: SLA Extrapolado (Active Suspended) */}
              <div className="bg-[#181D2D] border border-slate-800 p-4 rounded-2xl relative overflow-hidden shadow-md space-y-2 flex flex-col justify-between min-h-[140px]">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] text-rose-400 font-extrabold uppercase tracking-wider block">SLA Extrapolado</span>
                    <span className="text-3xl font-black text-white mt-1 block">{generalStats.suspended}</span>
                  </div>
                  <div className="p-2 bg-rose-500/10 text-rose-400 rounded-lg">
                    <AlertCircle className="w-4 h-4" />
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-2 text-[10px] text-rose-300 font-bold">
                    <span>+0,71%</span>
                    <span className="text-slate-500 font-normal">Vs. ano anterior</span>
                  </div>
                  <div className="mt-1.5">
                    {generateSparklineSvg(sparklineDataExtra, '#f43f5e', '#e11d48')}
                  </div>
                </div>
              </div>

            </div>

            {/* Bento Grid: Core Charts Layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              
              {/* Left Bento Column: Open counts (Reason & User) */}
              <div className="lg:col-span-4 space-y-5">
                
                {/* Visual 1: Total em Aberto por Motivo */}
                <div className="bg-[#111625] border border-slate-800 p-5 rounded-2xl shadow-xl flex flex-col justify-between">
                  <div>
                    <h3 className="text-xs font-black uppercase text-slate-100 tracking-wider">Total em Aberto por Motivo</h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">Demanda pendente agregada por categoria</p>
                  </div>
                  <div className="space-y-3.5 mt-5">
                    {openByReason.length === 0 ? (
                      <p className="text-xs text-slate-500 italic py-6 text-center">Nenhum chamado pendente.</p>
                    ) : (
                      openByReason.slice(0, 5).map(item => {
                        const maxCount = Math.max(...openByReason.map(i => i.count), 1);
                        const progressPercent = Math.round((item.count / maxCount) * 100);
                        return (
                          <div key={item.category} className="space-y-1">
                            <div className="flex justify-between text-[11px] font-medium text-slate-300">
                              <span className="truncate w-3/4" title={item.category}>{item.category}</span>
                              <span className="text-orange-400 font-bold">{item.count}</span>
                            </div>
                            <div className="w-full bg-[#181E31] rounded-full h-2 overflow-hidden">
                              <div 
                                className="bg-[#f97316] h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(249,115,22,0.4)]"
                                style={{ width: `${progressPercent}%` }}
                              />
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                {/* Visual 2: Total em Aberto por Usuário */}
                <div className="bg-[#111625] border border-slate-800 p-5 rounded-2xl shadow-xl flex flex-col justify-between">
                  <div>
                    <h3 className="text-xs font-black uppercase text-slate-100 tracking-wider">Total em Aberto por Usuário</h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">Distribuição individual de técnicos</p>
                  </div>
                  <div className="space-y-3.5 mt-5">
                    {openByUser.length === 0 ? (
                      <p className="text-xs text-slate-500 italic py-6 text-center">Nenhum chamado pendente atribuído.</p>
                    ) : (
                      openByUser.slice(0, 5).map(item => {
                        const maxCount = Math.max(...openByUser.map(i => i.count), 1);
                        const progressPercent = Math.round((item.count / maxCount) * 100);
                        return (
                          <div key={item.name} className="space-y-1">
                            <div className="flex justify-between text-[11px] font-medium text-slate-300">
                              <span className="truncate w-3/4">{item.name}</span>
                              <span className="text-orange-400 font-bold">{item.count}</span>
                            </div>
                            <div className="w-full bg-[#181E31] rounded-full h-2 overflow-hidden">
                              <div 
                                className="bg-[#f97316] h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(249,115,22,0.4)]"
                                style={{ width: `${progressPercent}%` }}
                              />
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

              </div>

              {/* Center Bento Column: Semicircle Gauge & SLA Met by User */}
              <div className="lg:col-span-4 space-y-5">
                
                {/* Semicircle Gauge: SLA Atendido Rate */}
                <div className="bg-[#111625] border border-slate-800 p-5 rounded-2xl shadow-xl flex flex-col items-center justify-center text-center min-h-[220px]">
                  <span className="text-xs font-black uppercase text-slate-100 tracking-wider w-full text-left">SLA Atendido</span>
                  <p className="text-[10px] text-slate-400 w-full text-left mt-0.5">Percentual de resoluções gerais</p>

                  <div className="relative mt-4 w-32 h-16 sm:w-40 sm:h-20 flex items-center justify-center overflow-hidden">
                    <svg className="w-full h-full" viewBox="0 0 100 50">
                      {/* Background trace arc */}
                      <path 
                        d="M 10 50 A 40 40 0 0 1 90 50" 
                        fill="none" 
                        stroke="#1E2538" 
                        strokeWidth="10" 
                        strokeLinecap="round" 
                      />
                      {/* Foreground SLA progress arc */}
                      {(() => {
                        const radius = 40;
                        const circum = Math.PI * radius; // 125.66
                        const percentage = generalStats.resolutionRate;
                        const strokeOffset = circum - (percentage / 100) * circum;
                        return (
                          <path 
                            d="M 10 50 A 40 40 0 0 1 90 50" 
                            fill="none" 
                            stroke="#10b981" 
                            strokeWidth="10" 
                            strokeLinecap="round"
                            strokeDasharray={circum}
                            strokeDashoffset={strokeOffset}
                            className="transition-all duration-1000 ease-out"
                          />
                        );
                      })()}
                    </svg>
                    
                    {/* Centered large digital text SLA */}
                    <div className="absolute bottom-0 text-center">
                      <span className="text-3xl font-black text-white">{generalStats.resolutionRate}%</span>
                    </div>
                  </div>
                  
                  <span className="text-[10px] text-slate-500 font-mono mt-3">Target operacional: &gt;= 80%</span>
                </div>

                {/* Visual 3: SLA Atendido por Usuário */}
                <div className="bg-[#111625] border border-slate-800 p-5 rounded-2xl shadow-xl flex flex-col justify-between">
                  <div>
                    <h3 className="text-xs font-black uppercase text-slate-100 tracking-wider">SLA Atendido por Usuário</h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">Chamados resolvidos por técnico</p>
                  </div>
                  <div className="space-y-3.5 mt-5">
                    {resolvedByUser.length === 0 ? (
                      <p className="text-xs text-slate-500 italic py-6 text-center">Nenhum chamado de sucesso catalogado.</p>
                    ) : (
                      resolvedByUser.slice(0, 5).map(item => {
                        const maxCount = Math.max(...resolvedByUser.map(i => i.count), 1);
                        const progressPercent = Math.round((item.count / maxCount) * 100);
                        return (
                          <div key={item.name} className="space-y-1">
                            <div className="flex justify-between text-[11px] font-medium text-slate-300">
                              <span className="truncate w-3/4">{item.name}</span>
                              <span className="text-emerald-400 font-bold">{item.count}</span>
                            </div>
                            <div className="w-full bg-[#181E31] rounded-full h-2 overflow-hidden">
                              <div 
                                className="bg-[#10b981] h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]"
                                style={{ width: `${progressPercent}%` }}
                              />
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

              </div>

              {/* Right Bento Column: SLA Extrapolated / % SLA by Motivo */}
              <div className="lg:col-span-4 space-y-5">
                
                {/* Visual 4: SLA Extrapolado e % SLA por Motivo */}
                <div className="bg-[#111625] border border-slate-800 p-5 rounded-2xl shadow-xl flex flex-col justify-between h-full min-h-[350px]">
                  <div>
                    <h3 className="text-xs font-black uppercase text-slate-100 tracking-wider">SLA Extrapolado e % por Motivo</h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">Rank de causas extrapolação de Meta</p>
                  </div>
                  
                  <div className="space-y-4 mt-5 flex-1 overflow-y-auto max-h-[360px] pr-1">
                    {nonResolvedByReason.length === 0 ? (
                      <p className="text-xs text-slate-500 italic py-12 text-center">Toda a equipe opera 100% no prazo.</p>
                    ) : (
                      nonResolvedByReason.map(item => {
                        const maxCount = Math.max(...nonResolvedByReason.map(i => i.count), 1);
                        const progressPercent = Math.round((item.count / maxCount) * 100);
                        return (
                          <div key={item.category} className="space-y-1.5 bg-[#181E31]/40 p-2.5 rounded-xl border border-slate-800/60">
                            <div className="flex justify-between text-[11px] font-bold text-slate-300">
                              <span className="truncate w-1/2" title={item.category}>{item.category}</span>
                              <div className="flex gap-2">
                                <span className="text-rose-400">{item.count} chamados</span>
                                <span className="text-slate-500 font-mono">{item.percentage}%</span>
                              </div>
                            </div>
                            
                            <div className="w-full bg-[#181E31] rounded-full h-2 overflow-hidden">
                              <div 
                                className="bg-[#f43f5e] h-full rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(244,63,94,0.4)]"
                                style={{ width: `${progressPercent}%` }}
                              />
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  <div className="pt-3 border-t border-slate-800/80 text-[10px] text-slate-500 flex items-center gap-1.5">
                    <Info className="w-3.5 h-3.5 text-cyan-400" />
                    Calculado dividindo gargalos de chamado pendente ou suspensos no período.
                  </div>
                </div>

              </div>

            </div>

          </div>

        </div>
      )}

      {/* ----------------- MODE 2: CLASSIC CORPORATE DETAILED VIEW (LIGHT/DARK) ----------------- */}
      {activeViewMode === 'classic' && (
        <>
          {/* Main Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            
            <div className="bg-gradient-to-tr from-slate-800 to-slate-900 p-5 rounded-2xl text-white space-y-3 shadow-md">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-widest">SLA Geral da UPX</span>
                <TrendingUp className="w-4.5 h-4.5 text-cyan-400" />
              </div>
              <div>
                <span className="text-3xl md:text-4xl font-extrabold block text-white" style={{ color: '#ffffff' }}>{generalStats.resolutionRate}%</span>
                <span className="text-xs text-slate-400">Taxa de resolução corporativa</span>
              </div>
              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 font-medium">
                {generalStats.resolved} de {generalStats.total} chamados totais finalizados com sucesso no filtro.
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Gargalo Operacional</span>
                <AlertCircle className="w-4.5 h-4.5 text-amber-500" />
              </div>
              <div>
                <span className="text-sm font-bold text-slate-800 dark:text-slate-100 line-clamp-1">{generalStats.topProblem}</span>
                <span className="text-xs text-slate-400 block mt-1">Causa de chamado mais comum</span>
              </div>
              <div className="pt-2 border-t border-slate-150 dark:border-slate-800 text-[11px] text-slate-500">
                Registrado <span className="font-bold text-slate-700 dark:text-slate-300">{generalStats.topProblemCount} vezes</span> no período filtado.
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Quadro de Técnicos Ativos</span>
                <UserCheck className="w-4.5 h-4.5 text-cyan-600" />
              </div>
              <div>
                <span className="text-3xl font-extrabold text-slate-800 dark:text-slate-100 block">{techCollaborators.length}</span>
                <span className="text-xs text-slate-400">Colaboradores de suporte operando</span>
              </div>
              <div className="pt-2 border-t border-slate-150 dark:border-slate-800 text-[11px] text-slate-500">
                Emissão individual de atendimentos e histórico individual ativo.
              </div>
            </div>

          </div>

          {/* Tech Performance Ranking Table */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden" id="ranking-table-panel">
            <div className="p-5 border-b border-slate-150 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 uppercase tracking-wide">Ranking de Eficiência dos Técnicos</h3>
                <p className="text-xs text-slate-400">Classificação com base na taxa de resolução de chamados resolvidos</p>
              </div>
              
              {/* Quick tech selector to focus */}
              <select
                id="focus-tech-selector"
                value={selectedTechId}
                onChange={(e) => setSelectedTechId(e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-755 dark:text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-cyan-500 cursor-pointer"
              >
                <option value="">Focar em um técnico específico...</option>
                {techCollaborators.map(t => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-850/50 border-b border-slate-200 dark:border-slate-800 text-[10px] font-bold text-slate-550 dark:text-slate-405 uppercase tracking-wider">
                    <th className="py-3.5 px-5">Técnico</th>
                    <th className="py-3.5 px-5 text-center">Criados</th>
                    <th className="py-3.5 px-5 text-center text-cyan-600">Transferidos</th>
                    <th className="py-3.5 px-5 text-center text-indigo-600">Recebidos</th>
                    <th className="py-3.5 px-5 text-center text-slate-650 dark:text-slate-350">Sob Resp. (Ativos)</th>
                    <th className="py-3.5 px-5 text-center text-emerald-600">Resolvidos</th>
                    <th className="py-3.5 px-5 text-right">Eficácia (SLA)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-105 dark:divide-slate-800 text-xs text-slate-700 dark:text-slate-300">
                  {technicianStats.map((stat, idx) => (
                    <tr key={stat.techId} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/10 transition-colors">
                      <td className="py-3 px-5">
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-[11px] font-bold text-slate-400 w-4 block text-center">
                            #{idx + 1}
                          </span>
                          <div>
                            <span className="font-semibold text-slate-800 dark:text-slate-200 block">{stat.name}</span>
                            <span className="text-[10px] text-slate-400">{stat.email}</span>
                          </div>
                        </div>
                      </td>
                      <td className="py-3 px-5 text-center font-semibold text-slate-700 dark:text-slate-300">{stat.created}</td>
                      <td className="py-3 px-5 text-center font-bold text-cyan-600">
                        {stat.transferredOut > 0 ? `➜ ${stat.transferredOut}` : '0'}
                      </td>
                      <td className="py-3 px-5 text-center font-bold text-indigo-600">
                        {stat.transferredIn > 0 ? `+ ${stat.transferredIn}` : '0'}
                      </td>
                      <td className="py-3 px-5 text-center font-semibold text-slate-800 dark:text-slate-200">{stat.total}</td>
                      <td className="py-3 px-5 text-center font-bold text-emerald-600">{stat.resolved}</td>
                      <td className="py-3 px-5 text-right">
                        <div className="flex items-center justify-end gap-2.5">
                          <div className="w-16 bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden hidden sm:block">
                            <div 
                              className={`h-full rounded-full ${stat.resolutionRate >= 80 ? 'bg-emerald-500' : stat.resolutionRate >= 50 ? 'bg-amber-500' : 'bg-rose-500'}`}
                              style={{ width: `${stat.resolutionRate}%` }}
                            />
                          </div>
                          <span className={`font-extrabold ${stat.resolutionRate >= 80 ? 'text-emerald-600' : stat.resolutionRate >= 50 ? 'text-amber-600' : 'text-rose-600'}`}>
                            {stat.resolutionRate}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Selected Technician Focus Section */}
          {focusedTechData && (
            <div className="bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-850 p-5 rounded-2xl space-y-4 animate-slideDown" id="technician-focus-card">
              <div className="flex justify-between items-start border-b border-slate-200 dark:border-slate-800 pb-3">
                <div>
                  <span className="text-[10px] bg-cyan-100 dark:bg-cyan-950 text-cyan-850 dark:text-cyan-400 px-2.5 py-1 font-bold rounded-full uppercase tracking-wider block w-fit mb-1.5">Visão do Colaborador</span>
                  <h3 className="text-base font-bold text-slate-800 dark:text-slate-100">{focusedTechData.name}</h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">Histórico de chamados atendidos por este profissional na base filtrada</p>
                </div>
                
                <button
                  onClick={() => setSelectedTechId('')}
                  className="text-xs text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 underline font-medium cursor-pointer"
                >
                  Fechar Foco
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-6 gap-3.5 text-center">
                <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-150 dark:border-slate-800">
                  <span className="text-[9px] font-bold text-slate-400 block uppercase tracking-tight">Criados (Origem)</span>
                  <span className="text-xl font-black text-slate-750 dark:text-slate-350">{focusedTechData.created}</span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-150 dark:border-slate-800">
                  <span className="text-[9px] font-bold text-cyan-600 block uppercase tracking-tight flex items-center justify-center">Transferidos</span>
                  <span className="text-xl font-black text-cyan-600">{focusedTechData.transferredOut}</span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-150 dark:border-slate-800">
                  <span className="text-[9px] font-bold text-indigo-600 block uppercase tracking-tight">Recebidos</span>
                  <span className="text-xl font-black text-indigo-650">{focusedTechData.transferredIn}</span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-150 dark:border-slate-800">
                  <span className="text-[9px] font-bold text-slate-500 block uppercase tracking-tight">Sob Resp. (Ativo)</span>
                  <span className="text-xl font-black text-slate-800 dark:text-slate-100">{focusedTechData.total}</span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-150 dark:border-slate-800">
                  <span className="text-[9px] font-bold text-emerald-650 block uppercase tracking-tight">Resolvidos</span>
                  <span className="text-xl font-black text-emerald-600">{focusedTechData.resolved}</span>
                </div>
                <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-150 dark:border-slate-800">
                  <span className="text-[9px] font-bold text-slate-500 block uppercase tracking-tight">Eficácia SLA</span>
                  <span className="text-xl font-black text-slate-850 dark:text-slate-200">{focusedTechData.resolutionRate}%</span>
                </div>
              </div>

              <div className="space-y-2 mt-4">
                <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block">Lista de Chamados Recentes ({focusedTechData.name})</span>
                {focusedTechData.tickets.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">Este técnico ainda não possui chamados registrados no filtro.</p>
                ) : (
                  <div className="space-y-2">
                    {focusedTechData.tickets.map(ticket => (
                      <div key={ticket.id} className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-150 dark:border-slate-800 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-slate-800 dark:text-slate-205">{ticket.companyName}</span>
                            <span className="text-slate-400">({ticket.clientName})</span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">{ticket.problemCategory}</p>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-400 font-mono">
                            {new Date(ticket.dateTime).toLocaleDateString('pt-BR')}
                          </span>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            ticket.status === 'RESOLVIDO' ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-400' :
                            ticket.status === 'SUSPENSO' ? 'bg-amber-50 dark:bg-amber-950 text-amber-700 dark:text-amber-400' : 'bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-400'
                          }`}>
                            {ticket.status === 'RESOLVIDO' ? 'Resolvido' :
                             ticket.status === 'SUSPENSO' ? 'Suspenso' : 'Não resolvido'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}

      {/* Printing Virtual Report Overlay (Shown when generating reports) */}
      {isPrinting && (
        <div className="fixed inset-0 bg-white z-50 p-12 overflow-y-auto block text-slate-900 animate-fadeIn" id="print-virtual-overlay">
          <div className="max-w-4xl mx-auto space-y-6">
            
            {/* Header */}
            <div className="flex justify-between items-center pb-5 border-b-2 border-slate-300">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-slate-900 text-white rounded-xl">
                  <span className="font-extrabold text-lg block">UPX</span>
                </div>
                <div>
                  <h1 className="text-xl font-bold tracking-tight text-slate-900">RELATÓRIO DE PRODUTIVIDADE E SLA</h1>
                  <p className="text-xs text-slate-500 font-semibold uppercase">Setor de Suporte Tecnológico UPX</p>
                </div>
              </div>
              <div className="text-right text-xs">
                <p className="font-bold">Emissão:</p>
                <p className="text-slate-600">31 de Maio de 2026</p>
                <p className="text-slate-500 text-[10px] font-mono">Gerado em: {new Date().toLocaleTimeString('pt-BR')}</p>
              </div>
            </div>

            {/* Metrics summarized */}
            <div className="grid grid-cols-4 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
              <div className="text-center">
                <span className="text-[9px] font-bold text-slate-400 block uppercase">Chamados Totais</span>
                <span className="text-lg font-bold">{generalStats.total}</span>
              </div>
              <div className="text-center border-l border-slate-200">
                <span className="text-[9px] font-bold text-emerald-650 block uppercase">Resolvidos</span>
                <span className="text-lg font-bold text-emerald-600">{generalStats.resolved}</span>
              </div>
              <div className="text-center border-l border-slate-200">
                <span className="text-[9px] font-bold text-slate-400 block uppercase">Suspensos</span>
                <span className="text-lg font-bold">{generalStats.suspended}</span>
              </div>
              <div className="text-center border-l border-slate-200">
                <span className="text-[9px] font-bold text-slate-400 block uppercase">Meta SLA</span>
                <span className="text-lg font-black text-cyan-600">{generalStats.resolutionRate}% de Resolução</span>
              </div>
            </div>

            {/* Table of performance */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wide border-b border-slate-200 pb-1 text-slate-800">Desempenho da Equipe de Técnicos</h3>
              <table className="w-full text-left font-sans text-[11px]">
                <thead>
                  <tr className="border-b border-slate-200 text-[9px] font-bold text-slate-500 uppercase">
                    <th className="py-2">Técnico</th>
                    <th className="py-2 text-center">Criados</th>
                    <th className="py-2 text-center">Transferidos</th>
                    <th className="py-2 text-center">Recebidos</th>
                    <th className="py-2 text-center">Ativos (Responsável)</th>
                    <th className="py-2 text-center text-emerald-600">Resolvidos</th>
                    <th className="py-2 text-right">Aproveitamento (SLA)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150">
                  {technicianStats.map(stat => (
                    <tr key={stat.techId} className="py-2 border-b border-slate-100 last:border-0">
                      <td className="py-2 font-semibold text-slate-800">{stat.name}</td>
                      <td className="py-2 text-center text-slate-700">{stat.created}</td>
                      <td className="py-2 text-center text-cyan-650">{stat.transferredOut}</td>
                      <td className="py-2 text-center text-indigo-650">{stat.transferredIn}</td>
                      <td className="py-2 text-center text-slate-800 font-medium">{stat.total}</td>
                      <td className="py-2 text-center text-emerald-650 font-bold">{stat.resolved}</td>
                      <td className="py-2 text-right font-black text-slate-800">{stat.resolutionRate}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Print Footer and Signature area */}
            <div className="pt-16 grid grid-cols-2 gap-12 text-center text-xs">
              <div className="space-y-1">
                <div className="border-b border-slate-400 w-3/4 mx-auto h-4" />
                <p className="font-bold text-slate-800">Henrique</p>
                <p className="text-slate-500 text-[10px]">Supervisor de Redes - UPX Admin</p>
              </div>
              <div className="space-y-1">
                <div className="border-b border-slate-400 w-3/4 mx-auto h-4" />
                <p className="font-bold text-slate-800">Coordenação Geral de TI</p>
                <p className="text-slate-500 text-[10px]">UPX Soluções de Conectividade</p>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
