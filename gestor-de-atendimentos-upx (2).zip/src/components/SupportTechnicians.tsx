import React, { useState } from 'react';
import { User } from '../types';
import { Users, Search, ChevronRight, UserPlus, Trash2, KeyRound, RotateCcw } from 'lucide-react';

interface SupportTechniciansProps {
  technicians: User[];
  onAddTechnician: (tech: Omit<User, 'id' | 'role'> & { password?: string }) => { success: boolean; message: string };
  onDeleteTechnician: (id: string) => void;
  onToggleStatus: (id: string) => void;
  onSetTechnicianPassword: (id: string, passwordString: string) => void;
  onResetTicketCounter?: () => void;
}

export default function SupportTechnicians({
  technicians,
  onAddTechnician,
  onDeleteTechnician,
  onToggleStatus,
  onSetTechnicianPassword,
  onResetTicketCounter
}: SupportTechniciansProps) {
  const [search, setSearch] = useState('');
  
  // Create Technician State
  const [isAdding, setIsAdding] = useState(false);
  const [newTechForm, setNewTechForm] = useState({ name: '', email: '', status: 'ATIVO' as 'ATIVO' | 'INATIVO' });
  const [newTechError, setNewTechError] = useState('');
  
  // Set Password Form State
  const [passwordFormObj, setPasswordFormObj] = useState<{techId: string, name: string} | null>(null);
  const [newPasswordString, setNewPasswordString] = useState('');

  // Delete Confirm State
  const [deleteConfirmObj, setDeleteConfirmObj] = useState<{techId: string, name: string} | null>(null);

  // Local component list filtering - Only "Suporte" department, or default empty ones (no department defined yet)
  const filteredTechs = technicians.filter(t => {
    const isSupportOrUnassigned = t.department === 'Suporte' || !t.department;
    const matchesSearch = t.name.toLowerCase().includes(search.toLowerCase()) || t.email.toLowerCase().includes(search.toLowerCase());
    return isSupportOrUnassigned && matchesSearch;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setNewTechError('');
    if (!newTechForm.name.trim() || !newTechForm.email.trim()) {
      setNewTechError('Preencha os campos de nome e e-mail.');
      return;
    }
    const res = onAddTechnician(newTechForm);
    if (!res.success) {
      setNewTechError(res.message);
    } else {
      setIsAdding(false);
      setNewTechForm({ name: '', email: '', status: 'ATIVO' });
      alert(res.message);
    }
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordFormObj || !newPasswordString.trim() || newPasswordString.length < 5) {
      alert('A senha deve ter no mínimo 5 caracteres.');
      return;
    }
    onSetTechnicianPassword(passwordFormObj.techId, newPasswordString);
    alert('Senha atualizada com sucesso para este técnico.');
    setPasswordFormObj(null);
    setNewPasswordString('');
  };

  return (
    <div className="space-y-6 animate-fadeIn transition-colors relative z-0">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Users className="w-6 h-6 text-cyan-500" />
            Técnicos de Suporte
          </h2>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
            Gerencie apenas os técnicos vinculados ao departamento de Suporte.
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-3 w-full md:w-auto mt-4 md:mt-0">
          {onResetTicketCounter && (
            <button 
              onClick={() => {
                if(window.confirm('Tem certeza que deseja reiniciar o número dos pedidos/chamados? O próximo chamado criado será o #1.')) {
                  onResetTicketCounter();
                }
              }}
              className="bg-amber-100 hover:bg-amber-200 dark:bg-amber-500/10 dark:hover:bg-amber-500/20 text-amber-700 dark:text-amber-500 px-5 py-2.5 rounded-xl font-bold text-sm border border-amber-200 dark:border-amber-500/30 transition-colors flex items-center gap-2 w-full md:w-auto justify-center"
            >
              <RotateCcw className="w-4 h-4" />
              Reiniciar Nº Pedidos
            </button>
          )}
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-cyan-500 hover:bg-cyan-600 dark:bg-cyan-600 dark:hover:bg-cyan-500 text-white px-5 py-2.5 rounded-xl font-bold text-sm shadow-sm transition-colors flex items-center gap-2 w-full md:w-auto justify-center"
          >
            <UserPlus className="w-4 h-4" />
            Adicionar Técnico
          </button>
        </div>
      </div>

      <div className="bg-white dark:bg-[#1E293B] border border-slate-200 dark:border-slate-800/60 rounded-2xl shadow-sm overflow-hidden flex flex-col">
        <div className="p-4 border-b border-slate-200 dark:border-slate-800/60 bg-slate-50 dark:bg-[#1E293B]/50 flex flex-col md:flex-row gap-4 justify-between items-center">
          <div className="relative w-full md:max-w-md">
            <Search className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar por nome ou e-mail..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700/50 rounded-xl pl-10 pr-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 dark:text-slate-100 transition-colors"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 dark:bg-[#0F172A]/50 border-b border-slate-200 dark:border-slate-800/60">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Técnico</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Contatos</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Status Base</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider text-right">Acesso / Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
              {filteredTechs.map(tech => (
                <tr key={tech.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-cyan-100 dark:bg-cyan-900/30 flex items-center justify-center text-cyan-600 dark:text-cyan-400 font-bold border border-cyan-200 dark:border-cyan-800">
                        {tech.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 dark:text-slate-100">{tech.name}</p>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{tech.role === 'ADMIN' ? 'Administrador' : 'Técnico'}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-medium text-slate-600 dark:text-slate-300">{tech.email}</p>
                  </td>
                  <td className="px-6 py-4">
                    <button 
                      onClick={() => onToggleStatus(tech.id)}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-bold uppercase transition-colors ${tech.status === 'ATIVO' ? 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-400 dark:hover:bg-emerald-500/20' : 'bg-rose-50 text-rose-600 hover:bg-rose-100 dark:bg-rose-500/10 dark:text-rose-400 dark:hover:bg-rose-500/20'}`}
                    >
                      <div className={`w-1.5 h-1.5 rounded-full ${tech.status === 'ATIVO' ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                      {tech.status}
                    </button>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                       <button
                         onClick={() => setPasswordFormObj({ techId: tech.id, name: tech.name })}
                         className="p-2 text-slate-400 hover:text-cyan-600 dark:hover:text-cyan-400 transition-colors rounded-lg hover:bg-cyan-50 dark:hover:bg-cyan-900/20 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50 tooltip-trigger relative group"
                         title="Definir/Resetar Senha"
                       >
                         <KeyRound className="w-4 h-4" />
                       </button>
                       <button
                         onClick={() => {
                           setDeleteConfirmObj({ techId: tech.id, name: tech.name });
                         }}
                         className="p-2 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 transition-colors rounded-lg hover:bg-rose-50 dark:hover:bg-rose-900/20 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/50"
                         title="Apagar Técnico"
                       >
                         <Trash2 className="w-4 h-4" />
                       </button>
                    </div>
                  </td>
                </tr>
              ))}
              {filteredTechs.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-6 py-12 text-center text-slate-500 dark:text-slate-400 text-sm">
                    Nenhum técnico de suporte encontrado.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isAdding && (
        <div className="fixed inset-0 bg-slate-900/30 dark:bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl p-6 relative border border-slate-200 dark:border-slate-800">
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-4">Novo Técnico de Suporte</h3>
            {newTechError && (
              <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400 px-4 py-3 rounded-xl text-sm mb-4">
                {newTechError}
              </div>
            )}
            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Nome Completo</label>
                <input
                  type="text"
                  required
                  value={newTechForm.name}
                  onChange={e => setNewTechForm({...newTechForm, name: e.target.value})}
                  className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-500 dark:text-slate-100"
                  placeholder="Ex: João Silva"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">E-mail Corporativo</label>
                <input
                  type="email"
                  required
                  value={newTechForm.email}
                  onChange={e => setNewTechForm({...newTechForm, email: e.target.value})}
                  className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-500 dark:text-slate-100"
                  placeholder="Ex: joao.silva@upx.com"
                />
              </div>
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 bg-slate-50 dark:bg-slate-800 p-3 rounded-lg border border-slate-100 dark:border-slate-700">
                  O técnico receberá o e-mail cadastrado e não terá senha inicial. Você deve gerar e atribuir uma senha para ele logo após a criação na tabela usando o botão de chaves. O departamento adotado será 'Suporte'.
                </p>
              </div>
              <div className="flex gap-3 justify-end pt-4">
                <button
                  type="button"
                  onClick={() => { setIsAdding(false); setNewTechError(''); }}
                  className="px-4 py-2.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl font-semibold transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-cyan-500 hover:bg-cyan-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-sm transition-colors"
                >
                  Criar Técnico
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {passwordFormObj && (
        <div className="fixed inset-0 bg-slate-900/30 dark:bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl p-6 relative border border-slate-200 dark:border-slate-800">
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2 mt-1 flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-cyan-500" />
              Definir Acesso
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-5">
              Crie uma senha temporária ou definitiva para <strong>{passwordFormObj.name}</strong> acessar o sistema.
            </p>
            <form onSubmit={handlePasswordSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-1">Nova Senha</label>
                <input
                  type="text"
                  required
                  value={newPasswordString}
                  onChange={e => setNewPasswordString(e.target.value)}
                  className="w-full bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl px-4 py-2.5 focus:outline-none focus:border-cyan-500 dark:focus:border-cyan-500 dark:text-slate-100 font-mono"
                  placeholder="Digite a senha..."
                  minLength={5}
                />
              </div>
              <div className="flex gap-3 justify-end pt-4">
                <button
                  type="button"
                  onClick={() => { setPasswordFormObj(null); setNewPasswordString(''); }}
                  className="px-4 py-2.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl font-semibold transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="bg-cyan-500 hover:bg-cyan-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-sm transition-colors flex items-center gap-2"
                >
                  Atualizar Senha
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {deleteConfirmObj && (
        <div className="fixed inset-0 bg-slate-900/30 dark:bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-md rounded-2xl shadow-2xl p-6 relative border border-slate-200 dark:border-slate-800">
            <h3 className="text-xl font-bold text-slate-800 dark:text-slate-100 mb-2 mt-1 flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-rose-500" />
              Apagar Técnico
            </h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-5">
              Tem certeza que deseja apagar o registro de <strong>{deleteConfirmObj.name}</strong>? Isso pode quebrar referências de chamados passados caso dependam deste técnico.
            </p>
            <div className="flex gap-3 justify-end pt-4">
              <button
                type="button"
                onClick={() => setDeleteConfirmObj(null)}
                className="px-4 py-2.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl font-semibold transition-colors"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteTechnician(deleteConfirmObj.techId);
                  setDeleteConfirmObj(null);
                }}
                className="bg-rose-500 hover:bg-rose-600 text-white px-6 py-2.5 rounded-xl font-bold shadow-sm transition-colors flex items-center gap-2"
              >
                Sim, Apagar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
