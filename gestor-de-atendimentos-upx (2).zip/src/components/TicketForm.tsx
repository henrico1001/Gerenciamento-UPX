/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Ticket, TicketStatus, PROBLEM_CATEGORIES, SOLUTION_CATEGORIES, DEVICE_MODELS, User, PRODUCT_INFO_CAUSES } from '../types';
import { 
  Building2, 
  UserSquare, 
  FileCheck, 
  AlertTriangle, 
  Settings2, 
  Sparkles, 
  HelpCircle,
  Clock,
  ArrowLeft,
  Save,
  Undo2,
  ArrowRightLeft,
  Smartphone,
  ChevronDown,
  Phone
} from 'lucide-react';

interface TicketFormProps {
  currentUser: User;
  allTechnicians: User[];
  editingTicket?: Ticket | null;
  onSubmit: (ticketData: Omit<Ticket, 'id' | 'dateTime' | 'technicianId' | 'technicianName' | 'transfer'> & { id?: string; transfer?: Ticket['transfer'] }) => void;
  onCancel: () => void;
}

export default function TicketForm({ currentUser, allTechnicians, editingTicket, onSubmit, onCancel }: TicketFormProps) {
  const [clientName, setClientName] = useState('');
  const [clientPhone, setClientPhone] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [deviceModel, setDeviceModel] = useState('');
  const [problemCategory, setProblemCategory] = useState('');
  const [productInfoCause, setProductInfoCause] = useState('');
  const [status, setStatus] = useState<TicketStatus>('EM_ANDAMENTO');
  const [solutionCategory, setSolutionCategory] = useState(SOLUTION_CATEGORIES[0]);
  const [observations, setObservations] = useState('');
  const [finishedTime, setFinishedTime] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  
  const [isMotivoOpen, setIsMotivoOpen] = useState(false);
  const [motivoSearch, setMotivoSearch] = useState('');
  const motivoRef = useRef<HTMLDivElement>(null);
  
  const [isDeviceModelOpen, setIsDeviceModelOpen] = useState(false);
  const [deviceModelSearch, setDeviceModelSearch] = useState('');
  const deviceModelRef = useRef<HTMLDivElement>(null);
  
  const [isProductInfoCauseOpen, setIsProductInfoCauseOpen] = useState(false);
  const [productInfoCauseSearch, setProductInfoCauseSearch] = useState('');
  const productInfoCauseRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (motivoRef.current && !motivoRef.current.contains(event.target as Node)) {
        setIsMotivoOpen(false);
      }
      if (deviceModelRef.current && !deviceModelRef.current.contains(event.target as Node)) {
        setIsDeviceModelOpen(false);
      }
      if (productInfoCauseRef.current && !productInfoCauseRef.current.contains(event.target as Node)) {
        setIsProductInfoCauseOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Transfer states inside creation/edit form
  const [isTransferring, setIsTransferring] = useState(false);
  const [transferTechId, setTransferTechId] = useState('');
  const [transferReason, setTransferReason] = useState('');

  // Populate data if we are in editing mode
  useEffect(() => {
    if (editingTicket) {
      setClientName(editingTicket.clientName);
      setClientPhone(editingTicket.clientPhone || '');
      setCompanyName(editingTicket.companyName);
      setDeviceModel(editingTicket.deviceModel);
      setProblemCategory(editingTicket.problemCategory);
      setProductInfoCause(editingTicket.productInfoCause || PRODUCT_INFO_CAUSES[0]);
      setStatus(editingTicket.status);
      setObservations(editingTicket.observations || '');
      if (editingTicket.solutionCategory) {
        setSolutionCategory(editingTicket.solutionCategory);
      } else {
        setSolutionCategory(SOLUTION_CATEGORIES[0]);
      }
      if (editingTicket.finishedAt) {
        const date = new Date(editingTicket.finishedAt);
        const hh = date.getHours().toString().padStart(2, '0');
        const mm = date.getMinutes().toString().padStart(2, '0');
        setFinishedTime(`${hh}:${mm}`);
      } else {
        setFinishedTime('');
      }
      
      if (['EM_ANDAMENTO'].includes(editingTicket.status) && editingTicket.transfer) {
        setIsTransferring(true);
        setTransferTechId(editingTicket.transfer.toId);
        setTransferReason(editingTicket.transfer.reason);
      } else {
        setIsTransferring(false);
        setTransferTechId('');
        setTransferReason('');
      }
    } else {
      // Default creation defaults
      setClientName('');
      setClientPhone('');
      setCompanyName('');
      setDeviceModel('');
      setProblemCategory('');
      setProductInfoCause('');
      setStatus('EM_ANDAMENTO');
      setSolutionCategory(SOLUTION_CATEGORIES[0]);
      setObservations('');
      setFinishedTime('');
      setIsTransferring(false);
      setTransferTechId('');
      setTransferReason('');
    }
    setErrorMsg('');
  }, [editingTicket]);

  // Reset transfer state if the status is not EM_ANDAMENTO
  useEffect(() => {
    if (!['EM_ANDAMENTO'].includes(status)) {
      setIsTransferring(false);
    }
  }, [status]);

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 11) value = value.slice(0, 11);
    
    if (value.length > 2) {
      value = `(${value.slice(0, 2)}) ${value.slice(2)}`;
    }
    if (value.length > 9) {
      value = `${value.slice(0, 10)}-${value.slice(10)}`;
    } else if (value.length > 8) {
      value = `${value.slice(0, 9)}-${value.slice(9)}`;
    }
    
    setClientPhone(value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!clientName.trim()) {
      setErrorMsg('O nome do cliente é obrigatório.');
      return;
    }
    if (!clientPhone.trim() || clientPhone.replace(/\D/g, '').length < 10) {
      setErrorMsg('O telefone do cliente é obrigatório e deve ser válido.');
      return;
    }
    if (!companyName.trim()) {
      setErrorMsg('A empresa do cliente é obrigatória.');
      return;
    }
    if (!problemCategory) {
      setErrorMsg('Selecione um motivo para o chamado.');
      return;
    }
    
    if (['Informações sobre produtos', 'Falha de funcionamento', 'Instalação'].includes(problemCategory)) {
      if (!deviceModel) {
        setErrorMsg('Selecione o modelo do equipamento.');
        return;
      }
      if (!productInfoCause) {
        setErrorMsg('Selecione a causa relacionada ao produto.');
        return;
      }
    }

    const payload: Omit<Ticket, 'id' | 'dateTime' | 'technicianId' | 'technicianName' | 'transfer'> & { id?: string; transfer?: Ticket['transfer'] } = {
      clientName: clientName.trim(),
      clientPhone: clientPhone.trim(),
      companyName: companyName.trim(),
      deviceModel: ['Informações sobre produtos', 'Falha de funcionamento', 'Instalação'].includes(problemCategory) ? deviceModel : DEVICE_MODELS[0],
      problemCategory,
      productInfoCause: ['Informações sobre produtos', 'Falha de funcionamento', 'Instalação'].includes(problemCategory) ? productInfoCause : undefined,
      status,
      observations: observations.trim() || undefined,
    };

    // If solved, apply solution category
    if (status === 'RESOLVIDO') {
      payload.solutionCategory = solutionCategory;
      if (finishedTime) {
        const baseDate = editingTicket ? new Date(editingTicket.dateTime) : new Date();
        const [hh, mm] = finishedTime.split(':').map(Number);
        if (!isNaN(hh) && !isNaN(mm)) {
          baseDate.setHours(hh, mm, 0, 0);
          payload.finishedAt = baseDate.toISOString();
        }
      }
    }

    if (isTransferring) {
      if (!transferTechId) {
        setErrorMsg('Por favor, selecione um técnico de destino para a transferência.');
        return;
      }
      if (!transferReason.trim()) {
        setErrorMsg('Por favor, descreva o motivo da transferência.');
        return;
      }
      const targetTech = allTechnicians.find(u => u.id === transferTechId);
      if (targetTech) {
        payload.transfer = {
          fromId: editingTicket?.transfer?.fromId || currentUser.id,
          fromName: editingTicket?.transfer?.fromName || currentUser.name,
          toId: targetTech.id,
          toName: targetTech.name,
          reason: transferReason.trim(),
          status: editingTicket?.transfer?.status || 'PENDENTE',
          timestamp: editingTicket?.transfer?.timestamp || new Date().toISOString()
        };
      }
    } else {
      payload.transfer = editingTicket?.transfer;
    }

    if (editingTicket) {
      payload.id = editingTicket.id;
    }

    onSubmit(payload);
  };

  return (
    <div className="bg-white dark:bg-[#1E293B]/90 backdrop-blur-md rounded-2xl border border-slate-200/80 dark:border-slate-800/80 p-6 md:p-8 shadow-sm space-y-6 max-w-4xl mx-auto" id="ticket-form-panel">
      
      {/* Header section with structured Back button and Title */}
      <div className="space-y-4 pb-4 border-b border-slate-100 dark:border-slate-800/50">
        <div className="flex justify-between items-center">
          <button
            type="button"
            onClick={onCancel}
            className="inline-flex items-center gap-1.5 text-xs text-slate-500 hover:text-cyan-600 transition-colors duration-200 cursor-pointer font-bold select-none group"
          >
            <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-0.5" />
            Voltar à Tela Anterior
          </button>
          
          <div className="flex items-center gap-1 text-[10px] bg-cyan-50 dark:bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 px-3 py-1.5 font-bold uppercase rounded-lg tracking-wider">
            <Sparkles className="w-3.5 h-3.5 text-cyan-500" />
            <span>Suporte UPX</span>
          </div>
        </div>

        <div>
          <h2 className="text-xl font-bold text-slate-800 dark:text-slate-100 tracking-tight" id="form-title">
            {editingTicket ? 'Editar Atendimento' : 'Registrar Novo Atendimento'}
          </h2>
          <p className="text-xs text-slate-400 dark:text-slate-500 font-medium mt-1">
            Técnico responsável: <span className="text-cyan-600 dark:text-cyan-405 font-semibold">{editingTicket ? editingTicket.technicianName : currentUser.name}</span>
          </p>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 bg-rose-50 dark:bg-rose-500/10 border border-rose-200 dark:border-rose-500/20 text-rose-700 dark:text-rose-455 text-xs rounded-xl flex items-center gap-2" id="form-error-alert">
          <AlertTriangle className="w-4.5 h-4.5 text-rose-500 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6" id="form-ticket-body">
        
        {/* Core Info - Handled in 3 columns */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          
          {/* Client input */}
          <div className="space-y-1.5 animate-fadeIn">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5" htmlFor="client-name">
              <UserSquare className="w-4 h-4 text-cyan-500" />
              Nome do Cliente *
            </label>
            <input
              type="text"
              id="client-name"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              placeholder="ex: Carlos Alberto de Souza"
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-xl text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 focus:bg-white dark:focus:bg-[#1E293B]/60 transition-colors placeholder-slate-400 dark:placeholder-slate-500"
            />
          </div>

          <div className="space-y-1.5 animate-fadeIn">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5" htmlFor="client-phone">
              <Phone className="w-4 h-4 text-cyan-500" />
              Telefone do Cliente *
            </label>
            <input
              type="text"
              id="client-phone"
              value={clientPhone}
              onChange={handlePhoneChange}
              placeholder="ex: (11) 99999-9999"
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-xl text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 focus:bg-white dark:focus:bg-[#1E293B]/60 transition-colors placeholder-slate-400 dark:placeholder-slate-500"
            />
          </div>

          {/* Company input */}
          <div className="space-y-1.5 animate-fadeIn">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5" htmlFor="company-name">
              <Building2 className="w-4 h-4 text-cyan-500" />
              Empresa do Cliente *
            </label>
            <input
              type="text"
              id="company-name"
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              placeholder="ex: Comercial Alvorada Ltda"
              className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-xl text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 focus:bg-white dark:focus:bg-[#1E293B]/60 transition-colors placeholder-slate-400 dark:placeholder-slate-500"
            />
          </div>

          {/* Problem categorisation selector (Motivo) */}
          <div className="space-y-2 animate-fadeIn lg:col-span-3 md:col-span-3 relative z-50">
            <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5 mb-1" htmlFor="problem-category-btn">
              <HelpCircle className="w-4 h-4 text-cyan-500" />
              Motivo *
            </label>
            <div className="relative" ref={motivoRef}>
              <button
                type="button"
                id="problem-category-btn"
                onClick={() => setIsMotivoOpen(!isMotivoOpen)}
                className={`w-full flex items-center justify-between bg-slate-50 dark:bg-slate-900 border px-4 py-2.5 rounded-xl text-sm transition-colors text-left ${
                  isMotivoOpen ? 'border-cyan-500 text-slate-800 dark:text-slate-100 bg-white dark:bg-[#1E293B]/60' : 'border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100'
                }`}
              >
                <span className={!problemCategory ? "text-slate-400 dark:text-slate-500" : ""}>{problemCategory || 'Selecione um motivo...'}</span>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isMotivoOpen ? 'rotate-180 text-cyan-500' : ''}`} />
              </button>
              
              <AnimatePresence>
                {isMotivoOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    transition={{ duration: 0.15 }}
                    className="absolute z-50 w-full mt-2 bg-white dark:bg-slate-900 shadow-xl border border-slate-200 dark:border-slate-700/60 rounded-2xl overflow-hidden"
                  >
                    <div className="p-2 border-b border-slate-100 dark:border-slate-800">
                      <input
                        type="text"
                        placeholder="Pesquisar motivo..."
                        value={motivoSearch}
                        onChange={(e) => setMotivoSearch(e.target.value)}
                        className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-2 rounded-lg text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                    <div className="max-h-64 overflow-y-auto w-full flex flex-col py-1">
                      {PROBLEM_CATEGORIES.filter(category => category.toLowerCase().includes(motivoSearch.toLowerCase())).length > 0 ? (
                        PROBLEM_CATEGORIES.filter(category => category.toLowerCase().includes(motivoSearch.toLowerCase())).map((category) => (
                          <button
                            key={category}
                            type="button"
                            onClick={() => {
                              setProblemCategory(category);
                              setIsMotivoOpen(false);
                            }}
                            className={`w-full px-4 py-3 text-[13px] font-semibold transition-all text-left flex items-center gap-3 group border-b border-slate-100 dark:border-slate-800/80 last:border-0 ${
                              problemCategory === category
                                ? 'bg-cyan-50 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 shadow-sm'
                                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/80 hover:text-slate-800 dark:hover:text-slate-200'
                            }`}
                          >
                            <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                              problemCategory === category 
                                ? 'border-cyan-500 bg-white dark:bg-transparent' 
                                : 'border-slate-300 dark:border-slate-600 group-hover:border-slate-400 dark:group-hover:border-slate-500 bg-white dark:bg-slate-800'
                            }`}>
                              {problemCategory === category && (
                                <div className="w-2.5 h-2.5 rounded-full bg-cyan-500 shadow-[0_0_8px_rgba(6,182,212,0.4)]" />
                              )}
                            </div>
                            <span className="truncate">{category}</span>
                          </button>
                        ))
                      ) : (
                        <div className="px-4 py-3 text-sm text-slate-500 text-center">Nenhum motivo encontrado.</div>
                      )}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            {!PROBLEM_CATEGORIES.includes(problemCategory) && problemCategory !== '' && (
              <div className="mt-2 p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300">
                <span className="font-bold">Outro Selecionado Anteriormente:</span> {problemCategory}
              </div>
            )}
          </div>

          <AnimatePresence>
            {['Informações sobre produtos', 'Falha de funcionamento', 'Instalação'].includes(problemCategory) && (
              <motion.div
                initial={{ opacity: 0, height: 0, marginTop: 0, overflow: 'hidden' }}
                animate={{ opacity: 1, height: 'auto', marginTop: '1.25rem', transitionEnd: { overflow: 'visible' } }}
                exit={{ opacity: 0, height: 0, marginTop: 0, overflow: 'hidden' }}
                className="col-span-1 md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-5"
              >
                {/* Device Model input */}
                <div className="space-y-1.5 z-40 relative">
                  <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5" htmlFor="device-model-btn">
                    <Smartphone className="w-4 h-4 text-cyan-500" />
                    Modelo do Equipamento *
                  </label>
                  <div className="relative" ref={deviceModelRef}>
                    <button
                      type="button"
                      id="device-model-btn"
                      onClick={() => setIsDeviceModelOpen(!isDeviceModelOpen)}
                      className={`w-full flex items-center justify-between bg-slate-50 dark:bg-slate-900 border px-4 py-2.5 rounded-xl text-sm transition-colors text-left ${
                        isDeviceModelOpen ? 'border-cyan-500 text-slate-800 dark:text-slate-100 bg-white dark:bg-[#1E293B]/60' : 'border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100'
                      }`}
                    >
                      <span className={!deviceModel ? "text-slate-400 dark:text-slate-500" : ""}>{deviceModel || 'Selecione o modelo...'}</span>
                      <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isDeviceModelOpen ? 'rotate-180 text-cyan-500' : ''}`} />
                    </button>
                    
                    <AnimatePresence>
                      {isDeviceModelOpen && (
                        <motion.div
                          initial={{ opacity: 0, y: -5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          transition={{ duration: 0.15 }}
                          className="absolute z-50 w-full mt-2 bg-white dark:bg-slate-900 shadow-xl border border-slate-200 dark:border-slate-700/60 rounded-2xl overflow-hidden"
                        >
                          <div className="p-2 border-b border-slate-100 dark:border-slate-800">
                            <input
                              type="text"
                              placeholder="Pesquisar modelo..."
                              value={deviceModelSearch}
                              onChange={(e) => setDeviceModelSearch(e.target.value)}
                              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-2 rounded-lg text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                              onClick={(e) => e.stopPropagation()}
                            />
                          </div>
                          <div className="max-h-64 overflow-y-auto w-full flex flex-col py-1">
                            {DEVICE_MODELS.filter(model => model.toLowerCase().includes(deviceModelSearch.toLowerCase())).length > 0 ? (
                              DEVICE_MODELS.filter(model => model.toLowerCase().includes(deviceModelSearch.toLowerCase())).map((model) => (
                                <button
                                  key={model}
                                  type="button"
                                  onClick={() => {
                                    setDeviceModel(model);
                                    setIsDeviceModelOpen(false);
                                  }}
                                  className={`w-full px-4 py-3 text-[13px] font-semibold transition-all text-left flex items-center gap-3 group border-b border-slate-100 dark:border-slate-800/80 last:border-0 ${
                                    deviceModel === model
                                      ? 'bg-cyan-50 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 shadow-sm'
                                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/80 hover:text-slate-800 dark:hover:text-slate-200'
                                  }`}
                                >
                                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                                    deviceModel === model 
                                      ? 'border-cyan-500 bg-white dark:bg-transparent' 
                                      : 'border-slate-300 dark:border-slate-600 group-hover:border-slate-400 dark:group-hover:border-slate-500 bg-white dark:bg-slate-800'
                                  }`}>
                                    {deviceModel === model && <div className="w-2 h-2 rounded-full bg-cyan-500" />}
                                  </div>
                                  <span className="flex-1 line-clamp-2">{model}</span>
                                </button>
                              ))
                            ) : (
                              <div className="px-4 py-3 text-sm text-slate-500 text-center">Nenhum modelo encontrado.</div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>

                {/* Info Cause input */}
                <div className="space-y-1.5 z-30 relative">
                  <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5" htmlFor="product-info-cause-btn">
                    <HelpCircle className="w-4 h-4 text-cyan-500" />
                    Causa *
                  </label>
                  <div className="relative" ref={productInfoCauseRef}>
                    <button
                      type="button"
                      id="product-info-cause-btn"
                      onClick={() => setIsProductInfoCauseOpen(!isProductInfoCauseOpen)}
                      className={`w-full flex items-center justify-between bg-slate-50 dark:bg-slate-900 border px-4 py-2.5 rounded-xl text-sm transition-colors text-left ${
                        isProductInfoCauseOpen ? 'border-cyan-500 text-slate-800 dark:text-slate-100 bg-white dark:bg-[#1E293B]/60' : 'border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-100'
                      }`}
                    >
                      <span className={!productInfoCause ? "text-slate-400 dark:text-slate-500" : ""}>{productInfoCause || 'Selecione a causa...'}</span>
                      <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isProductInfoCauseOpen ? 'rotate-180 text-cyan-500' : ''}`} />
                    </button>
                    
                    <AnimatePresence>
                      {isProductInfoCauseOpen && (
                        <motion.div
                          initial={{ opacity: 0, y: -5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          transition={{ duration: 0.15 }}
                          className="absolute z-50 w-full mt-2 bg-white dark:bg-slate-900 shadow-xl border border-slate-200 dark:border-slate-700/60 rounded-2xl overflow-hidden"
                        >
                          <div className="p-2 border-b border-slate-100 dark:border-slate-800">
                            <input
                              type="text"
                              placeholder="Pesquisar causa..."
                              value={productInfoCauseSearch}
                              onChange={(e) => setProductInfoCauseSearch(e.target.value)}
                              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-3 py-2 rounded-lg text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 transition-colors"
                              onClick={(e) => e.stopPropagation()}
                            />
                          </div>
                          <div className="max-h-64 overflow-y-auto w-full flex flex-col py-1">
                            {PRODUCT_INFO_CAUSES.filter(cause => cause.toLowerCase().includes(productInfoCauseSearch.toLowerCase())).length > 0 ? (
                              PRODUCT_INFO_CAUSES.filter(cause => cause.toLowerCase().includes(productInfoCauseSearch.toLowerCase())).map((cause) => (
                                <button
                                  key={cause}
                                  type="button"
                                  onClick={() => {
                                    setProductInfoCause(cause);
                                    setIsProductInfoCauseOpen(false);
                                  }}
                                  className={`w-full px-4 py-3 text-[13px] font-semibold transition-all text-left flex items-center gap-3 group border-b border-slate-100 dark:border-slate-800/80 last:border-0 ${
                                    productInfoCause === cause
                                      ? 'bg-cyan-50 dark:bg-cyan-500/10 text-cyan-750 dark:text-cyan-400 shadow-sm'
                                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/80 hover:text-slate-800 dark:hover:text-slate-200'
                                  }`}
                                >
                                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center shrink-0 transition-colors ${
                                    productInfoCause === cause 
                                      ? 'border-cyan-500 bg-white dark:bg-transparent' 
                                      : 'border-slate-300 dark:border-slate-600 group-hover:border-slate-400 dark:group-hover:border-slate-500 bg-white dark:bg-slate-800'
                                  }`}>
                                    {productInfoCause === cause && <div className="w-2 h-2 rounded-full bg-cyan-500" />}
                                  </div>
                                  <span className="flex-1 line-clamp-2">{cause}</span>
                                </button>
                              ))
                            ) : (
                              <div className="px-4 py-3 text-sm text-slate-500 text-center">Nenhuma causa encontrada.</div>
                            )}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Status choices were removed per user request */}
        {/* Toggle Direct Transfer Panel */}
        {['EM_ANDAMENTO'].includes(status) && (
          <div className="bg-slate-50 dark:bg-slate-900/40 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 animate-fadeIn" id="form-transfer-container">
            <label className="flex items-start sm:items-center gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={isTransferring}
                onChange={(e) => setIsTransferring(e.target.checked)}
                className="mt-1 sm:mt-0 w-4.5 h-4.5 text-cyan-600 border-slate-300 rounded focus:ring-cyan-500 cursor-pointer shrink-0"
                id="checkbox-transfer-service"
              />
              <div className="space-y-0.5">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5 uppercase tracking-wider">
                  <ArrowRightLeft className="w-4 h-4 text-amber-500" />
                  Transferir este chamado para outro técnico *
                </span>
                <span className="text-[11px] text-slate-400 dark:text-slate-500 block leading-normal">
                  Selecione essa opção para registrar o chamado e enviá-lo pendente para aceitação de outro técnico.
                </span>
              </div>
            </label>

            {isTransferring && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800 overflow-hidden"
                id="form-transfer-details-block"
              >
                {/* Select technician */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block flex items-center gap-1" htmlFor="form-transfer-tech">
                    Técnico de Destino *
                  </label>
                  <select
                    id="form-transfer-tech"
                    value={transferTechId}
                    onChange={(e) => setTransferTechId(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2.5 text-xs rounded-xl text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 cursor-pointer"
                  >
                    <option value="">Selecione quem receberá o chamado...</option>
                    {allTechnicians
                      .filter(u => u.role === 'TECNICO' && u.status === 'ATIVO' && u.id !== currentUser.id)
                      .map(tech => (
                        <option key={tech.id} value={tech.id} className="dark:bg-slate-900">
                          {tech.name}
                        </option>
                      ))}
                  </select>
                </div>

                {/* Reason */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-bold text-slate-600 dark:text-slate-400 block" htmlFor="form-transfer-reason">
                    Motivo da Transferência *
                  </label>
                  {/* Quick templates */}
                  <div className="flex flex-wrap gap-1 md:gap-1.5 mb-1 bg-white dark:bg-slate-900/50 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800/80">
                    <span className="text-[9px] font-bold text-slate-400 dark:text-slate-500 block uppercase tracking-wider w-full mb-1">Dicas de motivos rápidos:</span>
                    {[
                      "Ausência por licença médica",
                      "Indisponibilidade de agenda",
                      "Dificuldade técnica avançada",
                      "Equipamento sob manutenção",
                    ].map(opt => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => setTransferReason(opt)}
                        className="text-[10px] bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 px-2.5 py-1 rounded-md transition-all cursor-pointer border border-slate-200 dark:border-slate-800 font-semibold"
                      >
                        {opt}
                      </button>
                    ))}
                  </div>

                  <textarea
                    id="form-transfer-reason"
                    value={transferReason}
                    onChange={(e) => setTransferReason(e.target.value)}
                    rows={3}
                    placeholder="Selecione um dos motivos rápidos acima ou descreva detalhadamente a necessidade de transferir..."
                    className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3 py-2 text-xs rounded-xl text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 placeholder-slate-400 dark:placeholder-slate-550 resize-none"
                  />
                </div>
              </motion.div>
            )}
          </div>
        )}

        {/* Additional Observations / Notes (Optional) */}
        <div className="space-y-1.5 animate-fadeIn">
          <label className="text-xs font-bold text-slate-600 dark:text-slate-400 flex items-center gap-1.5" htmlFor="observations">
            <Settings2 className="w-4 h-4 text-cyan-500" />
            Observações Adicionais (Opcional)
          </label>
          <textarea
            id="observations"
            value={observations}
            onChange={(e) => setObservations(e.target.value)}
            rows={4}
            placeholder="Adicione detalhes complementares, especificações técnicas da máquina, histórico do cliente, links de relatórios de terceiros ou detalhes dos testes realizados."
            className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-4 py-2.5 rounded-xl text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:border-cyan-500 focus:bg-white dark:focus:bg-[#1E293B]/60 transition-colors placeholder-slate-400 dark:placeholder-slate-500 resize-none"
          />
        </div>

        {/* Submit Actions */}
        <div className="flex gap-3 justify-end pt-4 border-t border-slate-100 dark:border-slate-800/80">
          <button
            type="button"
            id="btn-cancel-ticket"
            onClick={onCancel}
            className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-450 font-medium text-xs hover:bg-slate-50 dark:hover:bg-slate-900 transition-all cursor-pointer flex items-center gap-2 hover:scale-[1.01] active:scale-[0.99]"
          >
            <Undo2 className="w-4 h-4" />
            Descartar
          </button>
          
          <button
            type="submit"
            id="btn-save-ticket"
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-600 hover:opacity-95 active:scale-[0.98] text-white font-bold text-xs transition-all shadow-md shadow-cyan-500/10 cursor-pointer flex items-center gap-2 hover:scale-[1.015]"
          >
            <Save className="w-4 h-4" />
            {editingTicket ? 'Salvar Alterações' : 'Registrar Chamado'}
          </button>
        </div>

      </form>
    </div>
  );
}
