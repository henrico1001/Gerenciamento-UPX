export interface ParsedEml {
  from: string;
  to: string;
  subject: string;
  date: string; // ISO string if parseable, or raw date string
  body: string;
  isHtml: boolean;
}

/**
 * Parses raw multipart MIME content based on the boundary string.
 */
function parseMultipart(bodyText: string, boundary: string): Array<{ headers: Record<string, string>; body: string }> {
  const delimiter = "--" + boundary;
  const parts: Array<{ headers: Record<string, string>; body: string }> = [];
  
  // Split content by the delimiter
  const rawParts = bodyText.split(delimiter);
  
  for (const rawPart of rawParts) {
    const trimmed = rawPart.trim();
    // Skip empty prologue, epilogue (--boundary--) or invalid parts
    if (trimmed === "" || trimmed === "--") continue;
    
    const lines = rawPart.split(/\r?\n/);
    
    let headerLines: string[] = [];
    let bodyLines: string[] = [];
    let parsingHeaders = true;
    
    // Find the first non-empty line to start parsing headers
    let index = 0;
    while (index < lines.length && lines[index].trim() === "") {
      index++;
    }
    
    for (let i = index; i < lines.length; i++) {
      const line = lines[i];
      if (parsingHeaders) {
        if (line.trim() === "") {
          parsingHeaders = false;
        } else if (line.startsWith(" ") || line.startsWith("\t")) {
          // Multiline header continuance
          if (headerLines.length > 0) {
            headerLines[headerLines.length - 1] += " " + line.trim();
          }
        } else {
          headerLines.push(line);
        }
      } else {
        bodyLines.push(line);
      }
    }
    
    const partHeaders: Record<string, string> = {};
    for (const hl of headerLines) {
      const colonIdx = hl.indexOf(":");
      if (colonIdx > -1) {
        const name = hl.substring(0, colonIdx).trim().toLowerCase();
        const value = hl.substring(colonIdx + 1).trim();
        partHeaders[name] = value;
      }
    }
    
    const pBody = bodyLines.join("\n");
    parts.push({ headers: partHeaders, body: pBody });
  }
  
  return parts;
}

/**
 * Recursively extracts plain text or HTML body from a MIME tree.
 */
function extractTextOrHtmlBody(bodyText: string, contentType: string, transferEncoding: string = ""): { body: string; isHtml: boolean } {
  const normalizedContentType = contentType.toLowerCase();
  
  let decodedBody = bodyText;
  
  // Check if this part has specific transfer encodings
  if (transferEncoding.toLowerCase().includes("quoted-printable")) {
    decodedBody = decodeQuotedPrintable(decodedBody);
  } else if (transferEncoding.toLowerCase().includes("base64")) {
    try {
      const base64Str = decodedBody.replace(/\s+/g, "");
      // Decodes base64 text
      decodedBody = decodeURIComponent(
        escape(atob(base64Str))
      );
    } catch (e) {
      try {
        decodedBody = atob(decodedBody.replace(/\s+/g, ""));
      } catch (err) {
        // Fallback to original text if decoding completely fails
      }
    }
  }

  // If this part is a multipart, drill down recursively!
  if (normalizedContentType.includes("multipart/")) {
    const boundaryMatch = contentType.match(/boundary="?([^";\s]+)"?/i);
    if (boundaryMatch) {
      const boundary = boundaryMatch[1];
      const parts = parseMultipart(bodyText, boundary);
      
      let htmlBody: string | null = null;
      let plainTextBody: string | null = null;
      
      for (const part of parts) {
        const partContentType = part.headers["content-type"] || "text/plain";
        const partEncoding = part.headers["content-transfer-encoding"] || "";
        const res = extractTextOrHtmlBody(part.body, partContentType, partEncoding);
        
        if (res.isHtml && res.body.trim()) {
          htmlBody = res.body;
        } else if (res.body.trim() && !plainTextBody) {
          plainTextBody = res.body;
        }
      }
      
      // Prefer HTML, fallback to plain text
      if (htmlBody) {
        return { body: htmlBody, isHtml: true };
      }
      if (plainTextBody) {
        return { body: plainTextBody, isHtml: false };
      }
    }
  }

  const isHtml = normalizedContentType.includes("text/html");
  return { body: decodedBody, isHtml };
}

/**
 * Parses a raw .eml file content.
 */
export function parseEml(rawText: string): ParsedEml {
  const lines = rawText.split(/\r?\n/);
  const headers: Record<string, string> = {};
  let bodyStartIndex = 0;
  
  // Parse top-level headers
  let currentHeaderName = "";
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.trim() === "") {
      bodyStartIndex = i + 1;
      break;
    }
    
    if ((line.startsWith(" ") || line.startsWith("\t")) && currentHeaderName) {
      headers[currentHeaderName] += " " + line.trim();
    } else {
      const colonIdx = line.indexOf(":");
      if (colonIdx > -1) {
        const name = line.substring(0, colonIdx).trim().toLowerCase();
        const value = line.substring(colonIdx + 1).trim();
        headers[name] = value;
        currentHeaderName = name;
      }
    }
  }
  
  const rawBody = lines.slice(bodyStartIndex).join("\n");
  const contentType = headers["content-type"] || "text/plain";
  const transferEncoding = headers["content-transfer-encoding"] || "";
  
  // Extract body recursively through any multipart envelopes
  const result = extractTextOrHtmlBody(rawBody, contentType, transferEncoding);
  let finalBody = result.body;
  
  // One final safety cleaning step: If plain text contains leftover boundaries/headers (due to parsing malformed files)
  if (!result.isHtml) {
    const rawLines = finalBody.split("\n");
    const cleanedLines = rawLines.filter(line => {
      const lw = line.toLowerCase().trim();
      // Skip MIME/Boundary lines
      if (lw.startsWith("--") && (lw.includes("mb") || lw.includes("brap") || lw.includes("boundary") || lw.length > 25)) {
        return false;
      }
      if (lw.startsWith("content-type:") || lw.startsWith("content-transfer-encoding:") || lw.startsWith("boundary=")) {
        return false;
      }
      return true;
    });
    finalBody = cleanedLines.join("\n");
  }
  
  // Clean up sender email (e.g. "Some Name <some@email.com>" -> "some@email.com")
  let cleanFrom = headers["from"] || "";
  const fromEmailMatch = cleanFrom.match(/<([^>]+)>/);
  if (fromEmailMatch) {
    cleanFrom = fromEmailMatch[1];
  }
  
  let cleanDate = headers["date"] || "";
  try {
    const d = new Date(cleanDate);
    if (!isNaN(d.getTime())) {
      cleanDate = d.toISOString();
    }
  } catch (e) {
    // Keep raw string on failure
  }
  
  return {
    from: cleanFrom.trim(),
    to: headers["to"]?.trim() || "",
    subject: headers["subject"]?.trim() || "",
    date: cleanDate,
    body: finalBody,
    isHtml: result.isHtml
  };
}

/**
 * Decodes Quoted-Printable string format.
 */
function decodeQuotedPrintable(str: string): string {
  // Join soft breaks (equals sign at line end)
  let dec = str.replace(/=\r?\n/g, "");
  dec = dec.replace(/=\n/g, "");
  
  // Replace RFC 2045 hex-encoded characters with standard raw percentages for URI decoding
  try {
    // Replace hex matches (e.g., =C3=A1) with percentage representations (%C3%A1)
    const percentEncoded = dec.replace(/=([0-9A-F]{2})/gi, "%$1");
    return decodeURIComponent(percentEncoded);
  } catch (e) {
    // Fallback if decodeURIComponent fails (e.g. invalid bytes)
    try {
      return decodeURIComponent(escape(dec.replace(/=([0-9A-F]{2})/gi, (_, hex) => {
        return String.fromCharCode(parseInt(hex, 16));
      })));
    } catch (err) {
      return dec.replace(/=([0-9A-F]{2})/gi, (_, hex) => {
        return String.fromCharCode(parseInt(hex, 16));
      });
    }
  }
}
