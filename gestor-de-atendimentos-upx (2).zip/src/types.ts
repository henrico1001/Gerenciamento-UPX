/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'ADMIN' | 'TECNICO';

export type UserPosition = 'DONO' | 'CHEFE_SETOR' | 'FUNCIONARIO';

export type UserDepartment = 'Todos' | 'Suporte' | 'Comercial' | 'Fábrica' | 'Financeiro' | 'Estoque' | 'Estratégico' | 'Outro';

export type TicketStatus = 'RESOLVIDO' | 'EM_ANDAMENTO';

export interface TambasaTicket {
  id: string;
  emailOrigin: string;
  receivedAt: string;
  photoUrl: string;
  emlParsed?: {
    subject?: string;
    from?: string;
    to?: string;
    date?: string;
    body?: string;
    isHtml?: boolean;
    fileName?: string;
  };
  clientFinalName: string;
  clientFinalPhone: string;
  representativeName?: string;
  representativePhone?: string;
  invoiceUrl?: string;
  invoiceFileName?: string;
  invoiceIssueDate?: string;
  status: TicketStatus;
  openedBy: string;
  openedByName: string;
  createdAt: string;
  finishedAt?: string;
  duration?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  position?: UserPosition;
  department?: UserDepartment;
  status: 'ATIVO' | 'INATIVO';
  password?: string;
}

export interface Ticket {
  id: string;
  clientName: string;
  clientPhone?: string;
  companyName: string;
  deviceModel: string;
  dateTime: string; // ISO String
  finishedAt?: string; // ISO String
  problemCategory: string;
  productInfoCause?: string;
  status: TicketStatus;
  solutionCategory?: string;
  observations?: string;
  technicianId: string;
  technicianName: string;
  transfer?: {
    fromId: string;
    fromName: string;
    toId: string;
    toName: string;
    reason: string;
    status: 'PENDENTE' | 'ACEITO' | 'RECUSADO';
    timestamp: string;
  };
}

// Predefined Causes
export const PRODUCT_INFO_CAUSES = [
  "Não liga",
  "Não pesa",
  "Não zera",
  "desligando sozinha",
  "Peso oscilando ou instavel",
  "Não comunica",
  "Teclhas/teclado falhando",
  "Não Imprimi",
  "Travando Etiqueta",
  "Puxando papel em branco",
  "Manchando impressões",
  "Riscos nas impressões",
  "Falhas nas impressões",
  "Impressões Fracas/falhadas",
  "Não Abre",
  "Não Transmite",
  "Mensagem de erro"
];

// Predefined Problem List
export const PROBLEM_CATEGORIES = [
  "Falha de funcionamento",
  "Instalação",
  "Informações sobre produtos",
  "Garantias",
  "Treinamento",
  "Credenciamento",
  "Reparo fora de garantia"
];

// Predefined Solutions List
export const SOLUTION_CATEGORIES = [
  "Instalação completa",
  "Instruções Operacionais",
  "Indicação de Autorizada",
  "Configurações",
  "Instalação/Reinstalação de Programa",
  "Mal contato/ Reconexoes de Cabos",
  "Tomada sem Energia",
  "Dica de Reparo para Assistencia",
  "Envio de Manual ou Informação Técnica",
  "Suporte para Calibração",
  "Desnivelamento",
  "Corrente de Vento",
  "Prato mal encaixado/desposicionado",
  "Montagem/Conexao Incorreta"
];

// Predefined Device Models
export const DEVICE_MODELS = [
  "Balanças de Plataforma com Indicador Blue",
  "Balanças de Plataforma com Indicador IDX 10.000",
  "Checkout R2",
  "Checkout R4",
  "Checkout R7",
  "Combo Acqua 15 Impressor Restaurante",
  "Combo Blue One",
  "Combo EA-20 Impressor Restaurante",
  "Combo Restaurante EA-32",
  "Combo Restaurante Wind",
  "Combo Wind D3R",
  "Combo Wind Mega",
  "Conferencia R7",
  "EA-15",
  "EA-20",
  "EA-32",
  "Indicador de Peso IDX 10.000",
  "Leitor de Código de Barras UBR 01",
  "S Printer Plus",
  "S Printer R",
  "Thunder",
  "Thunder 1",
  "Thunder 1/ Com torre",
  "Thunder 2",
  "Thunder 7",
  "Thunder 7/ Com torre",
  "Thunder 8",
  "Thunder 8/ Com torre",
  "Thunder Torre",
  "Wind D3"
];


export const STATUS_LABELS: Record<TicketStatus, { label: string; theme: string; text: string; bg: string }> = {
  RESOLVIDO: {
    label: "Resolvido",
    theme: "bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/25 hover:bg-emerald-100 dark:hover:bg-emerald-555/20",
    text: "text-emerald-750 dark:text-emerald-400",
    bg: "bg-emerald-500",
  },
  EM_ANDAMENTO: {
    label: "Em Andamento",
    theme: "bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-500/10 dark:text-blue-400 dark:border-blue-500/25 hover:bg-blue-100 dark:hover:bg-blue-555/20",
    text: "text-blue-750 dark:text-blue-400",
    bg: "bg-blue-500",
  }
};
