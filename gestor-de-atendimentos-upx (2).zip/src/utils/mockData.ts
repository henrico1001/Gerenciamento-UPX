/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, Ticket } from '../types';

export const INITIAL_USERS: User[] = [
  {
    id: "tech_gabriel",
    name: "Gabriel Mendes",
    email: "gabriel.mendes@upx.com",
    role: "TECNICO",
    status: "ATIVO"
  },
  {
    id: "tech_mariana",
    name: "Mariana Silva",
    email: "mariana.silva@upx.com",
    role: "TECNICO",
    status: "ATIVO"
  },
  {
    id: "tech_beatriz",
    name: "Beatriz Santos",
    email: "beatriz.santos@upx.com",
    role: "TECNICO",
    status: "ATIVO"
  },
  {
    id: "admin_ricardo",
    name: "Aurelino",
    email: "eng1@upxsolution.com.br",
    role: "ADMIN",
    position: "DONO",
    status: "ATIVO"
  }
];

// Helper to construct historical dates based on current date (May 2026)
const dateAtDay = (daysAgo: number, hour: number): string => {
  const d = new Date("2026-05-30T20:20:00.000Z");
  d.setDate(d.getDate() - daysAgo);
  d.setHours(hour, Math.floor(Math.random() * 60), 0);
  return d.toISOString();
};

export const INITIAL_TICKETS: Ticket[] = [
  {
    id: "t_101",
    clientName: "José Alencar",
    companyName: "Supermercado Alvorada",
    dateTime: dateAtDay(9, 9),
    problemCategory: "Instabilidade na Conexão de Internet",
    status: "RESOLVIDO",
    solutionCategory: "Roteamento Reconfigurado ou Reinicialização de Hardware de Rede",
    observations: "Sinal do modem oscilava muito. Realizada reconfiguração dos canais de frequência de 2.4GHz e 5GHz e atualizado firmware.",
    technicianId: "tech_gabriel",
    technicianName: "Gabriel Mendes",
    deviceModel: "Thunder"
  },
  {
    id: "t_102",
    clientName: "Ana Cláudia",
    companyName: "Clínica Bem Estar",
    dateTime: dateAtDay(8, 14),
    problemCategory: "Lentidão Geral no Sistema UPX",
    status: "RESOLVIDO",
    solutionCategory: "Limpeza de Cache, Cookies e Otimização de Arquivos Temporários",
    observations: "Lentidão resolvida após desfragmentar a base temporária e aplicar limpeza no histórico de renderizações do navegador.",
    technicianId: "tech_mariana",
    technicianName: "Mariana Silva",
    deviceModel: "Thunder"
  },
  {
    id: "t_103",
    clientName: "Carlos Drumond",
    companyName: "Auto Peças Roda Viva",
    dateTime: dateAtDay(7, 11),
    problemCategory: "Erro ao Emitir Nota Fiscal / Faturamento",
    status: "RESOLVIDO",
    solutionCategory: "Instalação de Certificado A1/A3 e Configuração no Sistema",
    observations: "O certificado digital do cliente estava vencido. Foi efetuada a instalação do novo certificado digital tipo A1 e os parâmetros de emissão foram atualizados.",
    technicianId: "tech_beatriz",
    technicianName: "Beatriz Santos",
    deviceModel: "Thunder"
  },
  {
    id: "t_104",
    clientName: "Renata Vasconcellos",
    companyName: "Padaria Delícia",
    dateTime: dateAtDay(6, 16),
    problemCategory: "Problema no Terminal de Vendas / PDV",
    status: "EM_ANDAMENTO",
    observations: "Terminal travando ao ler código de barras. Atualização de driver do hardware de leitura está pendente para amanhã para testes presenciais.",
    technicianId: "tech_gabriel",
    technicianName: "Gabriel Mendes",
    deviceModel: "Thunder"
  },
  {
    id: "t_105",
    clientName: "Marcos Pontes",
    companyName: "Transportadora Sul",
    dateTime: dateAtDay(5, 10),
    problemCategory: "Configuração de Rede / Firewall / VPN",
    status: "RESOLVIDO",
    solutionCategory: "Correção de Parâmetros de IP / Reconfiguração de DNS",
    observations: "VPN corporativo não conectava no notebook externo por falha de tradução de domínios. Ajustado o gateway primário da máquina do colaborador.",
    technicianId: "tech_mariana",
    technicianName: "Mariana Silva",
    deviceModel: "Thunder"
  },
  {
    id: "t_106",
    clientName: "Juliana Paes",
    companyName: "Hotel Plaza Centro",
    dateTime: dateAtDay(4, 15),
    problemCategory: "Falha de Autenticação / Senha Bloqueada",
    status: "RESOLVIDO",
    solutionCategory: "Reset de Credenciais e Liberação de Perfil de Acesso",
    observations: "Usuário errou a senha repetidas vezes e acionou o autofill incorreto. Desbloqueado manualmente via painel administrativo.",
    technicianId: "tech_beatriz",
    technicianName: "Beatriz Santos",
    deviceModel: "Thunder"
  },
  {
    id: "t_107",
    clientName: "Roberto Carlos",
    companyName: "Construtora Fortes",
    dateTime: dateAtDay(3, 11),
    problemCategory: "Falha Física de Hardware / Substituição de Peças",
    status: "EM_ANDAMENTO",
    observations: "Notebook de trabalho do coordenador de obras quebrou a placa-mãe após oscilação abrupta de energia. Necessário enviar para assistência autorizada ou aprovar reembolso.",
    technicianId: "tech_gabriel",
    technicianName: "Gabriel Mendes",
    deviceModel: "Thunder"
  },
  {
    id: "t_108",
    clientName: "Fernanda Montenegro",
    companyName: "Escola Crescer",
    dateTime: dateAtDay(2, 9),
    problemCategory: "Dúvidas de Uso ou Orientação de Sistemas",
    status: "RESOLVIDO",
    solutionCategory: "Treinamento Operacional Fornecido ao Colaborador do Cliente",
    observations: "Explicado todo o fluxo de importação da planilha Excel de notas e matrículas. O cliente entendeu e realizou o procedimento em conjunto.",
    technicianId: "tech_mariana",
    technicianName: "Mariana Silva",
    deviceModel: "Thunder"
  },
  {
    id: "t_109",
    clientName: "Aline Moraes",
    companyName: "Clínica Bem Estar",
    dateTime: dateAtDay(2, 14),
    problemCategory: "Instalação ou Atualização de Software",
    status: "RESOLVIDO",
    solutionCategory: "Reinstalação do Software UPX ou Atualização do Sistema",
    observations: "Efetuada atualização de versão v4.12 que continha as otimizações de faturamento mensais exigidas pela Sefaz.",
    technicianId: "tech_beatriz",
    technicianName: "Beatriz Santos",
    deviceModel: "Thunder"
  },
  {
    id: "t_110",
    clientName: "Silvio Santos",
    companyName: "Supermercado Alvorada",
    dateTime: dateAtDay(1, 10),
    problemCategory: "Problema no Terminal de Vendas / PDV",
    status: "RESOLVIDO",
    solutionCategory: "Ajuste Físico de Conector ou Limpeza de Hardware",
    observations: "Gaveta de dinheiro mecânica presa sem abrir por fita isolante mal posicionada. Gaveta limpa, lubrificada levemente e reconfigurada no PDV.",
    technicianId: "tech_gabriel",
    technicianName: "Gabriel Mendes",
    deviceModel: "Thunder"
  },
  {
    id: "t_111",
    clientName: "Gisele Bündchen",
    companyName: "Mundo Fashion Store",
    dateTime: dateAtDay(0, 11),
    problemCategory: "Instabilidade na Conexão de Internet",
    status: "EM_ANDAMENTO",
    observations: "Sinal do link de fibra caindo frequentemente no modem principal da recepção. Aberto contato inicial e aberto chamado técnico com a operadora Claro.",
    technicianId: "tech_mariana",
    technicianName: "Mariana Silva",
    deviceModel: "Thunder"
  },
  {
    id: "t_112",
    clientName: "Rodrigo Faro",
    companyName: "Faro Entretenimento",
    dateTime: dateAtDay(0, 15),
    problemCategory: "Backup Agendado Não Executado",
    status: "RESOLVIDO",
    solutionCategory: "Reconexão Manual de Banco de Dados ou Restauração de Backup",
    observations: "Pendrive de destino de backup estava desconectado fisicamente do servidor. Pendrive reinserido, script reconfigurado e backup concluído manualmente com sucesso.",
    technicianId: "tech_beatriz",
    technicianName: "Beatriz Santos",
    deviceModel: "Thunder"
  }
];

// Helper to load or initialize from localStorage
export const loadData = () => {
  const usersStr = localStorage.getItem('upx_users');
  const ticketsStr = localStorage.getItem('upx_tickets');

  if (!usersStr) {
    localStorage.setItem('upx_users', JSON.stringify(INITIAL_USERS));
  }
  if (!ticketsStr) {
    localStorage.setItem('upx_tickets', JSON.stringify(INITIAL_TICKETS));
  }
};

export const getStoredUsers = (): User[] => {
  const usersStr = localStorage.getItem('upx_users');
  return usersStr ? JSON.parse(usersStr) : INITIAL_USERS;
};

export const saveUsers = (users: User[]) => {
  localStorage.setItem('upx_users', JSON.stringify(users));
};

export const getStoredTickets = (): Ticket[] => {
  const ticketsStr = localStorage.getItem('upx_tickets');
  return ticketsStr ? JSON.parse(ticketsStr) : INITIAL_TICKETS;
};

export const saveTickets = (tickets: Ticket[]) => {
  localStorage.setItem('upx_tickets', JSON.stringify(tickets));
};

export const getTicketCounter = (): number => {
  const counterStr = localStorage.getItem('upx_ticket_counter');
  return counterStr ? parseInt(counterStr, 10) : 0;
};

export const setTicketCounter = (counter: number) => {
  console.log('Setting ticket counter to:', counter);
  localStorage.setItem('upx_ticket_counter', counter.toString());
};
